# Marketplace Remote Data — next boundary

The next server-backed boundary is account/profile data. `RemoteAccountRepository` uses `/me` and `PATCH /me` and deliberately has no SharedPreferences fallback.

Local profile values in `AppRepository` remain cache/UI state until the Android screens are migrated to the remote repository and a real backend is deployed.

This milestone does not claim live backend functionality; it establishes the client contract and fail-closed transport path.
