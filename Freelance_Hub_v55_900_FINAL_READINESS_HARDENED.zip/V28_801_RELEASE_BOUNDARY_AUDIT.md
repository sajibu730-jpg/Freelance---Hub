# Freelance Hub v28.801 release-boundary audit

- Release identity: 28.801.0 / versionCode 28801
- Backend configuration now rejects non-HTTPS endpoints, URL user-info, fragments, blank project IDs, and the example.com placeholder.
- Added focused unit coverage for the backend configuration boundary.
- Added XML parsing and placeholder/cleartext static checks to the release gate.
- GitHub Actions updated to current Java/Gradle action majors and explicitly installs Gradle 8.10.2 because this archive does not contain a Gradle Wrapper.
- Actual Gradle tests/build, signed APK/AAB, backend deployment, and real-device verification remain external execution steps.
