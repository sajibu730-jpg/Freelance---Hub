#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
APP="$ROOT/app/build.gradle.kts"
GATES="$ROOT/SECURITY_RELEASE_GATES.md"
LEDGER="$ROOT/V18_101_TO_V18_300_200_STEP_LEDGER.md"
DOC="$ROOT/V18_300_RELEASE_HARDENING.md"
[[ -f "$APP" && -f "$GATES" && -f "$LEDGER" && -f "$DOC" ]]
grep -q 'versionCode = 9300' "$APP"
grep -q 'versionName = "18.300.0"' "$APP"
grep -q 'backendBaseUrl' "$APP"
[[ "$(grep -cE '^[0-9]+\. v18\.[0-9]+ — checkpoint recorded$' "$LEDGER")" -eq 200 ]]
for marker in 'Authentication provider configured' 'Payment webhooks verified server-side' 'Signed AAB/APK build reproduced and smoke-tested'; do grep -Fq "$marker" "$GATES"; done
if grep -RInE '(AIza[0-9A-Za-z_-]{20,}|sk_live_[0-9A-Za-z_-]+|BEGIN (RSA|EC|OPENSSH) PRIVATE KEY)' "$ROOT" --exclude='*.sha256' >/dev/null; then
  echo 'Potential secret material detected' >&2; exit 1
fi
echo 'Freelance Hub v18.300 source/CI release-boundary verification: PASS'
