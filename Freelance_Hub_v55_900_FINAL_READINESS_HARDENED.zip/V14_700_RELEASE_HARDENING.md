# Freelance Hub v14.700 — Release Hardening Notes

This range advances the release-integrity baseline from v14.500 to v14.700.

## Hardening changes

- Adds a dedicated v14.501 → v14.700 continuity ledger with 200 verified version/code transitions.
- Makes the production workflow fail fast when required release-signing and backend configuration secrets are missing.
- Builds both a signed release APK and an Android App Bundle (AAB) in the production workflow.
- Verifies both release artifact signatures before evidence is generated.
- Keeps credentials out of source and records only non-secret release metadata in CI evidence.
- Updates the active version to v14.700.0 / versionCode 5890.

## Boundary

A source/CI gate PASS does not by itself prove that a real production backend is deployed, that a physical Android device has been tested, that Play Console testing has passed, or that the release has been published.
