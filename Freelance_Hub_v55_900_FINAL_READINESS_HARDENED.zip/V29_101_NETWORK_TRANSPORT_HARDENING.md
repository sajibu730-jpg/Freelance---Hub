# Freelance Hub v29.101 Network Transport Hardening

- Previous release: v29.100.0
- Current release: v29.101.0
- Version code: 29101

## Controls added
1. Disable transparent HTTP redirects in `SecureApiClient`.
2. Enforce a bounded response reader at the 2 MiB security limit.
3. Keep existing HTTPS, host, URL-credential, fragment, content-type, and status validation.
4. Update CI verification and production evidence to v29.101.

## Verification
The release gate checks the new redirect and response-limit controls in addition to the existing release boundary checks.
