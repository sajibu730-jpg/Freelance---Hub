# Freelance Hub v11.300 — Release Evidence Provenance Hardening

- Added a dedicated release evidence provenance gate.
- Workflows now require version/version-code, Git SHA, workflow run/attempt, UTC timestamp, and APK SHA-256 evidence metadata.
- Evidence generation is checked after successful build steps.
- Current release artifact naming and metadata were reconciled to v11.300.
- Production workflow now explicitly checks out the repository before verification/build steps.
- Source manifest and manifest root were regenerated for v11.300.
