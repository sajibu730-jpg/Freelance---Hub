# Authentication Integration Boundary — v9.600

## Implemented in the source package

- OpenAPI definitions for signup, login, refresh and logout.
- HTTPS transport validation in `SecureApiClient`.
- Bearer access-token header support.
- Request/response size and request-path validation.
- Local/demo repository state for prototype flows.

## Not yet production-complete

- Deployed authentication API.
- Password hashing/credential verification on the server.
- Refresh-token rotation and revocation in the deployed service.
- Server-issued identity/session integration in the Android UI.
- End-to-end authentication integration tests against a deployed environment.

## Rule

Local `SharedPreferences` state is not an authoritative production identity store. Production authorization decisions must be enforced by the backend using authenticated server-side identity and database authorization policies.
