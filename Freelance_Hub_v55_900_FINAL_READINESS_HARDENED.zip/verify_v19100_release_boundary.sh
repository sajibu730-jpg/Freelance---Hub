#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/app/build.gradle.kts"
LEDGER="$ROOT/V18_901_TO_V19_100_200_STEP_LEDGER.md"
DOC="$ROOT/V19_100_RELEASE_HARDENING.md"
PROD="$ROOT/.github/workflows/android-production.yml"
BUILD="$ROOT/.github/workflows/android-build.yml"
test -f "$APP" && test -f "$LEDGER" && test -f "$DOC" && test -f "$PROD" && test -f "$BUILD"
grep -q 'versionCode = 10100' "$APP"
grep -q 'versionName = "19.100.0"' "$APP"
test "$(grep -Ec '^[0-9]+\. v(18\.(9[0-9][0-9])|19\.(0[0-9]|[1-9][0-9]|100)) ' "$LEDGER")" -eq 200
! grep -R -n -E 'BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY' "$ROOT" --exclude='*.sha256' --exclude='verify_*.sh' >/dev/null
for wf in "$PROD" "$BUILD"; do
  grep -q '^permissions:' "$wf"
  grep -q '^  contents: read$' "$wf"
  grep -q '^  actions: read$' "$wf"
  ! grep -E -n '^[[:space:]]+uses: .*@(main|master|dev|develop|latest)$' "$wf" >/dev/null
  grep -q 'actions/checkout@v4' "$wf"
  checkout=$(grep -n 'actions/checkout@v4' "$wf" | head -1 | cut -d: -f1)
  gate=$(grep -n 'v19.100 source/CI release-boundary gate' "$wf" | head -1 | cut -d: -f1)
  test -n "$checkout" && test -n "$gate" && test "$checkout" -lt "$gate"
done
grep -q 'v19.100 provenance gate' "$PROD"
grep -q 'v19.100 provenance gate' "$BUILD"
echo 'Freelance Hub v19.100 source/CI release-boundary verification: PASS'
