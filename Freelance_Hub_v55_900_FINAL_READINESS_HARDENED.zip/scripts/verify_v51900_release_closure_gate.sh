#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
f(){ echo "FAIL: $*" >&2; exit 1; }; p(){ echo "PASS: $*"; }
[[ "$(cat VERSION.txt)" == '51.900.0' ]] || f 'VERSION.txt mismatch'
grep -Fq 'versionCode = 51900' app/build.gradle.kts || f 'Gradle versionCode mismatch'
grep -Fq 'versionName = "51.900.0"' app/build.gradle.kts || f 'Gradle versionName mismatch'
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do grep -Fq '51.900.0' "$wf" || f "version identity missing: $wf"; grep -Fq '51900' "$wf" || f "version code missing: $wf"; grep -Fq 'verify_v51900_release_closure_gate.sh' "$wf" || f "new closure gate missing: $wf"; done
for s in scripts/verify_v51900_*.sh; do [[ -x "$s" ]] || f "not executable: $s"; bash -n "$s" || f "syntax error: $s"; done
! grep -RInE 'BEGIN (RSA|EC|OPENSSH) PRIVATE KEY|sk_live_[A-Za-z0-9_-]+' .github/workflows backend ops scripts --exclude='*.sha256' >/dev/null 2>&1 || f 'credential/private-key pattern detected'
p 'v51.900 release identity, workflow closure, syntax and credential hygiene checks'
