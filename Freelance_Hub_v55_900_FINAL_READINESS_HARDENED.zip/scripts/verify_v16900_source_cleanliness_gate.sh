#!/usr/bin/env bash
set -euo pipefail
if find . -type f \( -name '*.jks' -o -name '*.keystore' -o -name '*.p12' \) -print -quit | grep -q .; then exit 1; fi
if grep -RIlE 'BEGIN (RSA|EC|OPENSSH) PRIVATE KEY|AIza[0-9A-Za-z_-]{20,}' . --exclude-dir=.git --exclude='*.md' | grep -q .; then exit 1; fi
echo 'v16.900 source cleanliness gate: PASS'
