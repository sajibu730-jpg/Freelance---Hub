#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LEDGER="$ROOT/V17_901_TO_V18_100_200_STEP_LEDGER.md"
DOC="$ROOT/V18_100_RELEASE_HARDENING.md"
GRADLE="$ROOT/app/build.gradle.kts"
test -f "$LEDGER" && test -f "$DOC" && test -f "$GRADLE"
grep -q 'versionCode = 9100' "$GRADLE"
grep -q 'versionName = "18.100.0"' "$GRADLE"
count=$(grep -Ec '^[0-9]+\. v' "$LEDGER")
test "$count" -eq 200
printf '%s\n' 'Freelance Hub v18.100 release-boundary gate: PASS'
