#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail(){ echo "FAIL: $*" >&2; exit 1; }
[[ "$(tr -d '\r\n' < "$ROOT/VERSION.txt")" == "55.900.0" ]] || fail 'VERSION.txt mismatch'
grep -Fq 'versionCode = 55900' "$ROOT/app/build.gradle.kts" || fail 'Gradle versionCode mismatch'
grep -Fq 'versionName = "55.900.0"' "$ROOT/app/build.gradle.kts" || fail 'Gradle versionName mismatch'
grep -Fq 'v55.401 → v55.900' "$ROOT/V55_401_TO_V55_900_500_STEP_LEDGER.md" || fail 'closure ledger missing'
grep -Fq '500 controlled checkpoints' "$ROOT/V55_401_TO_V55_900_500_STEP_LEDGER.md" || fail 'checkpoint count missing'
grep -Fq 'serverAuthorizedMutation' "$ROOT/app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityFinalRules.kt" || fail 'privileged-operation boundary missing'
grep -Fq 'aiMayFinalizeMarketplaceOutcome' "$ROOT/app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityFinalRules.kt" || fail 'AI boundary missing'
for wf in "$ROOT/.github/workflows/android-build.yml" "$ROOT/.github/workflows/android-production.yml"; do
  grep -Fq '55.900.0' "$wf" || fail "version identity missing: $wf"
  grep -Fq '55900' "$wf" || fail "versionCode missing: $wf"
  grep -Fq 'verify_v55900_closure_gate.sh' "$wf" || fail "closure gate missing: $wf"
done
! grep -RInE 'sk_(live|test)_[A-Za-z0-9]+|AKIA[0-9A-Z]{16}|-----BEGIN (RSA |EC )?PRIVATE KEY-----' "$ROOT/app" "$ROOT/backend" --exclude='*.sha256' >/dev/null || fail 'credential/private-key pattern found'
for s in "$ROOT"/scripts/verify_v55900_*.sh; do bash -n "$s" || fail "shell syntax: $s"; done
echo 'v55.900 closure source gate: PASS'
