#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
f(){ echo "FAIL: $*" >&2; exit 1; }; p(){ echo "PASS: $*"; }
D=backend/ACCOUNT_SESSION_RECOVERY_CONTRACT_V47_200.md
[[ -s "$D" ]] || f 'account/session recovery contract missing'
for t in 'verified recovery factor' 'rate-limited' 'revokes or rotates' 'cannot elevate' 'Closed/banned identity' 'fail-closed' 'idempotent'; do grep -Fqi "$t" "$D" || f "missing recovery control: $t"; done
for s in app/src/test/java/com/freelancehub/app/security/SessionSecurityRulesTest.kt app/src/test/java/com/freelancehub/app/security/AccountAccessRulesTest.kt app/src/test/java/com/freelancehub/app/security/AccountClosureIdentityRulesTest.kt; do [[ -s "$s" ]] || f "security regression test missing: $s"; done
p 'v51.900 account, session and recovery controls'
