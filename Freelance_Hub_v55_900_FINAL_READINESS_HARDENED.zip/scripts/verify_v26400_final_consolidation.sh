#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
grep -q 'versionCode = 26400' "$root/app/build.gradle.kts"
grep -q 'versionName = "26.400.0"' "$root/app/build.gradle.kts"
grep -qx '26.400.0' "$root/VERSION.txt"
test -f "$root/app/src/main/java/com/freelancehub/app/security/ModerationAuditRules.kt"
test -f "$root/app/src/test/java/com/freelancehub/app/security/ModerationAuditRulesTest.kt"
grep -q 'summary: Read-only moderation audit history' "$root/openapi.yaml"
count=$(grep -c '^    ModerationActionRequest:' "$root/openapi.yaml")
test "$count" -eq 1
! grep -RInE 'TODO|FIXME|IMPLEMENT_ME|YOUR_' "$root/app/src/main" "$root/.github/workflows" >/dev/null
echo 'Freelance Hub v26.400 final consolidation static audit: PASS'
