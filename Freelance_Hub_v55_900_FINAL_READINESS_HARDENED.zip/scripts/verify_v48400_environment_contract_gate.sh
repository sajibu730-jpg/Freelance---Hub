#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }
DOC=backend/PRODUCTION_ENVIRONMENT_CONTRACT_V47_200.md
[[ -s "$DOC" ]] || fail 'environment contract missing'
ENV=backend/.env.example
[[ -s "$ENV" ]] || fail 'env example missing'
for key in DATABASE_URL JWT_ISSUER JWT_AUDIENCE AUTH_PROVIDER; do grep -q "^${key}=" "$ENV" || fail "env example missing $key"; done
if [[ -f backend/.env ]]; then fail 'populated backend/.env must not be committed'; fi
if grep -RInE '(password|secret|token|private[_ -]?key)\s*[:=]\s*[A-Za-z0-9_./+=-]{12,}' backend app ops .github --include='*.yml' --include='*.yaml' --include='*.json' --include='*.properties' --include='*.gradle*' >/dev/null 2>&1; then
  fail 'possible populated credential assignment detected in deployment/source configuration'
fi
grep -Fq 'HTTPS only' "$DOC" || fail 'HTTPS-only requirement missing'
grep -Fq 'fail closed' "$DOC" || fail 'fail-closed startup requirement missing'
grep -Fq 'Android must communicate only with the API boundary' "$DOC" || fail 'API-only client boundary missing'
pass 'v48.400 production environment, secret hygiene and API boundary contract checks'
