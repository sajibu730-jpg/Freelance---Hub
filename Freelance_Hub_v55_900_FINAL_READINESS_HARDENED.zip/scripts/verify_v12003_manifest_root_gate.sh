#!/usr/bin/env bash
set -euo pipefail
manifest='SOURCE_RELEASE_MANIFEST_v12.003.sha256'; root='SOURCE_RELEASE_MANIFEST_v12.003.root.sha256'
test -f "$manifest"; test -f "$root"
test "$(cat "$root")" = "$(sha256sum "$manifest" | awk '{print $1}')"
bash scripts/verify_v12002_release_manifest_gate.sh
printf 'v12.003 manifest root gate: PASS\n'
