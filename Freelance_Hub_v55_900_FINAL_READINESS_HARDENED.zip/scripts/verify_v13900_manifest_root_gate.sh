#!/usr/bin/env bash
set -euo pipefail
manifest='SOURCE_RELEASE_MANIFEST_v13.900.sha256'; root='SOURCE_RELEASE_MANIFEST_v13.900.root.sha256'
test -f "$manifest"; test -f "$root"
test "$(cat "$root")" = "$(sha256sum "$manifest" | awk '{print $1}')"
bash scripts/verify_v13900_release_manifest_gate.sh
printf 'v13.900 manifest root gate: PASS\n'
