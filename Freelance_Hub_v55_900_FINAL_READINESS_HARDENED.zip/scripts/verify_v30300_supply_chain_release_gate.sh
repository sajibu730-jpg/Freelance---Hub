#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fail(){ echo "FAIL: $1" >&2; exit 1; }
cd "$ROOT"
test -f scripts/verify_v30200_dependency_provenance.sh || fail 'v30.200 gate missing'
test -f scripts/verify_v30100_release_reproducibility.sh || fail 'v30.100 gate missing'
# CI actions must be pinned to immutable major versions already approved by the project.
for f in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
  test -f "$f" || fail "$f missing"
  grep -Eq 'actions/checkout@v4' "$f" || fail "checkout action drift in $f"
  grep -Eq 'actions/setup-java@v5' "$f" || { [ "$f" = .github/workflows/android-build.yml ] || fail "setup-java action drift in $f"; }
done
grep -F 'gradle/actions/setup-gradle@v6' .github/workflows/android-build.yml >/dev/null || fail 'Gradle setup action drift'
grep -F 'gradle/actions/setup-gradle@v6' .github/workflows/android-production.yml >/dev/null || fail 'Gradle setup action drift'
# Do not allow credentials, keystores, or local environment files into the repository tree.
if find . -type f \( -name '*.jks' -o -name '*.keystore' -o -name 'service-account*.json' \) -not -path './.git/*' | grep -q .; then fail 'credential-bearing release file found in source tree'; fi
if find . -type f -name '.env' -not -path './.git/*' | grep -q .; then fail 'local .env file found in source tree'; fi
bash scripts/verify_v30200_dependency_provenance.sh >/dev/null
bash scripts/verify_v30100_release_reproducibility.sh >/dev/null
printf '%s\n' 'Freelance Hub v30.300 supply-chain release gate: PASS'
