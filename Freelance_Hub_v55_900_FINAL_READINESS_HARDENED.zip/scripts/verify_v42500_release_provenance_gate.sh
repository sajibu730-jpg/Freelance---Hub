#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
grep -Fx '42.500.0' VERSION.txt >/dev/null || fail 'VERSION.txt drift'
grep -F 'versionCode = 42500' app/build.gradle.kts >/dev/null || fail 'versionCode drift'
grep -F 'versionName = "42.500.0"' app/build.gradle.kts >/dev/null || fail 'versionName drift'
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
  grep -F 'id-token: write' "$wf" >/dev/null || fail "OIDC permission missing: $wf"
  grep -F 'attestations: write' "$wf" >/dev/null || fail "attestation permission missing: $wf"
  grep -F 'actions/attest-build-provenance@v2' "$wf" >/dev/null || fail "build provenance attestation missing: $wf"
done
PROD=.github/workflows/android-production.yml
grep -F 'subject-path: app/build/outputs/apk/release/*.apk' "$PROD" >/dev/null || fail 'production APK attestation missing'
grep -F 'subject-path: app/build/outputs/bundle/release/*.aab' "$PROD" >/dev/null || fail 'production AAB attestation missing'
if grep -RInE 'freelance-hub-v41\.3(00)-' .github/workflows >/dev/null 2>&1; then fail 'stale v41.300 artifact label detected'; fi
printf '%s\n' 'Freelance Hub v42.500 release provenance gate: PASS'
