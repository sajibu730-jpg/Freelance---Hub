#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
grep -F 'versionCode = 31100' app/build.gradle.kts >/dev/null || fail 'versionCode drift'
grep -F 'versionName = "31.100.0"' app/build.gradle.kts >/dev/null || fail 'versionName drift'
grep -Fx '31.100.0' VERSION.txt >/dev/null || fail 'VERSION.txt drift'
for f in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
  test -f "$f" || fail "missing workflow $f"
  grep -F 'verify_v31100_final_production_boundary.sh' "$f" >/dev/null || fail "final gate missing from $f"
done
printf '%s\n' 'Freelance Hub v31.100 artifact integrity gate: PASS'
