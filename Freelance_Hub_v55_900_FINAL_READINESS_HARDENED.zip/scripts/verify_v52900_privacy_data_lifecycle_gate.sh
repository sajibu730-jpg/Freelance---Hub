#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
f(){ echo "FAIL: $*" >&2; exit 1; }; p(){ echo "PASS: $*"; }
D=backend/PRIVACY_DATA_LIFECYCLE_CONTRACT_V47_200.md
[[ -s "$D" ]] || f 'privacy lifecycle contract missing'
for t in 'purpose'  'Data export' 'Deletion requests' 'Rectification' 'Retention' 'AI work-analysis inputs' 'Fail-closed'; do grep -Fqi "$t" "$D" || f "missing privacy control: $t"; done
for s in app/src/main/java/com/freelancehub/app/data/PrivacyOperationalAssuranceRules.kt app/src/test/java/com/freelancehub/app/data/PrivacyOperationalAssuranceRulesTest.kt; do [[ -s "$s" ]] || f "privacy assurance source missing: $s"; done
p 'v52.900 privacy and data lifecycle controls'
