#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }
DOC=backend/PAYMENT_RECONCILIATION_CONTRACT_V47_200.md
SCHEMA=BACKEND_SCHEMA.sql
[[ -s "$DOC" ]] || fail 'payment reconciliation contract missing'
[[ -s "$SCHEMA" ]] || fail 'schema missing'
[[ -s backend/RECONCILIATION_READ_ONLY_QUERIES_V47_200.sql ]] || fail 'read-only reconciliation query pack missing'
for token in \
  'Every payment has exactly one contract' \
  'provider webhook event IDs are unique' \
  'A refund cannot exceed the original payment amount' \
  'Replayed webhook events must not create a second financial effect' \
  'currency mismatches' \
  'state mismatches'; do
  grep -Fq "$token" "$DOC" || fail "reconciliation invariant missing: $token"
done
for token in \
  'idempotency_key TEXT NOT NULL UNIQUE' \
  'UNIQUE(provider, provider_event_id)' \
  'NEW.amount_minor > p_amount' \
  'payment contract not found' \
  'ledger payment not found'; do
  grep -Fq "$token" "$SCHEMA" || fail "schema financial primitive missing: $token"
done
pass 'v55.900 payment reconciliation, refund ceiling, idempotency and ledger invariant contract checks'

if grep -nEi '^\s*(INSERT|UPDATE|DELETE|DROP|TRUNCATE|ALTER|CREATE)\b' backend/RECONCILIATION_READ_ONLY_QUERIES_V47_200.sql >/dev/null; then fail 'reconciliation query pack must remain read-only'; fi
for q in 'HAVING COUNT(*) > 1' 'completed_refund_minor' 'IS DISTINCT FROM' 'signature_verified = TRUE'; do grep -Fq "$q" backend/RECONCILIATION_READ_ONLY_QUERIES_V47_200.sql || fail "reconciliation query missing: $q"; done
pass 'v55.900 read-only reconciliation query pack is present and non-destructive'
