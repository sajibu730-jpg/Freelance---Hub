#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
grep -q '55.400.0' VERSION.txt
grep -q 'versionCode = 55400' app/build.gradle.kts
grep -q 'versionName = "55.400.0"' app/build.gradle.kts
test -f app/src/main/java/com/freelancehub/app/data/TransactionIntegrityRules.kt
test -f app/src/test/java/com/freelancehub/app/data/TransactionIntegrityRulesTest.kt
grep -q 'clientMayFinalizeTransaction(): Boolean = false' app/src/main/java/com/freelancehub/app/data/TransactionIntegrityRules.kt
grep -q 'aiMayFinalizeTransaction(): Boolean = false' app/src/main/java/com/freelancehub/app/data/TransactionIntegrityRules.kt
grep -q 'duplicateEventMustBeNoOp' app/src/main/java/com/freelancehub/app/data/TransactionIntegrityRules.kt
echo 'v55.400 transaction integrity source gate: PASS'
