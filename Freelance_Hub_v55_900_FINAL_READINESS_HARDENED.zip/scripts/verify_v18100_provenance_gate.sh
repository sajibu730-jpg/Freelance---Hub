#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
for f in "$ROOT/V17_900_RELEASE_HARDENING.md" "$ROOT/V17_901_TO_V18_100_200_STEP_LEDGER.md" "$ROOT/V18_100_RELEASE_HARDENING.md" "$ROOT/scripts/verify_v17900_release_boundary.sh" "$ROOT/scripts/verify_v18100_release_boundary.sh"; do test -f "$f"; done
sha256sum "$ROOT/V18_100_RELEASE_HARDENING.md" "$ROOT/V17_901_TO_V18_100_200_STEP_LEDGER.md"
echo 'Freelance Hub v18.100 provenance gate: PASS'
