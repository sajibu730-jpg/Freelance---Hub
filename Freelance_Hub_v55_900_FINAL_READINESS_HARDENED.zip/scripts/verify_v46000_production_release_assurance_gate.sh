#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }

[[ -f VERSION.txt ]] || fail "VERSION.txt missing"
[[ "$(tr -d '\r\n' < VERSION.txt)" == "46.000.0" ]] || fail "VERSION.txt is not 46.000.0"
grep -q 'versionCode = 46000' app/build.gradle.kts || fail "versionCode is not 46000"
grep -q 'versionName = "46.000.0"' app/build.gradle.kts || fail "versionName is not 46.000.0"

for f in \
  V43_801_TO_V44_000_CI_OPERATIONAL_INTEGRITY.md \
  RELEASE_V44_000_CHANGELOG.md \
  ops/runbooks/CI_OPERATIONAL_INTEGRITY_V44_000.md \
  V44_401_TO_V46_000_PRODUCTION_READINESS_HARDENING.md \
  RELEASE_V46_000_CHANGELOG.md \
  ops/runbooks/RELEASE_ASSURANCE_V46_000.md; do
  [[ -s "$f" ]] || fail "required artifact missing/empty: $f"
done

# No stale production release identity may remain in the active production workflow.
WF=.github/workflows/android-production.yml
[[ -s "$WF" ]] || fail "production workflow missing"
if grep -nE 'v43\.400|v43\.800|Version: 43\.400\.0|Version: 43\.800.0|Version Code: 43400|Version Code: 43800|v42\.700-production-release' "$WF" >/dev/null; then
  fail "stale production version identity found in active workflow"
fi
grep -q '46.000' "$WF" || fail "production workflow does not identify v46.000"

grep -q 'FREELANCE_HUB_BACKEND_BASE_URL' "$WF" || fail "production backend secret is not required"
grep -q 'FREELANCE_HUB_RELEASE_KEYSTORE_B64' "$WF" || fail "production signing secret is not required"

# Reject embedded high-risk credentials/private keys.
if grep -RInE '(BEGIN (RSA|EC|OPENSSH) PRIVATE KEY|sk_live_[A-Za-z0-9_-]+|AKIA[0-9A-Z]{16})' \
  app backend ops .github scripts --exclude='*.sha256' >/dev/null 2>&1; then
  fail "credential/private-key material detected"
fi

# Ensure logs/runbooks explicitly preserve financial evidence and prohibit secret logging.
grep -qi 'Logs must avoid passwords' backend/OBSERVABILITY_HEALTH_CONTRACT_V46_000.md || fail "sensitive logging rule missing"
grep -qi 'reconciliation' backend/PAYMENT_RECONCILIATION_CONTRACT_V46_000.md || fail "financial reconciliation rule missing"

# Baseline schema remains non-destructive.
if grep -nEi '^\s*(DROP\s+TABLE|TRUNCATE\b|DELETE\s+FROM\s+[A-Za-z_][A-Za-z0-9_]*\s*;)' BACKEND_SCHEMA.sql >/dev/null; then
  fail "forbidden destructive database operation found in baseline schema"
fi

pass "v46.000 production release assurance, migration/recovery, reconciliation, observability and artifact consistency checks"
