#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
bash scripts/verify_v41200_financial_rls_closure_gate.sh >/dev/null
echo 'PASS: v42.700 financial RLS closure gate'
