#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
test "$(cat "$root/VERSION.txt")" = "53.900.0"
grep -q 'versionCode = 53900' "$root/app/build.gradle.kts"
grep -q 'versionName = "53.900.0"' "$root/app/build.gradle.kts"
test -f "$root/app/src/main/java/com/freelancehub/app/data/MarketplaceGovernanceRules.kt"
test -f "$root/V49_901_TO_V51_400_GOVERNANCE_LEDGER.md"
count=$(grep -c '^\- Checkpoint ' "$root/V49_901_TO_V51_400_GOVERNANCE_LEDGER.md")
test "$count" -eq 500
grep -q 'v53900' "$root/.github/workflows/android-build.yml"
grep -q 'v53900' "$root/.github/workflows/android-production.yml"
echo 'v53.900 governance source gate: PASS'
