#!/usr/bin/env bash
set -euo pipefail

# Keep production dependencies explicit and auditable.
grep -q 'androidx.compose:compose-bom:2024.12.01' app/build.gradle.kts
grep -q 'androidx.activity:activity-compose:1.10.0' app/build.gradle.kts
grep -q 'com.google.android.play:app-update:2.1.0' app/build.gradle.kts

# No wildcard/dynamic dependency declarations in the production module.
if grep -EIn 'implementation\([^)]*:[^:()]+:(latest|release|\+)' app/build.gradle.kts >/dev/null 2>&1; then
  echo 'Dynamic production dependency found.' >&2
  exit 1
fi

# No local secret/key material may be tracked in the release source tree.
if find . -type f \( -name '*.jks' -o -name '*.keystore' -o -name '*.p12' \) -not -path './.git/*' | grep -q .; then
  echo 'Signing key material is present in source tree.' >&2
  exit 1
fi

if find . -type f \( -name '.env' -o -name '*.pem' -o -name '*.key' \) -not -path './.git/*' | grep -q .; then
  echo 'Potential secret material is present in source tree.' >&2
  exit 1
fi

echo 'PASS: v42.700 dependency and secret-material policy gate'
