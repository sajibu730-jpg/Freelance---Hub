#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
for d in .gradle build app/build .idea; do test ! -e "$d" || { echo "Forbidden generated directory present: $d" >&2; exit 1; }; done
for f in local.properties gradle.properties.keystore keystore.jks release.jks debug.keystore; do test ! -e "$f" || { echo "Forbidden local/signing file present: $f" >&2; exit 1; }; done
if find . -type f \( -name '*.jks' -o -name '*.keystore' -o -name '*.p12' \) -print -quit | grep -q .; then echo 'Signing material found in source tree' >&2; exit 1; fi
if find . -type f \( -name '*.apk' -o -name '*.aab' \) -print -quit | grep -q .; then echo 'Generated release artifact found in source tree' >&2; exit 1; fi
printf 'v15.700 source cleanliness gate: PASS\n'
