#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
grep -q "55.900.0" VERSION.txt
grep -q "versionCode = 55900" app/build.gradle.kts
grep -q "versionName = \"55.900.0\"" app/build.gradle.kts
test -f app/src/main/java/com/freelancehub/app/data/OperationalRecoveryRules.kt
test -f app/src/test/java/com/freelancehub/app/data/OperationalRecoveryRulesTest.kt
grep -q 'MAX_AUTOMATIC_RETRIES = 3' app/src/main/java/com/freelancehub/app/data/OperationalRecoveryRules.kt
grep -q 'clientMayPromoteRecovery(): Boolean = false' app/src/main/java/com/freelancehub/app/data/OperationalRecoveryRules.kt
grep -q 'aiMayPromoteRecovery(): Boolean = false' app/src/main/java/com/freelancehub/app/data/OperationalRecoveryRules.kt
echo 'v55.900 operational recovery source gate: PASS'
