#!/usr/bin/env bash
set -euo pipefail
manifest='SOURCE_RELEASE_MANIFEST_v11.100.sha256'
root='SOURCE_RELEASE_MANIFEST_v11.100.root.sha256'
test -f "$manifest"
test -f "$root"
# Root commits the exact manifest bytes; both files are intentionally excluded from the manifest itself.
expected="$(awk '{print $1}' "$root")"
actual="$(sha256sum "$manifest" | awk '{print $1}')"
test "$expected" = "$actual"
# Entries must be canonical, unique, sorted, and point to regular files.
count="$(grep -Ec '^[0-9a-f]{64}  \./.+$' "$manifest")"
test "$count" -gt 0
test "$(awk '{print $2}' "$manifest" | sort | uniq -d | wc -l | tr -d ' ')" -eq 0
test "$(awk '{print $2}' "$manifest" | sort | uniq | cmp -s - <(awk '{print $2}' "$manifest") && echo 1 || echo 0)" -eq 1
! awk '{print $2}' "$manifest" | grep -Eq '(^|/)SOURCE_RELEASE_MANIFEST_v[0-9]+\.[0-9]+\.(sha256|root\.sha256)$'
while IFS= read -r entry; do test -f "${entry#*  }"; done < "$manifest"
grep -Fq 'Version: 11.100.0' VERSION.txt
grep -Fq 'Version Code: 3010' VERSION.txt
grep -Fq 'versionCode = 3010' app/build.gradle.kts
grep -Fq 'versionName = "11.100.0"' app/build.gradle.kts
printf 'v11.100 release manifest root integrity gate: PASS (%s entries)\n' "$count"
