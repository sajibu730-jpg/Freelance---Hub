#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }
DOC=backend/OBSERVABILITY_HEALTH_CONTRACT_V47_200.md
[[ -s "$DOC" ]] || fail 'observability/health contract missing'
for token in 'process/liveness' 'database connectivity/readiness' 'payment provider dependency readiness' 'request ID propagation' 'idempotency conflicts/replays' 'migration/restore events' 'Logs must avoid passwords'; do
  grep -Fq "$token" "$DOC" || fail "observability requirement missing: $token"
done
if grep -RInE 'Authorization: Bearer|password=|secret=|PRIVATE KEY' backend ops --include='*.md' >/dev/null 2>&1; then
  fail 'sensitive logging/credential pattern found in operational documentation'
fi
pass 'v52.900 observability, health dependency and sensitive-log boundary checks'
