#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
grep -F 'versionCode = 31700' app/build.gradle.kts >/dev/null || fail 'versionCode drift'
grep -F 'versionName = "31.700.0"' app/build.gradle.kts >/dev/null || fail 'versionName drift'
grep -Fx '31.700.0' VERSION.txt >/dev/null || fail 'VERSION.txt drift'
test -f V31_401_TO_V31_700_300_STEP_HARDENING_LEDGER.md || fail 'ledger missing'
for f in .github/workflows/android-build.yml .github/workflows/android-production.yml; do test -f "$f" || fail "missing workflow $f"; grep -F 'verify_v31700_final_production_boundary.sh' "$f" >/dev/null || fail "final gate missing from $f"; done
printf '%s\n' 'Freelance Hub v31.700 artifact integrity gate: PASS'
