#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
test "$(cat "$root/VERSION.txt")" = "51.400.0"
grep -q 'versionCode = 51400' "$root/app/build.gradle.kts"
grep -q 'versionName = "51.400.0"' "$root/app/build.gradle.kts"
test -f "$root/app/src/main/java/com/freelancehub/app/data/MarketplaceGovernanceRules.kt"
test -f "$root/V49_901_TO_V51_400_GOVERNANCE_LEDGER.md"
count=$(grep -c '^\- Checkpoint ' "$root/V49_901_TO_V51_400_GOVERNANCE_LEDGER.md")
test "$count" -eq 500
grep -q 'v51400' "$root/.github/workflows/android-build.yml"
grep -q 'v51400' "$root/.github/workflows/android-production.yml"
echo 'v51.400 governance source gate: PASS'
