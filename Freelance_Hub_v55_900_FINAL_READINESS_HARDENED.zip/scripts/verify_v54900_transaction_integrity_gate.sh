#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
grep -q '54.900.0' VERSION.txt
grep -q 'versionCode = 54900' app/build.gradle.kts
grep -q 'versionName = "54.900.0"' app/build.gradle.kts
test -f app/src/main/java/com/freelancehub/app/data/TransactionIntegrityRules.kt
test -f app/src/test/java/com/freelancehub/app/data/TransactionIntegrityRulesTest.kt
grep -q 'clientMayFinalizeTransaction(): Boolean = false' app/src/main/java/com/freelancehub/app/data/TransactionIntegrityRules.kt
grep -q 'aiMayFinalizeTransaction(): Boolean = false' app/src/main/java/com/freelancehub/app/data/TransactionIntegrityRules.kt
grep -q 'duplicateEventMustBeNoOp' app/src/main/java/com/freelancehub/app/data/TransactionIntegrityRules.kt
echo 'v54.900 transaction integrity source gate: PASS'
