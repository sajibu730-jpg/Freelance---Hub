#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
grep -q '53.900.0' VERSION.txt
grep -q 'versionCode = 53900' app/build.gradle.kts
grep -q 'versionName = "53.900.0"' app/build.gradle.kts
test -f app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityRules.kt
test -f app/src/test/java/com/freelancehub/app/data/MarketplaceIntegrityRulesTest.kt
grep -q 'NORMAL_HIRING_WINDOW_HOURS = 24' app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityRules.kt
grep -q 'EMERGENCY_FREELANCERS_PER_PHASE = 50' app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityRules.kt
grep -q 'aiMayFinalizeMarketplaceOutcome(): Boolean = false' app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityRules.kt
echo 'v53.900 marketplace integrity source gate: PASS'
