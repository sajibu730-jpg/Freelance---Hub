#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
f(){ echo "FAIL: $*" >&2; exit 1; }; p(){ echo "PASS: $*"; }
D=backend/CLIENT_RESILIENCE_ACCESSIBILITY_CONTRACT_V47_200.md
[[ -s "$D" ]] || f 'resilience/accessibility contract missing'
for t in 'must never silently succeed offline' 'Retries are bounded' 'idempotency key' 'Stable error codes/messages' 'meaningful labels' 'not conveyed by color alone' 'Sensitive values are masked'; do grep -Fqi "$t" "$D" || f "missing resilience/accessibility control: $t"; done
for s in app/src/test/java/com/freelancehub/app/security/ApiRetryRulesTest.kt app/src/test/java/com/freelancehub/app/security/ApiResponseSecurityRulesTest.kt app/src/test/java/com/freelancehub/app/security/CheckoutRecoveryRulesTest.kt; do [[ -s "$s" ]] || f "client safety regression test missing: $s"; done
p 'v54.900 client resilience and accessibility controls'
