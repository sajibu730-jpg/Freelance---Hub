#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

test "$(grep -Fc 'Version: 9.700.0' VERSION.txt)" -eq 1
test "$(grep -Fc 'Version Code: 2850' VERSION.txt)" -eq 1
grep -Fq 'versionCode = 2850' app/build.gradle.kts
grep -Fq 'versionName = "9.700.0"' app/build.gradle.kts
test -f scripts/verify_v9700_contract_integrity_gate.sh
test -f RELEASE_VERIFICATION_V9_700.md
test -f V9_700_WORK_SUMMARY.md
test -s SOURCE_RELEASE_MANIFEST_v9.700.sha256

for WF in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
  test -f "$WF"
  grep -Fq 'v9.700 contract-integrity gate' "$WF"
  grep -Fq 'verify_v9700_contract_integrity_gate.sh' "$WF"
done

# Active workflows must not invoke historical v9 release gates.
if grep -RInE 'verify_v9[0-9]{3}.*gate\.sh' .github/workflows | grep -v 'verify_v9700_contract_integrity_gate.sh'; then
  echo 'Historical v9 release gate still active' >&2
  exit 1
fi

# Build/evidence identity and hardening.
grep -Fq "java-version: '17'" .github/workflows/android-build.yml
grep -Fq "gradle-version: '8.10.2'" .github/workflows/android-build.yml
grep -Fq 'gradle --no-daemon test' .github/workflows/android-build.yml
grep -Fq 'gradle --no-daemon assembleRelease' .github/workflows/android-build.yml
grep -Fq 'actions/upload-artifact@v4' .github/workflows/android-build.yml
grep -Fq 'freelance-hub-v9.700-verification-evidence' .github/workflows/android-build.yml
grep -Fq 'Version: 9.700.0' .github/workflows/android-build.yml
grep -Fq 'Version Code: 2850' .github/workflows/android-build.yml
grep -Fq 'isMinifyEnabled = true' app/build.gradle.kts
grep -Fq 'isShrinkResources = true' app/build.gradle.kts
grep -Fq 'jvmToolchain(17)' app/build.gradle.kts

# Contract integrity source controls.
grep -Fq 'enforce_contract_integrity' BACKEND_SCHEMA.sql
grep -Fq 'enforce_contract_status_transition' BACKEND_SCHEMA.sql
test -f app/src/main/java/com/freelancehub/app/data/ContractLifecycleRules.kt
test -f app/src/test/java/com/freelancehub/app/data/ContractLifecycleRulesTest.kt

# Manifest exact inventory and hashes.
awk 'NF==2 && $1 ~ /^[0-9a-f]{64}$/ {print $2}' SOURCE_RELEASE_MANIFEST_v9.700.sha256 > /tmp/fh_manifest_paths.txt
test -s SOURCE_RELEASE_MANIFEST_v9.700.sha256
test "$(sort /tmp/fh_manifest_paths.txt | uniq | wc -l)" -eq "$(wc -l < /tmp/fh_manifest_paths.txt)"
while IFS= read -r f; do test -f "$f"; done < /tmp/fh_manifest_paths.txt
sha256sum -c SOURCE_RELEASE_MANIFEST_v9.700.sha256 >/dev/null
find . -type f -not -path './.git/*' -not -path './app/build/*' -not -path './SOURCE_RELEASE_MANIFEST_v9.700.sha256' -print | sed 's#^./##' | sort > /tmp/fh_actual_paths.txt
sort /tmp/fh_manifest_paths.txt > /tmp/fh_manifest_paths_sorted.txt
cmp -s /tmp/fh_actual_paths.txt /tmp/fh_manifest_paths_sorted.txt || { echo 'Source manifest inventory mismatch' >&2; exit 1; }

while IFS= read -r -d '' f; do bash -n "$f"; done < <(find scripts -type f -name '*.sh' -print0)
if grep -RInE 'BEGIN (RSA|OPENSSH|EC|PRIVATE) KEY|AKIA[0-9A-Z]{16}|sk_live_[A-Za-z0-9]+' --exclude-dir=.git --exclude='*.zip' .; then
  echo 'Potential credential material found' >&2
  exit 1
fi

grep -Fq 'FREELANCE_HUB_BACKEND_BASE_URL' .github/workflows/android-production.yml
grep -Fq 'FREELANCE_HUB_RELEASE_KEYSTORE_B64' .github/workflows/android-production.yml
grep -Fq 'apksigner verify --verbose' .github/workflows/android-production.yml
grep -Fq 'Actual APK/AAB compilation' README.md
grep -Fq 'real-device' README.md
grep -Fq 'Play Console' README.md

echo 'v9.700 contract-integrity gate: PASS'
