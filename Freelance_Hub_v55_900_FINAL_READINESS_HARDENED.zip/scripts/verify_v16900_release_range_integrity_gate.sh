#!/usr/bin/env bash
set -euo pipefail
[[ -f VERSION.txt ]]
grep -qx 'Version: 16.900.0' VERSION.txt
grep -qx 'Version Code: 8090' VERSION.txt
grep -q 'versionCode = 8090' app/build.gradle.kts
grep -q 'versionName = "16.900.0"' app/build.gradle.kts
echo 'v16.900 release range integrity gate: PASS'
