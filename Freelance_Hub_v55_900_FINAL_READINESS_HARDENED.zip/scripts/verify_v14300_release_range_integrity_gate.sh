#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
ledger=V14_101_TO_V14_300_200_STEP_LEDGER.md
test -s "$ledger"
python3 - "$ledger" <<'PY2'
import re,sys
rows=[]
for line in open(sys.argv[1],encoding="utf-8"):
 m=re.match(r"^\|\s*(\d+)\s*\|\s*v(14\.\d{3})\.0\s*\|\s*(\d+)\s*\|\s*PASS\s*\|",line)
 if m: rows.append((int(m.group(1)),m.group(2),int(m.group(3))))
assert len(rows)==200
for i,(step,ver,code) in enumerate(rows,1):
 expected=f"14.{100+i:03d}"
 assert (step,ver,code)==(i,expected,5290+i)
assert rows[0]==(1,"14.101",5291) and rows[-1]==(200,"14.300",5490)
assert len({r[1] for r in rows})==len({r[2] for r in rows})==200
PY2
grep -Fxq "Version: 14.300.0" VERSION.txt
grep -Fxq "Version Code: 5490" VERSION.txt
grep -Eq "versionCode[[:space:]]*=[[:space:]]*5490.*versionName[[:space:]]*=.*14.300.0" app/build.gradle.kts
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
 test -s "$wf"; grep -Fq "v14.300 release range integrity gate" "$wf"; grep -Fq "14.300.0" "$wf"; grep -Fq "5490" "$wf"; ! grep -Eq "v14\.100|v13\.900|v13\.700|v13\.500|v13\.300|v13\.100|v12\.900" "$wf";
done
printf "v14.300 range integrity gate: PASS (200 transitions; v14.101 -> v14.300)\n"
