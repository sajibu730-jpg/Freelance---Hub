#!/usr/bin/env bash
set -euo pipefail
version='11.600.0'
code='3060'
evidence_dir="${1:-app/build/outputs/apk/release}"
test -d "$evidence_dir"
for f in BUILD_METADATA.txt SHA256SUMS.txt RELEASE_EVIDENCE_INDEX.txt; do test -f "$evidence_dir/$f"; done
mapfile -t apks < <(find "$evidence_dir" -maxdepth 1 -type f -name '*.apk' -printf '%f\n' | sort)
test "${#apks[@]}" -ge 1
# Every APK must be present exactly once in SHA256SUMS and its digest must match the file.
for apk in "${apks[@]}"; do
  test "$(grep -Ec "^[0-9a-f]{64}  ${apk//./\.}$" "$evidence_dir/SHA256SUMS.txt")" -eq 1
  expected=$(awk -v f="$apk" '$2==f{print $1}' "$evidence_dir/SHA256SUMS.txt")
  actual=$(sha256sum "$evidence_dir/$apk" | awk '{print $1}')
  test "$expected" = "$actual"
done
# Evidence metadata must match the release and provenance formats.
grep -Fq "Version: $version" "$evidence_dir/BUILD_METADATA.txt"
grep -Fq "Version Code: $code" "$evidence_dir/BUILD_METADATA.txt"
grep -Eq '^Git SHA: [0-9a-f]{40}$' "$evidence_dir/BUILD_METADATA.txt"
grep -Eq '^Workflow Run: [0-9]+$' "$evidence_dir/BUILD_METADATA.txt"
grep -Eq '^Workflow Attempt: [0-9]+$' "$evidence_dir/BUILD_METADATA.txt"
grep -Eq '^UTC: [0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$' "$evidence_dir/BUILD_METADATA.txt"
# The evidence index binds APK filenames, byte sizes, APK SHA-256 values, and evidence-file hashes.
grep -Fq "Evidence Version: $version" "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt"
grep -Fq "Evidence Version Code: $code" "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt"
for apk in "${apks[@]}"; do
  size=$(stat -c '%s' "$evidence_dir/$apk")
  sha=$(sha256sum "$evidence_dir/$apk" | awk '{print $1}')
  grep -Fq "APK: $apk | Size: $size | SHA256: $sha" "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt"
done
for f in BUILD_METADATA.txt SHA256SUMS.txt; do
  sha=$(sha256sum "$evidence_dir/$f" | awk '{print $1}')
  grep -Fq "Evidence File: $f | SHA256: $sha" "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt"
done
printf 'v11.600 release evidence index self-check: PASS\n'
