#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }

[[ -f VERSION.txt ]] || fail "VERSION.txt missing"
[[ "$(tr -d '\r\n' < VERSION.txt)" == "44.000.0" ]] || fail "VERSION.txt is not 44.000.0"
grep -q 'versionCode = 44000' app/build.gradle.kts || fail "Gradle versionCode is not 44000"
grep -q 'versionName = "44.000.0"' app/build.gradle.kts || fail "Gradle versionName is not 44.000.0"

for wf in .github/workflows/*.yml; do
  [[ -s "$wf" ]] || fail "empty workflow: $wf"
  while IFS= read -r ref; do
    script="${ref#./}"
    [[ -f "$script" ]] || fail "workflow $wf references missing script: $script"
    [[ -x "$script" ]] || fail "workflow $wf references non-executable script: $script"
  done < <(grep -oE 'scripts/[A-Za-z0-9_.-]+\.sh' "$wf" | sort -u)
done

# Live workflows must not carry stale release identities.
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
  if grep -nE 'v43\.400|v43\.800|Version: 43\.400\.0|Version: 43\.800\.0|Version Code: 43400|Version Code: 43800|v42\.700-production-release' "$wf" >/dev/null; then
    fail "stale release identity found in $wf"
  fi
done

# Current release identity must appear in active workflows.
grep -q '44\.000\.0' .github/workflows/android-build.yml || fail "android-build workflow missing current version"
grep -q '44\.000\.0' .github/workflows/android-production.yml || fail "android-production workflow missing current version"
grep -q '44000' .github/workflows/android-build.yml || fail "android-build workflow missing current version code"
grep -q '44000' .github/workflows/android-production.yml || fail "android-production workflow missing current version code"

# Reject high-risk embedded credential material.
if grep -RInE '(BEGIN (RSA|EC|OPENSSH) PRIVATE KEY|sk_live_[A-Za-z0-9_-]+|AKIA[0-9A-Z]{16})' \
  app backend ops .github scripts --exclude='*.sha256' >/dev/null 2>&1; then
  fail "credential/private-key material detected"
fi

pass "v44.000 CI operational integrity, workflow-reference, release-identity and credential-hygiene checks"
