#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }
[[ "$(cat VERSION.txt)" == '53.400.0' ]] || fail 'VERSION.txt is not 53.400.0'
grep -q 'versionCode = 53400' app/build.gradle.kts || fail 'Gradle versionCode is not 53400'
grep -q 'versionName = "53.400.0"' app/build.gradle.kts || fail 'Gradle versionName is not 53.400.0'
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
  [[ -s "$wf" ]] || fail "workflow missing: $wf"
  grep -Fq 'verify_v53400_api_contract_gate.sh' "$wf" || fail "API contract gate not wired: $wf"
  grep -Fq 'verify_v53400_reconciliation_fixture_gate.sh' "$wf" || fail "reconciliation gate not wired: $wf"
done
if grep -RInE 'v44\.800|44\.800\.0|44800|verify_v44800' .github/workflows >/dev/null 2>&1; then fail 'stale v44.800 release identity remains in active workflows'; fi
if grep -RInE '(BEGIN (RSA|EC|OPENSSH|PRIVATE) KEY|AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{20,})' .github backend app scripts ops --exclude='*.sha256' >/dev/null 2>&1; then fail 'credential/private-key pattern found'; fi
pass 'v53.400 operational closure, version identity, workflow wiring and credential-hygiene checks'
