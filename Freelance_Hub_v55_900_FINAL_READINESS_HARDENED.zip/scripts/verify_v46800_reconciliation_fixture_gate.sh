#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }
SQL=backend/RECONCILIATION_INVARIANT_FIXTURES_V46_800.sql
[[ -s "$SQL" ]] || fail 'reconciliation invariant fixture file missing'
if grep -nEi '^\s*(INSERT|UPDATE|DELETE|DROP|TRUNCATE|ALTER|CREATE|GRANT|REVOKE)\b' "$SQL" >/dev/null; then
  fail 'fixture SQL must remain read-only'
fi
for token in 'COUNT(*) > 1' 'refund_amount_minor > payment_amount_minor' 'IS DISTINCT FROM' 'COUNT(DISTINCT request_hash) > 1' 'FROM payment_webhook_events'; do
  grep -Fq "$token" "$SQL" || fail "fixture invariant missing: $token"
done
pass 'v46.800 payment/refund/currency/idempotency/webhook invariant fixtures are read-only'
