#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
for f in "$ROOT/V20_300_RELEASE_HARDENING.md" "$ROOT/V20_301_TO_V20_500_200_STEP_LEDGER.md" "$ROOT/V20_500_RELEASE_HARDENING.md" "$ROOT/scripts/verify_v20300_release_boundary.sh" "$ROOT/scripts/verify_v20500_release_boundary.sh"; do test -f "$f"; done
sha256sum "$ROOT/V20_500_RELEASE_HARDENING.md" "$ROOT/V20_301_TO_V20_500_200_STEP_LEDGER.md" "$ROOT/scripts/verify_v20500_release_boundary.sh"
echo 'Freelance Hub v20.500 provenance gate: PASS'
