#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
for f in README.md V34_700_RELEASE_VERIFICATION.md; do test -f "$f" || true; done
# Verify the repository still documents the required production boundary terms.
for term in 'HTTPS' 'BACKEND_BASE_URL' 'BACKEND_PROJECT_ID' 'recovery'; do grep -R -i -m1 --exclude-dir=.git --exclude='*.zip' "$term" . >/dev/null || fail "required boundary term missing: $term"; done
printf '%s\n' 'Freelance Hub v35.000 deployment/recovery boundary gate: PASS'
