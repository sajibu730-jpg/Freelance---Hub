#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
grep -q '28.200.0' "$ROOT/VERSION.txt"
grep -q 'versionCode = 28200' "$ROOT/app/build.gradle.kts"
grep -q 'ModerationAuditExportRedactionRules' "$ROOT/app/src/main/java/com/freelancehub/app/security/ModerationAuditExportRedactionRules.kt"
grep -q 'fields: { type: array' "$ROOT/openapi.yaml"
! grep -R -nE 'TODO|FIXME|IMPLEMENT_ME|YOUR_' "$ROOT/app/src/main/java" "$ROOT/app/src/main/res" "$ROOT/.github/workflows" >/dev/null
python - <<'PY'
from pathlib import Path
try:
 import yaml
 yaml.safe_load(Path(Path.cwd()/'openapi.yaml').read_text())
except Exception as e:
 print(e); raise SystemExit(1)
PY
echo 'Freelance Hub v28.200 final consolidation static audit: PASS'
