#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
grep -F 'https://' .github/workflows/android-production.yml >/dev/null || fail 'HTTPS production boundary missing'
grep -F 'BACKEND_BASE_URL' .github/workflows/android-production.yml >/dev/null || fail 'backend URL secret missing'
grep -F 'BACKEND_PROJECT_ID' .github/workflows/android-production.yml >/dev/null || fail 'backend project secret missing'
grep -Eiq 'backup|restore|rollback|recovery' README.md V30_101_TO_V30_400_RELEASE_HARDENING.md || fail 'recovery documentation missing'
printf '%s\n' 'Freelance Hub v31.100 deployment/recovery boundary gate: PASS'
