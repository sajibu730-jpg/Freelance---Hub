#!/usr/bin/env bash
set -euo pipefail
version='11.902.0'; code='3092'; evidence_dir="${1:-app/build/outputs/apk/release}"
test -d "$evidence_dir"
for f in BUILD_METADATA.txt SHA256SUMS.txt RELEASE_EVIDENCE_INDEX.txt; do test -f "$evidence_dir/$f"; done
mapfile -t apks < <(find "$evidence_dir" -maxdepth 1 -type f -name '*.apk' -printf '%f\n' | sort)
test "${#apks[@]}" -ge 1
# The index must have exactly one APK binding per generated APK and exactly two evidence-file bindings.
apk_records=$(grep -Ec '^APK: .+ \| Size: [0-9]+ \| SHA256: [0-9a-f]{64}$' "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt" || true)
evidence_records=$(grep -Ec '^Evidence File: (BUILD_METADATA\.txt|SHA256SUMS\.txt) \| SHA256: [0-9a-f]{64}$' "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt" || true)
test "$apk_records" -eq "${#apks[@]}"
test "$evidence_records" -eq 2
grep -Fq "Evidence Version: $version" "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt"
grep -Fq "Evidence Version Code: $code" "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt"
grep -Fq "Version: $version" "$evidence_dir/BUILD_METADATA.txt"
grep -Fq "Version Code: $code" "$evidence_dir/BUILD_METADATA.txt"
# Reject any non-empty malformed records and duplicate bindings.
awk 'NF && $0 !~ /^(Evidence Version: [0-9]+\.[0-9]+\.[0-9]+|Evidence Version Code: [0-9]+|APK: .+ \| Size: [0-9]+ \| SHA256: [0-9a-f]{64}|Evidence File: (BUILD_METADATA\.txt|SHA256SUMS\.txt) \| SHA256: [0-9a-f]{64})$/{exit 1}' "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt"
test "$(grep -Ec '^APK:' "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt")" -eq "$(grep '^APK:' "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt" | sort | uniq | wc -l | tr -d ' ')"
for apk in "${apks[@]}"; do
  size=$(stat -c '%s' "$evidence_dir/$apk"); sha=$(sha256sum "$evidence_dir/$apk" | awk '{print $1}')
  test "$(grep -Fc "APK: $apk | Size: $size | SHA256: $sha" "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt")" -eq 1
done
for f in BUILD_METADATA.txt SHA256SUMS.txt; do
  sha=$(sha256sum "$evidence_dir/$f" | awk '{print $1}')
  test "$(grep -Fc "Evidence File: $f | SHA256: $sha" "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt")" -eq 1
done
printf 'v11.902 strict release evidence index gate: PASS\n'
