#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
f(){ echo "FAIL: $*" >&2; exit 1; }; p(){ echo "PASS: $*"; }
[[ "$(cat VERSION.txt)" == '53.400.0' ]] || f 'VERSION.txt mismatch'
grep -Fq 'versionCode = 53400' app/build.gradle.kts || f 'Gradle versionCode mismatch'
grep -Fq 'versionName = "53.400.0"' app/build.gradle.kts || f 'Gradle versionName mismatch'
[[ -s backend/FINAL_RELEASE_BOUNDARY_CONTRACT_V47_200.md ]] || f 'final release boundary contract missing'
[[ -s ops/runbooks/RELEASE_ASSURANCE_V47_200.md ]] || f 'release runbook missing'
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
  grep -Fq '53.400.0' "$wf" || f "version identity missing: $wf"
  grep -Fq '53400' "$wf" || f "version code missing: $wf"
  grep -Fq 'verify_v53400_final_release_boundary_gate.sh' "$wf" || f "final gate missing: $wf"
done
! grep -RInE '45\.600|45600|v45600|45\.200|45200|v45200' .github/workflows >/dev/null 2>&1 || f 'stale prior-version reference in active workflows'
! grep -RInE 'BEGIN (RSA|EC|OPENSSH) PRIVATE KEY|sk_live_[A-Za-z0-9_-]+' .github/workflows backend ops scripts --exclude='*.sha256' >/dev/null 2>&1 || f 'credential/private-key pattern detected'
for s in scripts/verify_v53400_*.sh; do [[ -x "$s" ]] || f "not executable: $s"; bash -n "$s" || f "syntax error: $s"; done
p 'v53.400 final release identity, workflow closure, syntax and credential hygiene'
