#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }
[[ "$(tr -d '\r\n' < VERSION.txt)" == "53.900.0" ]] || fail "VERSION.txt drift"
grep -q 'versionCode = 53900' app/build.gradle.kts || fail "Gradle versionCode drift"
grep -q 'versionName = "53.900.0"' app/build.gradle.kts || fail "Gradle versionName drift"
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
  grep -q '53.900.0' "$wf" || fail "current version missing from $wf"
  grep -q '53900' "$wf" || fail "current versionCode missing from $wf"
  grep -q 'verify_v53900_release_stack_gate.sh' "$wf" || fail "stack gate missing from $wf"
  grep -q 'verify_v53900_artifact_reproducibility_gate.sh' "$wf" || fail "reproducibility gate missing from $wf"
  grep -q 'verify_v53900_evidence_contract_gate.sh' "$wf" || fail "evidence contract gate missing from $wf"
done
if grep -RInE 'v43\.400|v43\.800|v44\.000|44\.000\.0|44000|43800|43400' .github/workflows >/dev/null 2>&1; then fail 'stale release identity in active workflows'; fi
if grep -RInE '(BEGIN (RSA|EC|OPENSSH) PRIVATE KEY|sk_live_[A-Za-z0-9_-]+|AKIA[0-9A-Z]{16})' app backend ops .github scripts --exclude='*.sha256' >/dev/null 2>&1; then fail 'credential/private-key material detected'; fi
if grep -nEi '^\s*(DROP\s+TABLE|TRUNCATE\b|DELETE\s+FROM\s+[A-Za-z_][A-Za-z0-9_]*\s*;)' BACKEND_SCHEMA.sql >/dev/null; then fail 'destructive baseline schema operation found'; fi
# Every shell script referenced by active workflows must exist, be executable, and parse.
while IFS= read -r ref; do
  script="${ref#./}"
  [[ -f "$script" ]] || fail "missing workflow script: $script"
  [[ -x "$script" ]] || fail "non-executable workflow script: $script"
  bash -n "$script" || fail "shell syntax error: $script"
done < <(grep -hRoE 'scripts/[A-Za-z0-9_.-]+\.sh' .github/workflows/*.yml | sort -u)
pass 'v53.900 consolidated release stack, workflow, credential, schema and shell-integrity checks'
# v53.900 operational contracts must remain part of the release stack.
for gate in \
  scripts/verify_v53900_environment_contract_gate.sh \
  scripts/verify_v53900_migration_restore_gate.sh \
  scripts/verify_v53900_payment_reconciliation_gate.sh \
  scripts/verify_v53900_observability_health_gate.sh; do
  [[ -x "$gate" ]] || fail "missing/non-executable v53.900 operational gate: $gate"
  bash -n "$gate" || fail "shell syntax error: $gate"
done
pass 'v53.900 operational environment, recovery, reconciliation and observability gates are wired'
