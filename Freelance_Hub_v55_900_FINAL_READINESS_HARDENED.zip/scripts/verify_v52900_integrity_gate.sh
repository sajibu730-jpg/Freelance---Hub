#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
f(){ echo "FAIL: $*" >&2; exit 1; }
[[ "$(tr -d '\r\n' < VERSION.txt)" == "52.900.0" ]] || f 'VERSION mismatch'
grep -Fq 'versionCode = 52900' app/build.gradle.kts || f 'versionCode mismatch'
grep -Fq 'versionName = "52.900.0"' app/build.gradle.kts || f 'versionName mismatch'
grep -Fq 'v52.401 → v52.900' V52_401_TO_V52_900_PRODUCTION_CONTINUITY_LEDGER.md || f 'ledger missing'
grep -Fq '500 controlled checkpoints' V52_401_TO_V52_900_PRODUCTION_CONTINUITY_LEDGER.md || f 'checkpoint count missing'
grep -Fq 'aiMayFinalizeMarketplaceOutcome' app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityFinalRules.kt || f 'AI financial boundary missing'
grep -Fq 'validEmergencyWindow' app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityFinalRules.kt || f 'payment transition contract missing'
grep -Fq 'validSkillMatch' app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityFinalRules.kt || f 'skill matching contract missing'
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do grep -Fq '52.900.0' "$wf" || f "workflow version missing: $wf"; grep -Fq 'verify_v52900_integrity_gate.sh' "$wf" || f "integrity gate missing: $wf"; done
! grep -RInE 'sk_(live|test)_[A-Za-z0-9]+|AKIA[0-9A-Z]{16}|-----BEGIN (RSA |EC )?PRIVATE KEY-----' app backend .github scripts --exclude='*.sha256' >/dev/null || f 'credential/private-key pattern found'
for s in scripts/verify_v52900_*.sh; do bash -n "$s" || f "shell syntax: $s"; done
echo 'v52.900 production integrity source gate: PASS'
