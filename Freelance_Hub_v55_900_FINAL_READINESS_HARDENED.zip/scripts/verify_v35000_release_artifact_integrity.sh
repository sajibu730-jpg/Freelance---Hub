#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
grep -F 'versionCode = 35000' app/build.gradle.kts >/dev/null || fail 'versionCode drift'
grep -F 'versionName = "35.000.0"' app/build.gradle.kts >/dev/null || fail 'versionName drift'
grep -Fx '35.000.0' VERSION.txt >/dev/null || fail 'VERSION.txt drift'
test -f V34_701_TO_V35_000_300_STEP_HARDENING_LEDGER.md || fail 'ledger missing'
for f in .github/workflows/android-build.yml .github/workflows/android-production.yml; do test -f "$f" || fail "missing workflow $f"; grep -F 'verify_v35000_final_production_boundary.sh' "$f" >/dev/null || fail "final gate missing from $f"; grep -F '35.000.0' "$f" >/dev/null || fail "workflow version drift: $f"; grep -F '35000' "$f" >/dev/null || fail "workflow versionCode drift: $f"; done
printf '%s\n' 'Freelance Hub v35.000 artifact integrity gate: PASS'
