#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
test "$(cat VERSION.txt)" = "55.900.0"
grep -q 'versionCode = 55900' app/build.gradle.kts
grep -q 'versionName = "55.900.0"' app/build.gradle.kts
test -f app/src/main/java/com/freelancehub/app/data/ProductionBoundaryRules.kt
test -f V54_901_TO_V55_400_PRODUCTION_BOUNDARY_LEDGER.md
test "$(grep -cE '^[0-9]{3}\. Verify ' V54_901_TO_V55_400_PRODUCTION_BOUNDARY_LEDGER.md)" -eq 500
grep -q 'NORMAL_HIRING_WINDOW_HOURS = 24' app/src/main/java/com/freelancehub/app/data/ProductionBoundaryRules.kt
grep -q 'EMERGENCY_HIRING_WINDOW_HOURS = 6' app/src/main/java/com/freelancehub/app/data/ProductionBoundaryRules.kt
grep -q 'EMERGENCY_PHASE_DISTRIBUTION = 50' app/src/main/java/com/freelancehub/app/data/ProductionBoundaryRules.kt
grep -q 'aiMayFinalizePrivilegedOutcome(): Boolean = false' app/src/main/java/com/freelancehub/app/data/ProductionBoundaryRules.kt
grep -q 'covertMonitoringAllowed(): Boolean = false' app/src/main/java/com/freelancehub/app/data/ProductionBoundaryRules.kt
echo 'v55.900 production boundary gate: PASS'
