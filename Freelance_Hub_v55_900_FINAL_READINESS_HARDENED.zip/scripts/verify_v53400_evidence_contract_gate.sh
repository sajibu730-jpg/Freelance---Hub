#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }
WF=.github/workflows/android-production.yml
[[ -s "$WF" ]] || fail 'production workflow missing'
for token in \
  'FREELANCE_HUB_BACKEND_BASE_URL' \
  'FREELANCE_HUB_BACKEND_PROJECT_ID' \
  'FREELANCE_HUB_RELEASE_KEYSTORE_B64' \
  'FREELANCE_HUB_RELEASE_KEYSTORE_PASSWORD' \
  'FREELANCE_HUB_RELEASE_KEY_ALIAS' \
  'FREELANCE_HUB_RELEASE_KEY_PASSWORD' \
  'gradle --no-daemon test' \
  'assembleRelease bundleRelease' \
  'apksigner verify --verbose' \
  'jarsigner -verify -strict' \
  'sha256sum *.apk' \
  'AAB_SHA256SUMS.txt' \
  'BUILD_METADATA.txt' \
  'RELEASE_EVIDENCE_INDEX.txt' \
  'GITHUB_SHA' \
  'GITHUB_RUN_ID' \
  'GITHUB_RUN_ATTEMPT' \
  'actions/attest-build-provenance@v2'; do
  grep -Fq "$token" "$WF" || fail "evidence/release contract missing: $token"
done
if grep -nE 'Version: 44\.000\.0|Version Code: 44000|v44\.000' "$WF" >/dev/null; then fail 'stale v44.000 evidence identity'; fi
pass 'v53.400 production evidence, signing, hash, metadata and provenance contract checks'
for token in \
  'environment contract' \
  'migration/restore' \
  'payment reconciliation' \
  'Observability & Health'; do
  grep -qi "$token" backend/PRODUCTION_ENVIRONMENT_CONTRACT_V47_200.md backend/MIGRATION_RESTORE_VERIFICATION_CONTRACT_V47_200.md backend/PAYMENT_RECONCILIATION_CONTRACT_V47_200.md backend/OBSERVABILITY_HEALTH_CONTRACT_V47_200.md || fail "v53.400 evidence contract keyword missing: $token"
done
pass 'v53.400 operational evidence contract references are present'
