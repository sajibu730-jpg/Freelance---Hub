#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
grep -q "50.900.0" VERSION.txt
grep -q "versionCode = 50900" app/build.gradle.kts
grep -q 'versionName = "50.900.0"' app/build.gradle.kts
test -f app/src/main/java/com/freelancehub/app/data/ProductionContinuityRules.kt
test -f app/src/test/java/com/freelancehub/app/data/ProductionContinuityRulesTest.kt
grep -q 'NORMAL_HIRING_WINDOW_HOURS = 24' app/src/main/java/com/freelancehub/app/data/ProductionContinuityRules.kt
grep -q 'EMERGENCY_TOTAL_WINDOW_HOURS = 6' app/src/main/java/com/freelancehub/app/data/ProductionContinuityRules.kt
grep -q 'EMERGENCY_PHASE_HOURS = 3' app/src/main/java/com/freelancehub/app/data/ProductionContinuityRules.kt
grep -q 'EMERGENCY_PHASE_DISTRIBUTION = 50' app/src/main/java/com/freelancehub/app/data/ProductionContinuityRules.kt
grep -q 'aiMayFinalizeOutcome(): Boolean = false' app/src/main/java/com/freelancehub/app/data/ProductionContinuityRules.kt
grep -q 'clientMayBypassAuthorization(): Boolean = false' app/src/main/java/com/freelancehub/app/data/ProductionContinuityRules.kt
grep -q 'covertMonitoringAllowed(): Boolean = false' app/src/main/java/com/freelancehub/app/data/ProductionContinuityRules.kt
echo 'v50.900 production continuity source gate: PASS'
