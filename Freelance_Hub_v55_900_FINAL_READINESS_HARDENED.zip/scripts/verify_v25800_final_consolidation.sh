#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail(){ echo "FAIL: $1" >&2; exit 1; }
grep -q 'versionCode = 25800' "$ROOT/app/build.gradle.kts" || fail 'versionCode mismatch'
grep -q 'versionName = "25.800.0"' "$ROOT/app/build.gradle.kts" || fail 'versionName mismatch'
test "$(tr -d '\r\n ' < "$ROOT/VERSION.txt")" = "25.800.0" || fail 'VERSION.txt mismatch'
grep -q 'ProtectionAppealRules' "$ROOT/app/src/main/java/com/freelancehub/app/security/ProtectionAppealRules.kt" || fail 'appeal rules missing'
grep -q 'PROTECTION_APPEAL_STATUS' "$ROOT/app/src/main/java/com/freelancehub/app/data/ApiContract.kt" || fail 'appeal status API contract missing'
grep -q '/protection-appeals/{appealId}:' "$ROOT/openapi.yaml" || fail 'appeal status OpenAPI path missing'
grep -q 'ProtectionAppealEvidence' "$ROOT/openapi.yaml" || fail 'appeal evidence schema missing'
grep -q 'ProtectionAppealRules' "$ROOT/app/src/test/java/com/freelancehub/app/security/ProtectionAppealRulesTest.kt" || fail 'appeal tests missing'
! grep -R -n -E 'BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY' "$ROOT" --exclude='*.sha256' --exclude='verify_*.sh' >/dev/null || fail 'private key material found'
! grep -RInE 'TODO|FIXME|IMPLEMENT_ME|YOUR_' "$ROOT/app/src/main" "$ROOT/.github/workflows" >/dev/null || fail 'unfinished marker found'
python - "$ROOT/openapi.yaml" <<'PY'
import sys, yaml
data=yaml.safe_load(open(sys.argv[1], encoding='utf-8'))
assert data.get('openapi') == '3.0.3'
assert 'components' in data and 'schemas' in data['components']
for key in ('ProtectionAppealCreate','ProtectionAppealEvidence','ProtectionReportCreate'):
    assert key in data['components']['schemas'], key
assert '/protection-appeals/{appealId}' in data['paths']
print('OpenAPI parse: PASS')
PY
echo 'Freelance Hub v25.800 final consolidation static audit: PASS'
