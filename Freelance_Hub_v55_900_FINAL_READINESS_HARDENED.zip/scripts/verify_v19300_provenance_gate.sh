#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
for f in "$ROOT/V19_100_RELEASE_HARDENING.md" "$ROOT/V19_101_TO_V19_300_200_STEP_LEDGER.md" "$ROOT/V19_300_RELEASE_HARDENING.md" "$ROOT/scripts/verify_v19100_release_boundary.sh" "$ROOT/scripts/verify_v19300_release_boundary.sh"; do test -f "$f"; done
sha256sum "$ROOT/V19_300_RELEASE_HARDENING.md" "$ROOT/V19_101_TO_V19_300_200_STEP_LEDGER.md" "$ROOT/scripts/verify_v19300_release_boundary.sh"
echo 'Freelance Hub v19.300 provenance gate: PASS'
