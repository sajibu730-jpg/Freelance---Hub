#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
FILE=app/build.gradle.kts
grep -Fq 'versionName = "16.100.0"' "$FILE"; grep -Fq 'versionCode = 7290' "$FILE"; grep -Fq 'isMinifyEnabled = true' "$FILE"; grep -Fq 'isShrinkResources = true' "$FILE"; grep -Fq 'BACKEND_BASE_URL' "$FILE"; grep -Fq 'BACKEND_PROJECT_ID' "$FILE"
WF=.github/workflows/android-production.yml
grep -Fq 'RELEASE_KEYSTORE_PATH' "$WF"; grep -Fq 'FREELANCE_HUB_RELEASE_KEYSTORE_B64' "$WF"; grep -Fq '16.100.0' "$WF"; grep -Fq '7290' "$WF"
printf 'v16.100 production config gate: PASS\n'
