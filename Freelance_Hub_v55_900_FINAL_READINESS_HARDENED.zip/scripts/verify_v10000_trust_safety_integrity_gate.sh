#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
test "$(grep -Fc 'Version: 10.000.0' VERSION.txt)" -eq 1
test "$(grep -Fc 'Version Code: 2900' VERSION.txt)" -eq 1
grep -Fq 'versionCode = 2900' app/build.gradle.kts
grep -Fq 'versionName = "10.000.0"' app/build.gradle.kts
test -f scripts/verify_v10000_trust_safety_integrity_gate.sh
test -s SOURCE_RELEASE_MANIFEST_v10.000.sha256
for WF in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
 test -f "$WF"; grep -Fq 'v10.000 trust-safety integrity gate' "$WF"; grep -Fq 'verify_v10000_trust_safety_integrity_gate.sh' "$WF"; grep -Fq 'Version: 10.000.0' "$WF"; grep -Fq 'Version Code: 2900' "$WF"
done
if grep -RInE 'verify_v9[0-9]{3}.*gate\.sh' .github/workflows | grep -v 'verify_v10000_trust_safety_integrity_gate.sh'; then exit 1; fi
grep -Fq 'isMinifyEnabled = true' app/build.gradle.kts
grep -Fq 'isShrinkResources = true' app/build.gradle.kts
grep -Fq 'jvmToolchain(17)' app/build.gradle.kts
for needle in enforce_moderation_case_integrity enforce_moderation_case_transition enforce_account_enforcement_integrity; do grep -Fq "$needle" BACKEND_SCHEMA.sql; done
test -f app/src/main/java/com/freelancehub/app/data/TrustSafetyRules.kt
test -f app/src/test/java/com/freelancehub/app/data/TrustSafetyRulesTest.kt
grep -Fq 'moderation_cases_read_subject_or_opener' BACKEND_RLS.sql
grep -Fq 'account_enforcements_read_owner' BACKEND_RLS.sql
awk 'NF==2 && $1 ~ /^[0-9a-f]{64}$/ {print $2}' SOURCE_RELEASE_MANIFEST_v10.000.sha256 > /tmp/fh_manifest_paths.txt
test -s SOURCE_RELEASE_MANIFEST_v10.000.sha256
test "$(sort /tmp/fh_manifest_paths.txt | uniq | wc -l)" -eq "$(wc -l < /tmp/fh_manifest_paths.txt)"
while IFS= read -r f; do test -f "$f"; done < /tmp/fh_manifest_paths.txt
sha256sum -c SOURCE_RELEASE_MANIFEST_v10.000.sha256 >/dev/null
find . -type f -not -path './.git/*' -not -path './app/build/*' -not -path './SOURCE_RELEASE_MANIFEST_v10.000.sha256' -print | sed 's#^./##' | sort > /tmp/fh_actual_paths.txt
sort /tmp/fh_manifest_paths.txt > /tmp/fh_manifest_paths_sorted.txt
cmp -s /tmp/fh_actual_paths.txt /tmp/fh_manifest_paths_sorted.txt
while IFS= read -r -d '' f; do bash -n "$f"; done < <(find scripts -type f -name '*.sh' -print0)
if grep -RInE 'BEGIN (RSA|OPENSSH|EC|PRIVATE) KEY|AKIA[0-9A-Z]{16}|sk_live_[A-Za-z0-9]+' --exclude-dir=.git --exclude='*.zip' .; then exit 1; fi
grep -Fq 'FREELANCE_HUB_BACKEND_BASE_URL' .github/workflows/android-production.yml
grep -Fq 'FREELANCE_HUB_RELEASE_KEYSTORE_B64' .github/workflows/android-production.yml
grep -Fq 'apksigner verify --verbose' .github/workflows/android-production.yml
echo 'v10.000 trust-safety integrity gate: PASS'
