#!/usr/bin/env bash
set -euo pipefail
manifest='SOURCE_RELEASE_MANIFEST_v11.200.sha256'
root='SOURCE_RELEASE_MANIFEST_v11.200.root.sha256'
test -f "$manifest"; test -f "$root"
test "$(awk '{print $1}' "$root")" = "$(sha256sum "$manifest" | awk '{print $1}')"
count="$(grep -Ec '^[0-9a-f]{64}  \.\/.+|^[0-9a-f]{64}  \./.+$' "$manifest")"
test "$count" -gt 0
awk '{print $2}' "$manifest" | sort -c
test "$(awk '{print $2}' "$manifest" | sort | uniq -d | wc -l | tr -d ' ')" -eq 0
while IFS= read -r entry; do test -f "${entry#*  }"; done < "$manifest"
grep -Fq 'Version: 11.200.0' VERSION.txt
grep -Fq 'Version Code: 3020' VERSION.txt
grep -Fq 'versionCode = 3020' app/build.gradle.kts
grep -Fq 'versionName = "11.200.0"' app/build.gradle.kts
printf 'v11.200 manifest root gate: PASS (%s entries)\n' "$count"
