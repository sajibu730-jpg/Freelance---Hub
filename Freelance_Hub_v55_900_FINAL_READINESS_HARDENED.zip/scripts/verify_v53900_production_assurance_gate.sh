#!/usr/bin/env bash
set -euo pipefail
[[ "$(cat VERSION.txt)" == "53.900.0" ]]
grep -q 'versionCode = 53900' app/build.gradle.kts
grep -q 'versionName = "53.900.0"' app/build.gradle.kts
test -f V53_401_TO_V53_900_PRODUCTION_ASSURANCE_LEDGER.md
[[ "$(grep -cE '^[0-9]{3}\. ' V53_401_TO_V53_900_PRODUCTION_ASSURANCE_LEDGER.md)" == "500" ]]
test -f app/src/main/java/com/freelancehub/app/data/ProductionAssuranceRules.kt
grep -q 'EMERGENCY_PHASE_DISTRIBUTION = 50' app/src/main/java/com/freelancehub/app/data/ProductionAssuranceRules.kt
grep -q 'clientMayFinalizePrivilegedState(): Boolean = false' app/src/main/java/com/freelancehub/app/data/ProductionAssuranceRules.kt
grep -q 'aiMayFinalizePrivilegedState(): Boolean = false' app/src/main/java/com/freelancehub/app/data/ProductionAssuranceRules.kt
grep -q 'allowsCovertMonitoring(): Boolean = false' app/src/main/java/com/freelancehub/app/data/ProductionAssuranceRules.kt
grep -R -q 'verify_v53900_' .github/workflows
echo 'v53.900 production assurance gate: PASS'
