#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }

# Release metadata must be internally consistent.
grep -Fx '41.400.0' VERSION.txt >/dev/null || fail 'VERSION.txt drift'
grep -F 'versionCode = 41400' app/build.gradle.kts >/dev/null || fail 'versionCode drift'
grep -F 'versionName = "41.400.0"' app/build.gradle.kts >/dev/null || fail 'versionName drift'

for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
  grep -F '41.400.0' "$wf" >/dev/null || fail "workflow version drift: $wf"
  grep -F '41400' "$wf" >/dev/null || fail "workflow versionCode drift: $wf"
done

# Artifact labels must never advertise an older release.
if grep -RInE 'freelance-hub-v(3[0-9]|40)\.[0-9]+-(verification-evidence|production-release)' .github/workflows >/dev/null 2>&1; then
  fail 'stale workflow artifact name detected'
fi

# Production workflow must fail closed on signing/backend configuration.
PROD=.github/workflows/android-production.yml
grep -F 'FREELANCE_HUB_BACKEND_BASE_URL' "$PROD" >/dev/null || fail 'backend secret missing'
grep -F 'FREELANCE_HUB_RELEASE_KEYSTORE_B64' "$PROD" >/dev/null || fail 'keystore secret missing'
grep -F 'requireReleaseSigning=true' "$PROD" >/dev/null || fail 'production signing requirement missing'
grep -F 'apksigner verify --verbose' "$PROD" >/dev/null || fail 'APK signature verification missing'
grep -F 'jarsigner -verify -strict' "$PROD" >/dev/null || fail 'AAB signature verification missing'

bash scripts/verify_v41200_financial_rls_closure_gate.sh >/dev/null
grep -F 'verify_v41400_financial_rls_closure_gate.sh' .github/workflows/android-build.yml >/dev/null || fail 'financial gate wiring missing'
printf '%s\n' 'Freelance Hub v41.400 release evidence integrity gate: PASS'
