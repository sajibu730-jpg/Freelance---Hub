#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
for gate in scripts/verify_v35300_release_artifact_integrity.sh scripts/verify_v35300_deployment_recovery_boundary.sh; do test -x "$gate" || fail "missing gate: $gate"; done
grep -F 'versionCode = 35300' app/build.gradle.kts >/dev/null || fail 'versionCode drift'
grep -F 'versionName = "35.300.0"' app/build.gradle.kts >/dev/null || fail 'versionName drift'
grep -Fx '35.300.0' VERSION.txt >/dev/null || fail 'VERSION.txt drift'
for f in .github/workflows/android-build.yml .github/workflows/android-production.yml; do grep -F 'verify_v35300_final_production_boundary.sh' "$f" >/dev/null || fail "final gate missing from $f"; grep -F '35.300.0' "$f" >/dev/null || fail "workflow version drift: $f"; grep -F '35300' "$f" >/dev/null || fail "workflow versionCode drift: $f"; done
bash scripts/verify_v35300_release_artifact_integrity.sh >/dev/null
bash scripts/verify_v35300_deployment_recovery_boundary.sh >/dev/null
printf '%s\n' 'Freelance Hub v35.300 final production boundary gate: PASS'
