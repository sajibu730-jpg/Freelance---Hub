#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
ledger=V14_901_TO_V15_100_200_STEP_LEDGER.md
test -s "$ledger"
python3 - "$ledger" <<'PY2'
import re,sys
rows=[]
for line in open(sys.argv[1],encoding='utf-8'):
 m=re.match(r"^\|\s*(\d+)\s*\|\s*v(14\.\d{3}|15\.\d{3})\.0\s*\|\s*(\d+)\s*\|\s*PASS\s*\|",line)
 if m: rows.append((int(m.group(1)),m.group(2),int(m.group(3))))
assert len(rows)==200
for i,(step,ver,code) in enumerate(rows,1):
 expected=f"14.{900+i:03d}" if i<=99 else f"15.{i-100:03d}"
 assert (step,ver,code)==(i,expected,6090+i)
assert rows[0]==(1,"14.901",6091)
assert rows[98]==(99,"14.999",6189)
assert rows[99]==(100,"15.000",6190)
assert rows[-1]==(200,"15.100",6290)
assert len({r[1] for r in rows})==200 and len({r[2] for r in rows})==200
PY2
grep -Fxq "Version: 15.100.0" VERSION.txt
grep -Fxq "Version Code: 6290" VERSION.txt
grep -Eq "versionCode[[:space:]]*=[[:space:]]*6290.*versionName[[:space:]]*=.*15.100.0" app/build.gradle.kts
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
 test -s "$wf"
 grep -Fq "v15.100 release range integrity gate" "$wf"
 grep -Fq "15.100.0" "$wf"
 grep -Fq "6290" "$wf"
 ! grep -Eq "v14\.900|v14\.700|v14\.500|v14\.300|v14\.100|v13\.900" "$wf"
done
printf "v15.100 range integrity gate: PASS (200 transitions; v14.901 -> v15.100)\n"
