#!/usr/bin/env bash
set -euo pipefail
expected_version='12.200.0'; expected_code='3390'
start_code=3193; end_code=3390
ledger='V12_004_TO_V12_200_197_STEP_LEDGER.md'
test -f "$ledger"
test "$(grep -c '^| [0-9].* | v12\.' "$ledger")" -eq 197
test "$(grep -c '^| 1 | v12.004.0 | 3194 |' "$ledger")" -eq 1
test "$(grep -c '^| 197 | v12.200.0 | 3390 |' "$ledger")" -eq 1
# Every version/code pair in the requested range must appear exactly once.
python3 - "$ledger" <<'PY'
import re,sys
p=sys.argv[1]; rows=[]
for line in open(p):
 m=re.match(r'^\|\s*(\d+)\s*\|\s*v12\.(\d{3})\.0\s*\|\s*(\d+)\s*\|',line)
 if m: rows.append(tuple(map(int,m.groups())))
assert len(rows)==197
for i,(step,minor,code) in enumerate(rows,1):
 assert step==i and minor==i+3 and code==3193+i
assert len({r[1] for r in rows})==197 and len({r[2] for r in rows})==197
PY
# active workflows must reference current gates/version only
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
  test -f "$wf"
  ! grep -Eq 'v12\.00[3-9]|v12\.0[1-9][0-9]|v12\.1[0-9][0-9]' "$wf"
  grep -Fq 'v12.200' "$wf"
  grep -Fq '12.200.0' "$wf"
  grep -Fq '3390' "$wf"
done
printf 'v12.200 range integrity gate: PASS (197 transitions; v12.004 -> v12.200)\n'
