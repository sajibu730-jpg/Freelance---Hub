#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
grep -Fx '41.600.0' VERSION.txt >/dev/null || fail 'VERSION.txt drift'
grep -F 'versionCode = 41600' app/build.gradle.kts >/dev/null || fail 'versionCode drift'
grep -F 'versionName = "41.600.0"' app/build.gradle.kts >/dev/null || fail 'versionName drift'
bash scripts/verify_v41600_financial_rls_closure_gate.sh >/dev/null
printf '%s\n' 'Freelance Hub v41.600 release boundary gate: PASS'
