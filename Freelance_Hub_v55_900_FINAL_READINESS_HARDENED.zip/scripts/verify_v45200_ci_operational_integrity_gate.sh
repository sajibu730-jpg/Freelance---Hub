#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }
[[ "$(tr -d '\r\n' < VERSION.txt)" == "45.200.0" ]] || fail "VERSION.txt drift"
grep -q 'versionCode = 45200' app/build.gradle.kts || fail "Gradle versionCode drift"
grep -q 'versionName = "45.200.0"' app/build.gradle.kts || fail "Gradle versionName drift"
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
  grep -q '45\.200\.0' "$wf" || fail "current version missing from $wf"
  grep -q '45200' "$wf" || fail "current versionCode missing from $wf"
done
if grep -RInE 'v44\.400|44\.400\.0|44400|verify_v44400|v44\.000|44\.000\.0|44000' .github/workflows >/dev/null 2>&1; then fail 'stale release identity in active workflows'; fi
if grep -RInE '(BEGIN (RSA|EC|OPENSSH) PRIVATE KEY|sk_live_[A-Za-z0-9_-]+|AKIA[0-9A-Z]{16})' app backend ops .github scripts --exclude='*.sha256' >/dev/null 2>&1; then fail 'credential/private-key material detected'; fi
if grep -nEi '^\s*(DROP\s+TABLE|TRUNCATE\b|DELETE\s+FROM\s+[A-Za-z_][A-Za-z0-9_]*\s*;)' BACKEND_SCHEMA.sql >/dev/null; then fail 'destructive baseline schema operation found'; fi
while IFS= read -r ref; do
  script="${ref#./}"
  [[ -f "$script" ]] || fail "missing workflow script: $script"
  [[ -x "$script" ]] || fail "non-executable workflow script: $script"
  bash -n "$script" || fail "shell syntax error: $script"
done < <(grep -hRoE 'scripts/[A-Za-z0-9_.-]+\.sh' .github/workflows/*.yml | sort -u)
for required in \
  backend/PRODUCTION_ENVIRONMENT_CONTRACT_V45_200.md \
  backend/MIGRATION_RESTORE_VERIFICATION_CONTRACT_V45_200.md \
  backend/PAYMENT_RECONCILIATION_CONTRACT_V45_200.md \
  backend/OBSERVABILITY_HEALTH_CONTRACT_V45_200.md; do
  [[ -s "$required" ]] || fail "required v45.200 contract missing: $required"
done
pass 'v45.200 CI operational integrity, release identity, workflow, credential, schema and contract checks'
