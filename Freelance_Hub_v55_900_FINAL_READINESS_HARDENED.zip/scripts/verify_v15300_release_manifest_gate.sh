#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
manifest=SOURCE_RELEASE_MANIFEST_v15.300.sha256
test -s "$manifest"
count=$(grep -Ec '^[0-9a-f]{64}  ./.*' "$manifest")
test "$count" -ge 400
sha256sum -c "$manifest" >/dev/null
printf 'v15.300 release manifest gate: PASS (%s entries)\n' "$count"
