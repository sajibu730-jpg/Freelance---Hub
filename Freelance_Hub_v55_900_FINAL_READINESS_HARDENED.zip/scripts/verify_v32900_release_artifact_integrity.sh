#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
grep -F 'versionCode = 32900' app/build.gradle.kts >/dev/null || fail 'versionCode drift'
grep -F 'versionName = "32.900.0"' app/build.gradle.kts >/dev/null || fail 'versionName drift'
grep -Fx '32.900.0' VERSION.txt >/dev/null || fail 'VERSION.txt drift'
test -f V32_601_TO_V32_900_300_STEP_HARDENING_LEDGER.md || fail 'ledger missing'
for f in .github/workflows/android-build.yml .github/workflows/android-production.yml; do test -f "$f" || fail "missing workflow $f"; grep -F 'verify_v32900_final_production_boundary.sh' "$f" >/dev/null || fail "final gate missing from $f"; done
printf '%s\n' 'Freelance Hub v32.900 artifact integrity gate: PASS'
