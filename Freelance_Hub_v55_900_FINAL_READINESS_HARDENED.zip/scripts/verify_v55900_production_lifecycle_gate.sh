#!/usr/bin/env bash
set -euo pipefail
[[ "$(cat VERSION.txt)" == "55.900.0" ]]
grep -q 'versionCode = 55900' app/build.gradle.kts
grep -q 'versionName = "55.900.0"' app/build.gradle.kts
test -f app/src/main/java/com/freelancehub/app/data/ProductionLifecycleIntegrityRules.kt
test -f V53_901_TO_V54_400_PRODUCTION_HANDOFF_LEDGER.md
[[ "$(grep -cE '^[0-9]{3}\. ' V53_901_TO_V54_400_PRODUCTION_HANDOFF_LEDGER.md)" == "500" ]]
grep -q 'clientMayFinalizePrivilegedState(): Boolean = false' app/src/main/java/com/freelancehub/app/data/ProductionLifecycleIntegrityRules.kt
grep -q 'aiMayFinalizePrivilegedState(): Boolean = false' app/src/main/java/com/freelancehub/app/data/ProductionLifecycleIntegrityRules.kt
grep -R -q 'verify_v55900_' .github/workflows
echo 'v55.900 production lifecycle gate: PASS'
