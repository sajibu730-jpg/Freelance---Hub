#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
test -f VERSION.txt && grep -qx '54.900.0' VERSION.txt
grep -q 'versionCode = 54900' app/build.gradle.kts
grep -q 'versionName = "54.900.0"' app/build.gradle.kts
test -f app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityFinalRules.kt
test -f V50_401_TO_V50_900_500_STEP_LEDGER.md
test -f RELEASE_VERIFICATION_V50_900.md
grep -q 'v54900' .github/workflows/android-build.yml
grep -q 'v54900' .github/workflows/android-production.yml
printf 'v54.900 marketplace integrity final gate: PASS\n'
