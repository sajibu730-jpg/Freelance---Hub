#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
test "$(grep -Fc 'Version: 10.500.0' VERSION.txt)" -eq 1
test "$(grep -Fc 'Version Code: 2950' VERSION.txt)" -eq 1
grep -Fq 'versionCode = 2950' app/build.gradle.kts
grep -Fq 'versionName = "10.500.0"' app/build.gradle.kts
grep -Fq "first incident event must open the incident with NOTIFY" BACKEND_SCHEMA.sql
grep -Fq "incident event state transition is invalid" BACKEND_SCHEMA.sql
grep -Fq "incident event timestamp moved backwards" BACKEND_SCHEMA.sql
grep -Fq 'validEventTransition' app/src/main/java/com/freelancehub/app/data/IncidentLifecycleRules.kt
grep -Fq 'validFirstEvent' app/src/main/java/com/freelancehub/app/data/IncidentLifecycleRules.kt
grep -Fq 'v10.500 incident temporal integrity gate' .github/workflows/android-build.yml
grep -Fq 'v10.500 incident temporal integrity gate' .github/workflows/android-production.yml
printf 'v10.500 incident temporal integrity gate: PASS\n'
