#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
manifest=SOURCE_RELEASE_MANIFEST_v15.700.sha256; root=SOURCE_RELEASE_MANIFEST_v15.700.root.sha256
test -s "$manifest"; test -s "$root"
test "$(cat "$root")" = "$(sha256sum "$manifest" | awk '{print $1}')"
bash scripts/verify_v15700_release_manifest_gate.sh
printf 'v15.700 manifest root gate: PASS\n'
