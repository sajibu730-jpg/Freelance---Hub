#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
f(){ echo "FAIL: $*" >&2; exit 1; }; p(){ echo "PASS: $*"; }
D=backend/PRODUCTION_INTEGRATION_CONTRACT_V47_200.md; [[ -s "$D" ]] || f 'integration contract missing'
for t in 'HTTPS-only API transport' 'Server-derived actor identity' 'Unsupported API/client contract versions fail closed' 'Money uses integer minor units' 'AI analysis is advisory/validation-only' 'Android never receives direct database credentials'; do grep -Fqi "$t" "$D" || f "missing integration requirement: $t"; done
! grep -Eiq 'http://(localhost|127\.0\.0\.1)|BEGIN (RSA|EC|OPENSSH) PRIVATE KEY' "$D" || f 'insecure endpoint/private key pattern found'
p 'v54.900 production integration contract checks'
