#!/usr/bin/env bash
set -euo pipefail
version='11.900.0'
code='3090'
for f in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
  test -f "$f"
  grep -Fq "Version: $version" "$f"
  grep -Fq "Version Code: $code" "$f"
  grep -Fq 'Git SHA: $GITHUB_SHA' "$f"
  grep -Fq 'Workflow Run: $GITHUB_RUN_ID' "$f"
  grep -Fq 'Workflow Attempt: $GITHUB_RUN_ATTEMPT' "$f"
  grep -Fq 'UTC: $(date -u +%Y-%m-%dT%H:%M:%SZ)' "$f"
  grep -Fq 'sha256sum *.apk > SHA256SUMS.txt' "$f"
  grep -Fq 'SHA256SUMS.txt' "$f"
done
# Evidence must be generated only after a successful build step.
awk '/Generate verification evidence/{a=1} a && /sha256sum \*\.apk/{b=1} END{exit !(a&&b)}' .github/workflows/android-build.yml
awk '/Generate production evidence/{a=1} a && /sha256sum \*\.apk/{b=1} END{exit !(a&&b)}' .github/workflows/android-production.yml
# The current release must not retain prior-version artifact names.
! grep -RqsE 'freelance-hub-v(10\.|11\.(0|1|2)00)' .github/workflows
# The current evidence gate itself must be wired into both workflows.
grep -Fq 'scripts/verify_v11900_release_evidence_gate.sh' .github/workflows/android-build.yml
grep -Fq 'scripts/verify_v11900_release_evidence_gate.sh' .github/workflows/android-production.yml
printf 'v11.900 release evidence provenance gate: PASS\n'
