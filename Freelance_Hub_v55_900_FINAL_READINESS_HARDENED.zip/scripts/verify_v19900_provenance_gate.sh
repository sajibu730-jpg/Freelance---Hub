#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
for f in "$ROOT/V19_700_RELEASE_HARDENING.md" "$ROOT/V19_701_TO_V19_900_200_STEP_LEDGER.md" "$ROOT/V19_900_RELEASE_HARDENING.md" "$ROOT/scripts/verify_v19700_release_boundary.sh" "$ROOT/scripts/verify_v19900_release_boundary.sh"; do test -f "$f"; done
sha256sum "$ROOT/V19_900_RELEASE_HARDENING.md" "$ROOT/V19_701_TO_V19_900_200_STEP_LEDGER.md" "$ROOT/scripts/verify_v19900_release_boundary.sh"
echo 'Freelance Hub v19.900 provenance gate: PASS'
