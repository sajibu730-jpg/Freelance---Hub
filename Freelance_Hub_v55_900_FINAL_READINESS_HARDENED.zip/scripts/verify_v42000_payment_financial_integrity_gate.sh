#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
SCHEMA=BANKEND_SCHEMA.sql
SCHEMA=BANKEND_SCHEMA.sql
[ -f BACKEND_SCHEMA.sql ] || fail 'BACKEND_SCHEMA.sql missing'
SCHEMA=BACKEND_SCHEMA.sql

grep -F "payment_provider_reference_uq" "$SCHEMA" >/dev/null || fail 'provider reference uniqueness missing'
grep -F "wallet ledger entries are append-only" "$SCHEMA" >/dev/null || fail 'ledger immutability missing'
grep -F "cumulative refund amount exceeds payment amount" "$SCHEMA" >/dev/null || fail 'refund ceiling missing'
grep -F "unverified payment webhook cannot mutate financial state" "$SCHEMA" >/dev/null || fail 'webhook verification boundary missing'
grep -F "idempotency record must expire after creation" "$SCHEMA" >/dev/null || fail 'idempotency expiry boundary missing'
grep -F "ledger_financial_integrity_trigger" "$SCHEMA" >/dev/null || fail 'ledger financial trigger missing'
grep -F "refund_financial_ceiling_trigger" "$SCHEMA" >/dev/null || fail 'refund financial trigger missing'

# No provider secrets or signing material may enter the repository.
if find . -type f \( -name '*.jks' -o -name '*.keystore' -o -name '*.p12' -o -name '*.pem' -o -name '*.key' \) -print -quit | grep -q .; then
  fail 'signing/secret material present in source tree'
fi

printf '%s\n' 'Freelance Hub v42.300 payment/financial integrity gate: PASS'
