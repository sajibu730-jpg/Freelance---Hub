#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/app/build.gradle.kts"
LEDGER="$ROOT/V19_101_TO_V19_300_200_STEP_LEDGER.md"
DOC="$ROOT/V19_300_RELEASE_HARDENING.md"
PROD="$ROOT/.github/workflows/android-production.yml"
BUILD="$ROOT/.github/workflows/android-build.yml"
for f in "$APP" "$LEDGER" "$DOC" "$PROD" "$BUILD"; do test -f "$f"; done

grep -q 'versionCode = 10300' "$APP"
grep -q 'versionName = "19.300.0"' "$APP"
# Exactly 200 ordered checkpoints, v19.101..v19.300.
python3 - "$LEDGER" <<'PY'
import re,sys
p=sys.argv[1]
nums=[]
for line in open(p,encoding='utf-8'):
    m=re.match(r'^(\d+)\. v19\.(\d{3}) ',line)
    if m: nums.append((int(m.group(1)),int(m.group(2))))
assert len(nums)==200, len(nums)
assert nums == [(i,n) for i,n in enumerate(range(101,301),1)], nums[:3]
PY
# No private key blocks in source/evidence; verification scripts themselves are excluded.
! grep -R -n -E 'BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY' "$ROOT" --exclude='*.sha256' --exclude='verify_*.sh' >/dev/null
for wf in "$PROD" "$BUILD"; do
  grep -q '^permissions:' "$wf"
  grep -q '^  contents: read$' "$wf"
  grep -q '^  actions: read$' "$wf"
  ! grep -E -n '^[[:space:]]+uses: .*@(main|master|dev|develop|latest)$' "$wf" >/dev/null
  grep -q 'actions/checkout@v4' "$wf"
  checkout=$(grep -n 'actions/checkout@v4' "$wf" | head -1 | cut -d: -f1)
  gate=$(grep -n 'v19.300 source/CI release-boundary gate' "$wf" | head -1 | cut -d: -f1)
  prov=$(grep -n 'v19.300 provenance gate' "$wf" | head -1 | cut -d: -f1)
  test -n "$checkout" && test -n "$gate" && test -n "$prov"
  test "$checkout" -lt "$gate" && test "$gate" -lt "$prov"
  grep -q '19.300.0' "$wf"
  grep -q '10300' "$wf"
done
grep -q 'v19.300 provenance gate' "$PROD"
grep -q 'v19.300 provenance gate' "$BUILD"
# Production workflow must keep fail-closed checks for required secrets and HTTPS.
grep -q 'Missing required production secret/config' "$PROD"
grep -q 'https://\*)' "$PROD"
grep -q 'apksigner verify --verbose' "$PROD"
grep -q 'jarsigner -verify -strict' "$PROD"
echo 'Freelance Hub v19.300 source/CI release-boundary verification: PASS'
