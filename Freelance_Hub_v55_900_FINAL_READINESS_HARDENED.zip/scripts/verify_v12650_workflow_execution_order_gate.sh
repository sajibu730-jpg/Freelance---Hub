#!/usr/bin/env bash
set -euo pipefail
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do awk '/name: Checkout/{c=NR} /v12.650 release range integrity gate/{g=NR} /Set up JDK 17/{j=NR} END{exit !(c<g && g<j)}' "$wf"; done
printf "v12.650 workflow execution order gate: PASS\n"
