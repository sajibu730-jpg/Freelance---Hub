#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
f(){ echo "FAIL: $*" >&2; exit 1; }
[[ "$(tr -d '\r\n' < VERSION.txt)" == "53.400.0" ]] || f 'VERSION mismatch'
grep -Fq 'versionCode = 53400' app/build.gradle.kts || f 'versionCode mismatch'
grep -Fq 'versionName = "53.400.0"' app/build.gradle.kts || f 'versionName mismatch'
grep -Fq 'v52.901 → v53.400' V52_901_TO_V53_400_PRODUCTION_LIFECYCLE_INTEGRITY_LEDGER.md || f 'ledger missing'
grep -Fq '500 controlled checkpoints' V52_901_TO_V53_400_PRODUCTION_LIFECYCLE_INTEGRITY_LEDGER.md || f 'checkpoint count missing'
grep -Fq 'aiMayFinalizeMarketplaceOutcome' app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityFinalRules.kt || f 'AI financial boundary missing'
grep -Fq 'validEmergencyWindow' app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityFinalRules.kt || f 'payment transition contract missing'
grep -Fq 'validSkillMatch' app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityFinalRules.kt || f 'skill matching contract missing'
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do grep -Fq '53.400.0' "$wf" || f "workflow version missing: $wf"; grep -Fq 'verify_v53400_integrity_gate.sh' "$wf" || f "integrity gate missing: $wf"; done
! grep -RInE 'sk_(live|test)_[A-Za-z0-9]+|AKIA[0-9A-Z]{16}|-----BEGIN (RSA |EC )?PRIVATE KEY-----' app backend .github scripts --exclude='*.sha256' >/dev/null || f 'credential/private-key pattern found'
for s in scripts/verify_v53400_*.sh; do bash -n "$s" || f "shell syntax: $s"; done
echo 'v53.400 production integrity source gate: PASS'
