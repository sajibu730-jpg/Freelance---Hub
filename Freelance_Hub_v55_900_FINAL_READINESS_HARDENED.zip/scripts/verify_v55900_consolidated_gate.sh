#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
for gate in \
  scripts/verify_v55900_privacy_data_lifecycle_gate.sh \
  scripts/verify_v55900_account_session_recovery_gate.sh \
  scripts/verify_v55900_client_resilience_accessibility_gate.sh \
  scripts/verify_v55900_final_release_boundary_gate.sh; do
  bash "$gate"
done
printf 'PASS: v45.601 to v55.900 consolidated hardening gate\n'
