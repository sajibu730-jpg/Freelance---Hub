#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
f(){ echo "FAIL: $*" >&2; exit 1; }; p(){ echo "PASS: $*"; }
D=backend/AI_TRUST_SAFETY_CONTRACT_V47_200.md; [[ -s "$D" ]] || f 'AI/trust safety contract missing'
for t in 'authorize payment/refund' 'mark a contract complete by itself' 'close/suspend an account by itself' 'fail closed to a reviewable state' 'auditable evidence'; do grep -Fqi "$t" "$D" || f "missing AI safety requirement: $t"; done
p 'v48.000 AI work-analysis and trust/safety isolation checks'
