#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
EXPECTED_VERSION="12.201.0"
EXPECTED_CODE="3391"

for wf in "$ROOT/.github/workflows/android-build.yml" "$ROOT/.github/workflows/android-production.yml"; do
  test -s "$wf"
  grep -Fq "Version: ${EXPECTED_VERSION}" "$wf"
  grep -Fq "Version Code: ${EXPECTED_CODE}" "$wf"
  grep -Fq "Evidence Version: ${EXPECTED_VERSION}" "$wf"
  grep -Fq "Evidence Version Code: ${EXPECTED_CODE}" "$wf"
  grep -Fq "freelance-hub-v12.201-" "$wf"
  if grep -Eq 'v12\.(200|[0-9]{1,2})[^0-9]' "$wf"; then
    echo "stale release version reference found in $wf" >&2
    exit 1
  fi
done

grep -Fq "versionCode = ${EXPECTED_CODE}" "$ROOT/app/build.gradle.kts"
grep -Fq "versionName = \"${EXPECTED_VERSION}\"" "$ROOT/app/build.gradle.kts"

echo "v12.201 workflow metadata binding gate: PASS"
