#!/usr/bin/env bash
set -euo pipefail

# v10.900: release metadata/artifact consistency gate.
test "$(grep -Fc 'Version: 10.900.0' VERSION.txt)" -eq 1
test "$(grep -Fc 'Version Code: 2990' VERSION.txt)" -eq 1
grep -Fq 'versionCode = 2990' app/build.gradle.kts
grep -Fq 'versionName = "10.900.0"' app/build.gradle.kts

test "$(grep -Fc 'v10.900 release consistency integrity gate' .github/workflows/android-build.yml)" -eq 1
test "$(grep -Fc 'v10.900 release consistency integrity gate' .github/workflows/android-production.yml)" -eq 1

test "$(grep -Fc 'bash scripts/verify_v10900_release_consistency_gate.sh' .github/workflows/android-build.yml)" -eq 1
test "$(grep -Fc 'bash scripts/verify_v10900_release_consistency_gate.sh' .github/workflows/android-production.yml)" -eq 1

test "$(grep -Fc 'freelance-hub-v10.900-verification-evidence' .github/workflows/android-build.yml)" -eq 1
test "$(grep -Fc 'freelance-hub-v10.900-production-release' .github/workflows/android-production.yml)" -eq 1

# Historical release labels must not leak into current artifact metadata.
! grep -Eq '10\.(300|400|800)\.0|v10\.(300|400|800)-' .github/workflows/android-build.yml
grep -Fq 'Version: 10.900.0' .github/workflows/android-build.yml
grep -Fq 'Version Code: 2990' .github/workflows/android-build.yml
! grep -Eq '10\.(300|400|800)\.0|v10\.(300|400|800)-' .github/workflows/android-production.yml
grep -Fq 'Version: 10.900.0' .github/workflows/android-production.yml
grep -Fq 'Version Code: 2990' .github/workflows/android-production.yml

printf 'v10.900 release consistency integrity gate: PASS\n'
