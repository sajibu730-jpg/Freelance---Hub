#!/usr/bin/env bash
set -euo pipefail
manifest=SOURCE_RELEASE_MANIFEST_v16.100.sha256; root=SOURCE_RELEASE_MANIFEST_v16.100.root.sha256
test -s "$manifest"; test -s "$root"
test "$(sha256sum "$manifest" | cut -d' ' -f1)" = "$(tr -d '[:space:]' < "$root")"
printf 'v16.100 manifest root gate: PASS\n'
