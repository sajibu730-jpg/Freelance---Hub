#!/usr/bin/env bash
set -euo pipefail

manifest="app/src/main/AndroidManifest.xml"
netcfg="app/src/main/res/xml/network_security_config.xml"
backup="app/src/main/res/xml/backup_rules.xml"
data_rules="app/src/main/res/xml/data_extraction_rules.xml"
token_store="app/src/main/java/com/freelancehub/app/security/TokenStore.kt"
gradle="app/build.gradle.kts"

for f in "$manifest" "$netcfg" "$backup" "$data_rules" "$token_store" "$gradle"; do
  test -f "$f" || { echo "Missing required security file: $f" >&2; exit 1; }
done

grep -q 'android:usesCleartextTraffic="false"' "$manifest"
grep -q 'cleartextTrafficPermitted="false"' "$netcfg"
grep -q 'secure_session.xml' "$backup"
grep -q 'secure_session.xml' "$data_rules"
grep -q 'AndroidKeyStore' "$token_store"
grep -q 'AES/GCM/NoPadding' "$token_store"
grep -q 'setRandomizedEncryptionRequired(true)' "$token_store"

# Production source must not emit Android log calls from app code.
if grep -RInE 'Log\.[dviwe]|println\(' app/src/main/java >/dev/null 2>&1; then
  echo 'Production app source contains debug/console logging.' >&2
  exit 1
fi

# Reject dynamic Gradle dependency versions in the application module.
if grep -EIn 'implementation\([^)]*:[^:()]+:(latest|release|[0-9]+\.[0-9]+\.\+|\+)' "$gradle" >/dev/null 2>&1; then
  echo 'Dynamic dependency version detected.' >&2
  exit 1
fi

echo 'PASS: v41.600 Android security hardening gate'
