#!/usr/bin/env bash
set -euo pipefail
version='11.900.0'; code='3090'
workflows=(.github/workflows/android-build.yml .github/workflows/android-production.yml)
expected=(
 scripts/verify_v11900_release_evidence_gate.sh
 scripts/verify_v11900_release_evidence_index_gate.sh
 scripts/verify_v11900_release_evidence_consistency_gate.sh
 scripts/verify_v11900_release_manifest_integrity_gate.sh
 scripts/verify_v11900_release_workflow_integrity_gate.sh
 scripts/verify_v11900_manifest_root_gate.sh
 scripts/verify_v11900_release_manifest_root_gate.sh
)
for f in "${workflows[@]}"; do
 test -f "$f"; grep -Fq "Version: $version" "$f"; grep -Fq "Version Code: $code" "$f"
 for script in "${expected[@]}"; do grep -Fq "$script" "$f"; done
 ! grep -Eq 'scripts/verify_v11(3|4|5|6|7)[0-9]{2}_(release|manifest)' "$f"
 ! grep -Eq 'freelance-hub-v11\.(3|4|5|6|7)00-' "$f"
done
for script in "${expected[@]}" scripts/verify_v11900_release_gate_reconciliation.sh; do test -f "$script"; done
printf 'v11.900 release gate reconciliation: PASS\n'
