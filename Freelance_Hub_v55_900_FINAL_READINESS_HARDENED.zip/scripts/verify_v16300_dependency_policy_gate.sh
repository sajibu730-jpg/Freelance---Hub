#!/usr/bin/env bash
set -euo pipefail
test -s settings.gradle.kts
test -s app/build.gradle.kts
if grep -nE 'mavenLocal\(' settings.gradle.kts build.gradle.kts app/build.gradle.kts 2>/dev/null; then
  echo 'disallowed local Maven repository detected' >&2; exit 1
fi
if grep -nF 'http://' settings.gradle.kts build.gradle.kts app/build.gradle.kts 2>/dev/null; then
  echo 'disallowed insecure dependency URL detected' >&2; exit 1
fi
printf 'v16.300 dependency policy gate: PASS\n'
