#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }
DOC=backend/MIGRATION_RESTORE_VERIFICATION_CONTRACT_V47_200.md
[[ -s "$DOC" ]] || fail 'migration/restore contract missing'
[[ -s BACKEND_SCHEMA.sql ]] || fail 'baseline schema missing'
for token in 'forward-only' 'Destructive baseline operations are prohibited' 'backup/restore point' 'isolated target' 'financial invariant checks'; do
  grep -Fq "$token" "$DOC" || fail "migration/restore requirement missing: $token"
done
if grep -nEi '^\s*(DROP\s+TABLE|TRUNCATE\b|DELETE\s+FROM\s+[A-Za-z_][A-Za-z0-9_]*\s*;)' BACKEND_SCHEMA.sql >/dev/null; then fail 'destructive operation found in baseline schema'; fi
if grep -RInE 'DROP DATABASE|DROP SCHEMA|pg_restore .*--clean|pg_restore .*--create' .github/workflows >/dev/null 2>&1; then
  fail 'destructive restore command present in release automation'
fi
pass 'v50.400 migration, backup/restore evidence and destructive-operation boundary checks'
