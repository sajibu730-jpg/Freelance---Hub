#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
wf=.github/workflows/android-production.yml
for token in BUILD_METADATA.txt SHA256SUMS.txt GITHUB_SHA GITHUB_RUN_ID GITHUB_RUN_ATTEMPT sha256sum 'apksigner verify' 'jarsigner -verify'; do grep -Fq "$token" "$wf"; done
printf 'v15.500 production provenance gate: PASS\n'
