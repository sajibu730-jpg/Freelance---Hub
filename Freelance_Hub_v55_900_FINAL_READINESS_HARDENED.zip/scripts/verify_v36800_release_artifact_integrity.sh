#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
test -f VERSION.txt || fail "VERSION.txt missing"
grep -Fx "36.800.0" VERSION.txt >/dev/null || fail "VERSION.txt drift"
test -f app/build.gradle.kts || fail "Gradle file missing"
grep -F "versionCode = 36800" app/build.gradle.kts >/dev/null || fail "versionCode drift"
grep -F 'versionName = "36.800.0"' app/build.gradle.kts >/dev/null || fail "versionName drift"
test -f .github/workflows/android-build.yml || fail "build workflow missing"
test -f .github/workflows/android-production.yml || fail "production workflow missing"
printf '%s\n' 'Freelance Hub v36.500 release artifact integrity gate: PASS'
