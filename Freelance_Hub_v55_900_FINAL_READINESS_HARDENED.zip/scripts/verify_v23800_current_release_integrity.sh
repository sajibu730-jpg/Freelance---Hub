#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/app/build.gradle.kts"
VERSION="$ROOT/VERSION.txt"
BUILD="$ROOT/.github/workflows/android-build.yml"
PROD="$ROOT/.github/workflows/android-production.yml"

for f in "$APP" "$VERSION" "$BUILD" "$PROD"; do
  test -f "$f"
done

grep -q 'versionCode = 23800' "$APP"
grep -q 'versionName = "23.800.0"' "$APP"
test "$(tr -d '\r\n ' < "$VERSION")" = "23.800.0"

for wf in "$BUILD" "$PROD"; do
  grep -q 'Freelance Hub v23.800 current-release integrity gate' "$wf"
  grep -q '23.800.0' "$wf"
  grep -q '23800' "$wf"
  case "$wf" in
    *android-production.yml) grep -q 'PrequireReleaseSigning=true' "$wf" ;;
    *android-build.yml) grep -q 'PrequireReleaseSigning=false' "$wf" ;;
  esac
  ! grep -E -n 'v21\.101|v20\.(900|700|500|300|100)' "$wf" >/dev/null
  ! grep -E -n '^[[:space:]]+uses: .*@(main|master|dev|develop|latest)$' "$wf" >/dev/null
done

# Never ship private key material in source control.
! grep -R -n -E 'BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY' "$ROOT" \
  --exclude='*.sha256' --exclude='verify_*.sh' >/dev/null

echo 'Freelance Hub v23.800 current-release integrity: PASS'
