#!/usr/bin/env bash
set -euo pipefail
if find . -type f -not -path './.git/*' -not -path './build/*' -not -path './app/build/*' \( -name '*.jks' -o -name '*.keystore' -o -name '*.apk' -o -name '*.aab' \) -print -quit | grep -q .; then
  echo 'forbidden release artifact found in source tree' >&2; exit 1
fi
printf 'v16.300 source cleanliness gate: PASS\n'
