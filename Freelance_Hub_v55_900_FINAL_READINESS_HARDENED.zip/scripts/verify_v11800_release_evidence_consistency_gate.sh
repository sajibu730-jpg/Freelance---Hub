#!/usr/bin/env bash
set -euo pipefail
version='11.800.0'
code='3080'
evidence_dir="${1:-app/build/outputs/apk/release}"
test -d "$evidence_dir"
for f in BUILD_METADATA.txt SHA256SUMS.txt RELEASE_EVIDENCE_INDEX.txt; do test -f "$evidence_dir/$f"; done
mapfile -t apks < <(find "$evidence_dir" -maxdepth 1 -type f -name '*.apk' -printf '%f\n' | sort)
test "${#apks[@]}" -ge 1
# SHA256SUMS must contain exactly the generated APK set: no missing and no unexpected entries.
mapfile -t listed < <(awk 'NF==2 && $1 ~ /^[0-9a-f]{64}$/ {print $2}' "$evidence_dir/SHA256SUMS.txt" | sort)
printf '%s\n' "${apks[@]}" | sort > /tmp/fh_apks_11800.txt
printf '%s\n' "${listed[@]}" | sort > /tmp/fh_listed_11800.txt
diff -u /tmp/fh_apks_11800.txt /tmp/fh_listed_11800.txt >/dev/null
# The index must contain exactly one binding line for each APK and each evidence file.
for apk in "${apks[@]}"; do
  size=$(stat -c '%s' "$evidence_dir/$apk")
  sha=$(sha256sum "$evidence_dir/$apk" | awk '{print $1}')
  test "$(grep -Fc "APK: $apk | Size: $size | SHA256: $sha" "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt")" -eq 1
done
for f in BUILD_METADATA.txt SHA256SUMS.txt; do
  sha=$(sha256sum "$evidence_dir/$f" | awk '{print $1}')
  test "$(grep -Fc "Evidence File: $f | SHA256: $sha" "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt")" -eq 1
done
# Reject stale release metadata in evidence files.
grep -Fq "Evidence Version: $version" "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt"
grep -Fq "Evidence Version Code: $code" "$evidence_dir/RELEASE_EVIDENCE_INDEX.txt"
! grep -qE '11\.(0|1|2|3|4|5)00\.0|Version Code: 30(0[0-9]|1[0-9]|2[0-9]|3[0-9]|4[0-9]|5[0-9])' "$evidence_dir/BUILD_METADATA.txt"
printf 'v11.800 release evidence consistency gate: PASS\n'
