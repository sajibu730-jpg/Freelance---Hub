#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
grep -R -E 'BACKEND_BASE_URL|BACKEND_PROJECT_ID' README* V*md .github/workflows >/dev/null || fail 'deployment configuration evidence missing'
grep -R -Ei 'recovery|rollback|restore|backup' README* V*md .github/workflows >/dev/null || fail 'recovery evidence missing'
printf '%s\n' 'Freelance Hub v33.200 deployment/recovery boundary gate: PASS'
