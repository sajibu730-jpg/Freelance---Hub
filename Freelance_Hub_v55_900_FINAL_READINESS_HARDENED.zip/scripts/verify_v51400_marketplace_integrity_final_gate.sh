#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
test -f VERSION.txt && grep -qx '51.400.0' VERSION.txt
grep -q 'versionCode = 51400' app/build.gradle.kts
grep -q 'versionName = "51.400.0"' app/build.gradle.kts
test -f app/src/main/java/com/freelancehub/app/data/MarketplaceIntegrityFinalRules.kt
test -f V50_401_TO_V50_900_500_STEP_LEDGER.md
test -f RELEASE_VERIFICATION_V50_900.md
grep -q 'v51400' .github/workflows/android-build.yml
grep -q 'v51400' .github/workflows/android-production.yml
printf 'v51.400 marketplace integrity final gate: PASS\n'
