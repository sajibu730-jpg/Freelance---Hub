#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
f(){ echo "FAIL: $*" >&2; exit 1; }; p(){ echo "PASS: $*"; }
D=backend/DATA_FINANCIAL_CONSISTENCY_CONTRACT_V46_000.md; [[ -s "$D" ]] || f 'data/financial contract missing'
for t in 'migration ordering/checksum evidence' 'backup/restore evidence' 'refund ceiling' 'duplicate webhook protection' 'idempotency request-hash consistency'; do grep -Fqi "$t" "$D" || f "missing financial requirement: $t"; done
Q=backend/RECONCILIATION_READ_ONLY_QUERIES_V45_200.sql; [[ -s "$Q" ]] || f 'read-only reconciliation query pack missing'
if sed '/^[[:space:]]*--/d' "$Q" | grep -Eiq '(^|[;[:space:]])(insert|update|delete|truncate|drop|alter)[[:space:]]'; then f 'mutation SQL found in read-only query pack'; fi
p 'v46.000 data and financial consistency checks'
