#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }
[[ -f VERSION.txt && "$(tr -d '\r\n' < VERSION.txt)" == "55.900.0" ]] || fail 'release version mismatch'
# Source manifest inputs are deterministic: sorted paths, normalized relative names, no generated build outputs.
tmp="$(mktemp)"; trap 'rm -f "$tmp"' EXIT
find . -type f \
  -not -path './.git/*' \
  -not -path './app/build/*' \
  -not -path './build/*' \
  -not -path './.gradle/*' \
  -not -path './fh32_1200/*' \
  -not -path './RELEASE_SOURCE_MANIFEST_V47_200.sha256' \
  -print | LC_ALL=C sort | while read -r f; do sha256sum "$f"; done > "$tmp"
[[ -s "$tmp" ]] || fail 'empty source manifest'
# Ensure no absolute paths or obvious machine-local build artifacts enter the manifest.
if grep -Eq '/mnt/data|/home/|/Users/|\\\\' "$tmp"; then fail 'non-portable path leaked into manifest'; fi
sha256sum "$tmp" > RELEASE_SOURCE_MANIFEST_V47_200.sha256
pass 'v55.900 deterministic source manifest generated (generated build outputs excluded)'
