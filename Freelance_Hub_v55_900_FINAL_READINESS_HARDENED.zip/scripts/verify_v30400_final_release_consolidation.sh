#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fail(){ echo "FAIL: $1" >&2; exit 1; }
cd "$ROOT"
for gate in scripts/verify_v30100_release_reproducibility.sh scripts/verify_v30200_dependency_provenance.sh scripts/verify_v30300_supply_chain_release_gate.sh scripts/verify_v30000_production_readiness_boundary.sh; do test -x "$gate" || fail "missing executable gate: $gate"; done
grep -F 'versionCode = 30700' app/build.gradle.kts >/dev/null || fail 'versionCode must be 30400'
grep -F 'versionName = "30.700.0"' app/build.gradle.kts >/dev/null || fail 'versionName must be 30.400.0'
grep -F 'verify_v30700_release_evidence_consolidation.sh' .github/workflows/android-build.yml >/dev/null || fail 'verification workflow missing final gate'
grep -F 'verify_v30700_release_evidence_consolidation.sh' .github/workflows/android-production.yml >/dev/null || fail 'production workflow missing final gate'
if grep -RInE '\b(TODO|FIXME|IMPLEMENT_ME|YOUR_)\b' app/src/main app/src/test .github/workflows --include='*.kt' --include='*.kts' --include='*.yml' >/dev/null 2>&1; then fail 'unfinished implementation marker found'; fi
bash scripts/verify_v30000_production_readiness_boundary.sh >/dev/null
bash scripts/verify_v30100_release_reproducibility.sh >/dev/null
bash scripts/verify_v30200_dependency_provenance.sh >/dev/null
bash scripts/verify_v30300_supply_chain_release_gate.sh >/dev/null
printf '%s\n' 'Freelance Hub v30.400 final release consolidation gate: PASS'
