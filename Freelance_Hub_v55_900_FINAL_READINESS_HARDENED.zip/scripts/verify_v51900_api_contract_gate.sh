#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }
DOC=backend/API_CONTRACT_COMPLETENESS_V47_200.md
MATRIX=backend/API_CONTRACT_MATRIX_V47_200.md
[[ -s "$DOC" ]] || fail 'API completeness contract missing'
[[ -s "$MATRIX" ]] || fail 'API contract matrix missing'
for token in 'HTTPS termination' 'Authentication and token issuer/audience/expiry validation' 'Resource ownership/participant authorization' 'Rate limiting and bounded pagination/body-size checks' 'Idempotency and normalized request-hash checks' 'Stable response/error contract' 'AI/work-analysis boundary' 'Anti-bypass boundary'; do
  grep -Fq "$token" "$DOC" || fail "API contract requirement missing: $token"
done
for area in 'Auth/session' 'Jobs' 'Proposals' 'Contracts' 'Messages' 'Work submission' 'AI analysis' 'Payment/escrow' 'Webhooks' 'Refunds' 'Disputes' 'Trust & safety' 'Admin'; do
  grep -Fq "| $area |" "$MATRIX" || fail "API matrix area missing: $area"
done
if grep -RInE 'http://(localhost|127\.0\.0\.1)|password["'"']?\s*[:=]\s*["'"'][^"'"']+' backend/API_CONTRACT_COMPLETENESS_V47_200.md backend/API_CONTRACT_MATRIX_V47_200.md >/dev/null 2>&1; then
  fail 'local/insecure or populated credential-like value found in API contract docs'
fi
pass 'v51.900 API contract completeness, authorization, financial and safety-boundary checks'
