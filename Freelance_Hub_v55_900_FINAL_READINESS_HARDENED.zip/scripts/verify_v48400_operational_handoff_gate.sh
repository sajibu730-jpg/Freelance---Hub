#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
f(){ echo "FAIL: $*" >&2; exit 1; }; p(){ echo "PASS: $*"; }
[[ "$(tr -d '\r\n' < VERSION.txt)" == '48.400.0' ]] || f 'VERSION.txt mismatch'
grep -Fq 'versionCode = 48400' app/build.gradle.kts || f 'Gradle versionCode mismatch'
grep -Fq 'versionName = "48.400.0"' app/build.gradle.kts || f 'Gradle versionName mismatch'
[[ -s V46_801_TO_V47_200_PRODUCTION_OPERATIONAL_RESILIENCE.md ]] || f 'range hardening document missing'
[[ -s RELEASE_V47_200_CHANGELOG.md ]] || f 'release changelog missing'
for wf in .github/workflows/android-build.yml .github/workflows/android-production.yml; do
  grep -Fq '48.400.0' "$wf" || f "version identity missing: $wf"
  grep -Fq '48400' "$wf" || f "version code missing: $wf"
  grep -Fq 'verify_v48400_operational_handoff_gate.sh' "$wf" || f "operational handoff gate missing: $wf"
done
! grep -RInE '46\.800\.0|46800|v46800|46_800' .github/workflows scripts/verify_v48400_*.sh backend ops --exclude='verify_v48400_operational_handoff_gate.sh' >/dev/null 2>&1 || f 'stale v46.800 reference in active v48.400 surface'
! grep -RInE 'BEGIN (RSA|EC|OPENSSH) PRIVATE KEY|sk_live_[A-Za-z0-9_-]+' .github/workflows backend ops scripts --exclude='*.sha256' >/dev/null 2>&1 || f 'credential/private-key pattern detected'
for s in scripts/verify_v48400_*.sh; do [[ -x "$s" ]] || f "not executable: $s"; bash -n "$s" || f "syntax error: $s"; done
p 'v48.400 operational handoff, version identity, stale-reference and credential hygiene checks'
