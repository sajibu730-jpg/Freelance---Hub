#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"
RULE="app/src/main/java/com/freelancehub/app/data/EndToEndMarketplaceRules.kt"
test -s "$RULE"
grep -q 'NORMAL_HIRING_WINDOW_HOURS = 24' "$RULE"
grep -q 'EMERGENCY_TOTAL_HOURS = 6' "$RULE"
grep -q 'EMERGENCY_PHASE_HOURS = 3' "$RULE"
grep -q 'EMERGENCY_PHASE_DISTRIBUTION_LIMIT = 50' "$RULE"
grep -q 'aiMayFinalizeOutcome(): Boolean = false' "$RULE"
grep -q 'clientMayFinalizePrivilegedOutcome(): Boolean = false' "$RULE"
grep -q 'covertMonitoringAllowed(): Boolean = false' "$RULE"
grep -q 'closedIdentityMayReopenAccount(identityReusable: Boolean): Boolean = false' "$RULE"
printf 'PASS: v53.900 end-to-end marketplace lifecycle gate\n'
