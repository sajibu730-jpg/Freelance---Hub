#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

grep -q '^29\.700\.0$' VERSION.txt
grep -q 'versionCode = 29700; versionName = "29.700.0"' app/build.gradle.kts

grep -q 'AUTH_REFRESH_REUSE_DETECTED' backend/AUTH_API_IMPLEMENTATION.md
grep -q 'Conversation participant authorization' backend/RESOURCE_API_CONTRACT_v29_700.md
grep -q 'Duplicate payment webhook' backend/STAGING_INTEGRATION_TEST_PLAN_v29_700.md
grep -q 'Invalid webhook signature' backend/STAGING_INTEGRATION_TEST_PLAN_v29_700.md
grep -q 'Real identity provider configured' backend/PRODUCTION_READINESS_BOUNDARY_v29_700.md

for t in api_idempotency_records payment_webhook_events api_audit_events; do
  grep -q "CREATE TABLE IF NOT EXISTS $t" BACKEND_SCHEMA.sql
  grep -q "ALTER TABLE $t ENABLE ROW LEVEL SECURITY;" BACKEND_RLS.sql
  grep -q "ALTER TABLE $t FORCE ROW LEVEL SECURITY;" BACKEND_RLS.sql
done

# Production secrets must never be present in source.
if grep -RniE 'sk_(live|test)_[A-Za-z0-9]+|whsec_[A-Za-z0-9]+|-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----' backend app/src .github 2>/dev/null; then
  echo 'Potential production secret material detected' >&2
  exit 1
fi

# CI must run this exact gate and advertise the same release.
grep -q 'verify_v29700_production_integration_boundary.sh' .github/workflows/android-build.yml
grep -q 'verify_v29700_production_integration_boundary.sh' .github/workflows/android-production.yml
grep -q '29.700' .github/workflows/android-build.yml
grep -q '29.700' .github/workflows/android-production.yml
grep -q '29700' .github/workflows/android-build.yml
grep -q '29700' .github/workflows/android-production.yml

# Evidence metadata must not carry stale version identifiers.
if grep -RniE 'Version: 29\.(10[0-9]|200|400)|Evidence Version: 29\.(10[0-9]|200|400)|Version Code: 29400' .github/workflows; then
  echo 'Stale workflow version metadata detected' >&2
  exit 1
fi

echo 'Auth rotation/reuse boundary: PASS'
echo 'Resource authorization contract: PASS'
echo 'Staging integration plan: PASS'
echo 'RLS/idempotency/webhook/audit boundaries: PASS'
echo 'Secret scan: PASS'
echo 'Workflow version/evidence alignment: PASS'
echo 'Freelance Hub v29.700 production integration boundary gate: PASS'
