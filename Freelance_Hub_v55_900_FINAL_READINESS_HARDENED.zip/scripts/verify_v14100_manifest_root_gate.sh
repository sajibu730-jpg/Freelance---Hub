#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
manifest=SOURCE_RELEASE_MANIFEST_v14.100.sha256; root=SOURCE_RELEASE_MANIFEST_v14.100.root.sha256
test -f "$manifest"; test -f "$root"
test "$(cat "$root")" = "$(sha256sum "$manifest" | awk '{print $1}')"
bash scripts/verify_v14100_release_manifest_gate.sh
printf "v14.100 manifest root gate: PASS\n"
