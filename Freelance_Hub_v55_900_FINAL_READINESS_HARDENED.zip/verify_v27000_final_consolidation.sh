#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
test "$(cat VERSION.txt)" = "27.000.0"
grep -q 'versionCode = 27000' app/build.gradle.kts
grep -q 'sourceType' openapi.yaml
grep -q 'evidenceIds' openapi.yaml
test -f app/src/main/java/com/freelancehub/app/security/ModerationAuditAccessRules.kt
test -f app/src/main/java/com/freelancehub/app/security/ModerationEvidenceTraceRules.kt
test -f app/src/test/java/com/freelancehub/app/security/ModerationAuditAccessRulesTest.kt
test -f app/src/test/java/com/freelancehub/app/security/ModerationEvidenceTraceRulesTest.kt
! grep -RInE 'TODO|FIXME|IMPLEMENT_ME|YOUR_' app/src/main/java .github/workflows 2>/dev/null
echo 'Freelance Hub v27.000 final consolidation static audit: PASS'
