# Production Authentication Boundary — v9.600

The Android client must not authenticate users locally or treat SharedPreferences as an identity authority.

## Required production flow
1. Client sends signup/login request over HTTPS to the configured backend.
2. Backend validates credentials, account status, role and rate limits.
3. Backend returns a short-lived access token and refresh mechanism according to the deployed auth provider.
4. Android stores only the minimum session material using Android Keystore-backed storage.
5. Every protected API request is authorized server-side; client-side role checks are UX safeguards only.
6. Logout/revocation invalidates the server-side session/refresh token.

## Configuration
The build must supply `backendBaseUrl` and `backendProjectId`. Empty or `example.com` configuration is not production-valid.

No password, API secret, signing key, database credential or service-account key belongs in the APK or repository.

## Current status
The source baseline contains the secure transport and token-storage foundations, but a live backend/auth provider and deployment credentials are external prerequisites. Until those are supplied and tested, the app must not present local/demo sign-in as production authentication.
