# Freelance Hub v9.600 — Remote Profile UI Wiring

Status: source-level implementation complete; Android compilation/device verification remains pending because this environment does not contain the Android SDK/Gradle executable.

## Active production-flow changes
- Profile display loads from `GET /me` through `RemoteAccountRepository`.
- Profile editing uses `PATCH /me` through `RemoteAccountRepository`.
- Access token comes from `TokenStore`; profile UI has no local SharedPreferences fallback.
- Profile save uses an idempotency key and runs network work off the main thread.
- The active Profile tab no longer uses the legacy local `AppRepository` profile editor.
- `bio` is included in the remote account model and OpenAPI `User` contract.

## Boundary
Legacy local profile code remains in source only for historical compatibility. It is not the active Profile-tab authority.

## Verification
`bash scripts/verify_v9600_source_reproducibility_gate.sh` => PASS

This PASS verifies source/release-manifest integrity only. It does not prove APK compilation, live backend connectivity, or real-device behavior.
