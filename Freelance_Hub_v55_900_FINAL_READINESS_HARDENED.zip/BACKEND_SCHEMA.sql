CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Provider-neutral relational baseline for the production backend.
-- Apply server-side authorization/RLS policies before exposing these tables.
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('FREELANCER','CLIENT')),
  bio TEXT NOT NULL DEFAULT '',
  capabilities TEXT NOT NULL DEFAULT '',
  skills JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE jobs (
  id UUID PRIMARY KEY,
  client_id UUID NOT NULL REFERENCES users(id),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  budget_minor BIGINT NOT NULL CHECK (budget_minor >= 0),
  currency CHAR(3) NOT NULL,
  skills JSONB NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','PAUSED','CLOSED','COMPLETED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE proposals (
  id UUID PRIMARY KEY,
  job_id UUID NOT NULL REFERENCES jobs(id),
  freelancer_id UUID NOT NULL REFERENCES users(id),
  cover_letter TEXT NOT NULL,
  bid_minor BIGINT NOT NULL CHECK (bid_minor >= 0),
  currency CHAR(3) NOT NULL,
  delivery_days INT NOT NULL CHECK (delivery_days > 0),
  status TEXT NOT NULL DEFAULT 'SUBMITTED' CHECK (status IN ('SUBMITTED','SHORTLISTED','ACCEPTED','REJECTED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(job_id, freelancer_id)
);

CREATE INDEX jobs_client_id_idx ON jobs(client_id);
CREATE INDEX jobs_status_created_idx ON jobs(status, created_at DESC);
CREATE INDEX proposals_job_id_idx ON proposals(job_id);
CREATE INDEX proposals_freelancer_id_idx ON proposals(freelancer_id);


-- Feature foundations: skills, project requirements, work checks and trust reports.
ALTER TABLE users ADD COLUMN IF NOT EXISTS skill_levels JSONB NOT NULL DEFAULT '{}';
ALTER TABLE users ADD COLUMN IF NOT EXISTS capabilities TEXT NOT NULL DEFAULT '';

CREATE TABLE IF NOT EXISTS job_requirements (
  id UUID PRIMARY KEY,
  job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  requirement TEXT NOT NULL,
  required BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS work_checks (
  id UUID PRIMARY KEY,
  job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  freelancer_id UUID NOT NULL REFERENCES users(id),
  submission_ref TEXT NOT NULL,
  score INT NOT NULL CHECK (score BETWEEN 0 AND 100),
  status TEXT NOT NULL CHECK (status IN ('NEEDS_IMPROVEMENT','READY_FOR_REVIEW')),
  matched_requirements JSONB NOT NULL DEFAULT '[]',
  missing_requirements JSONB NOT NULL DEFAULT '[]',
  suggestions JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS trust_reports (
  id UUID PRIMARY KEY,
  reporter_id UUID NOT NULL REFERENCES users(id),
  reported_user_id UUID REFERENCES users(id),
  job_id UUID REFERENCES jobs(id),
  reason TEXT NOT NULL,
  evidence_ref TEXT,
  status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','UNDER_REVIEW','RESOLVED','DISMISSED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- Production data foundations for portfolio, messaging, work delivery and reviews.
ALTER TABLE users ADD COLUMN IF NOT EXISTS portfolio_summary TEXT NOT NULL DEFAULT '';
ALTER TABLE users ADD COLUMN IF NOT EXISTS portfolio_links JSONB NOT NULL DEFAULT '[]';

CREATE TABLE IF NOT EXISTS work_submissions (
  id UUID PRIMARY KEY,
  job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  freelancer_id UUID NOT NULL REFERENCES users(id),
  summary TEXT NOT NULL,
  file_links JSONB NOT NULL DEFAULT '[]',
  check_score INT NOT NULL DEFAULT 0 CHECK (check_score BETWEEN 0 AND 100),
  status TEXT NOT NULL DEFAULT 'SUBMITTED' CHECK (status IN ('SUBMITTED','CHANGES_REQUESTED','APPROVED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS reviews (
  id UUID PRIMARY KEY,
  job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  reviewer_id UUID NOT NULL REFERENCES users(id),
  reviewee_id UUID NOT NULL REFERENCES users(id),
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(job_id, reviewer_id)
);

CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY,
  job_id UUID NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES users(id),
  recipient_id UUID NOT NULL REFERENCES users(id),
  body TEXT NOT NULL,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY,
  audience_id UUID REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS work_submissions_job_idx ON work_submissions(job_id, created_at DESC);
CREATE INDEX IF NOT EXISTS reviews_reviewee_idx ON reviews(reviewee_id, created_at DESC);
CREATE INDEX IF NOT EXISTS messages_recipient_idx ON messages(recipient_id, created_at DESC);
CREATE INDEX IF NOT EXISTS messages_job_idx ON messages(job_id, created_at DESC);
CREATE INDEX IF NOT EXISTS notifications_audience_idx ON notifications(audience_id, created_at DESC);

-- Work delivery lifecycle extensions: structured freelancer analysis, review feedback and revision history.
CREATE TABLE IF NOT EXISTS work_submission_revisions (
  id UUID PRIMARY KEY,
  submission_id UUID NOT NULL REFERENCES work_submissions(id) ON DELETE CASCADE,
  version INT NOT NULL CHECK (version > 0),
  summary TEXT NOT NULL,
  file_links JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(submission_id, version)
);

CREATE TABLE IF NOT EXISTS work_analyses (
  id UUID PRIMARY KEY,
  submission_id UUID NOT NULL REFERENCES work_submissions(id) ON DELETE CASCADE,
  freelancer_id UUID NOT NULL REFERENCES users(id),
  completed_requirements TEXT NOT NULL,
  issues TEXT NOT NULL DEFAULT '',
  solutions TEXT NOT NULL DEFAULT '',
  results TEXT NOT NULL DEFAULT '',
  future_improvements TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS work_review_feedback (
  id UUID PRIMARY KEY,
  submission_id UUID NOT NULL REFERENCES work_submissions(id) ON DELETE CASCADE,
  reviewer_id UUID NOT NULL REFERENCES users(id),
  status TEXT NOT NULL CHECK (status IN ('CHANGES_REQUESTED','APPROVED')),
  comment TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS work_revisions_submission_idx ON work_submission_revisions(submission_id, version DESC);
CREATE INDEX IF NOT EXISTS work_analyses_submission_idx ON work_analyses(submission_id, created_at DESC);
CREATE INDEX IF NOT EXISTS work_review_feedback_submission_idx ON work_review_feedback(submission_id, created_at DESC);


-- Hiring and contract lifecycle: an accepted proposal creates one authoritative assignment/contract.
CREATE TABLE IF NOT EXISTS contracts (
  id UUID PRIMARY KEY,
  job_id UUID NOT NULL UNIQUE REFERENCES jobs(id) ON DELETE CASCADE,
  proposal_id UUID NOT NULL UNIQUE REFERENCES proposals(id),
  client_id UUID NOT NULL REFERENCES users(id),
  freelancer_id UUID NOT NULL REFERENCES users(id),
  agreed_budget_minor BIGINT NOT NULL CHECK (agreed_budget_minor >= 0),
  currency CHAR(3) NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','WORK_SUBMITTED','CHANGES_REQUESTED','APPROVED','COMPLETED','CANCELLED','DISPUTED')),
  started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS contracts_client_idx ON contracts(client_id, created_at DESC);
CREATE INDEX IF NOT EXISTS contracts_freelancer_idx ON contracts(freelancer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS contracts_status_idx ON contracts(status, updated_at DESC);

ALTER TABLE work_submissions ADD COLUMN IF NOT EXISTS contract_id UUID REFERENCES contracts(id);
CREATE INDEX IF NOT EXISTS work_submissions_contract_idx ON work_submissions(contract_id, created_at DESC);


-- v9.700 contract integrity hardening: server-side consistency and lifecycle transitions.
CREATE OR REPLACE FUNCTION enforce_contract_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  p_job_id UUID;
  p_freelancer_id UUID;
  j_client_id UUID;
BEGIN
  SELECT p.job_id, p.freelancer_id INTO p_job_id, p_freelancer_id
  FROM proposals p WHERE p.id = NEW.proposal_id;

  IF p_job_id IS NULL OR p_job_id <> NEW.job_id THEN
    RAISE EXCEPTION 'contract proposal/job mismatch';
  END IF;

  SELECT j.client_id INTO j_client_id FROM jobs j WHERE j.id = NEW.job_id;
  IF j_client_id IS NULL OR j_client_id <> NEW.client_id THEN
    RAISE EXCEPTION 'contract client/job mismatch';
  END IF;

  IF p_freelancer_id IS NULL OR p_freelancer_id <> NEW.freelancer_id THEN
    RAISE EXCEPTION 'contract freelancer/proposal mismatch';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS contracts_integrity_trigger ON contracts;
CREATE TRIGGER contracts_integrity_trigger
BEFORE INSERT OR UPDATE ON contracts
FOR EACH ROW EXECUTE FUNCTION enforce_contract_integrity();

CREATE OR REPLACE FUNCTION enforce_contract_status_transition()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status <> 'ACTIVE' THEN
      RAISE EXCEPTION 'new contracts must start ACTIVE';
    END IF;
    RETURN NEW;
  END IF;

  IF NEW.status = OLD.status THEN
    RETURN NEW;
  END IF;

  IF OLD.status = 'ACTIVE' AND NEW.status NOT IN ('WORK_SUBMITTED','CANCELLED','DISPUTED') THEN
    RAISE EXCEPTION 'invalid contract transition % -> %', OLD.status, NEW.status;
  ELSIF OLD.status = 'WORK_SUBMITTED' AND NEW.status NOT IN ('CHANGES_REQUESTED','APPROVED','DISPUTED') THEN
    RAISE EXCEPTION 'invalid contract transition % -> %', OLD.status, NEW.status;
  ELSIF OLD.status = 'CHANGES_REQUESTED' AND NEW.status NOT IN ('WORK_SUBMITTED','DISPUTED') THEN
    RAISE EXCEPTION 'invalid contract transition % -> %', OLD.status, NEW.status;
  ELSIF OLD.status = 'APPROVED' AND NEW.status NOT IN ('COMPLETED','DISPUTED') THEN
    RAISE EXCEPTION 'invalid contract transition % -> %', OLD.status, NEW.status;
  ELSIF OLD.status = 'DISPUTED' AND NEW.status NOT IN ('ACTIVE','CANCELLED','COMPLETED') THEN
    RAISE EXCEPTION 'invalid contract transition % -> %', OLD.status, NEW.status;
  ELSIF OLD.status IN ('COMPLETED','CANCELLED') THEN
    RAISE EXCEPTION 'terminal contract status cannot transition';
  END IF;

  IF NEW.status = 'COMPLETED' AND NEW.completed_at IS NULL THEN
    NEW.completed_at := NOW();
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS contracts_status_transition_trigger ON contracts;
CREATE TRIGGER contracts_status_transition_trigger
BEFORE INSERT OR UPDATE OF status, completed_at ON contracts
FOR EACH ROW EXECUTE FUNCTION enforce_contract_status_transition();


-- v9.800 payment/escrow integrity hardening: provider-independent transaction and ledger boundaries.
CREATE TABLE IF NOT EXISTS payment_transactions (
  id UUID PRIMARY KEY,
  contract_id UUID NOT NULL UNIQUE REFERENCES contracts(id) ON DELETE RESTRICT,
  client_id UUID NOT NULL REFERENCES users(id),
  freelancer_id UUID NOT NULL REFERENCES users(id),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','FUNDED','RELEASE_REQUESTED','RELEASED','REFUNDED','CANCELLED','DISPUTED')),
  idempotency_key TEXT NOT NULL UNIQUE,
  provider_reference TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS payment_transactions_client_idx ON payment_transactions(client_id, created_at DESC);
CREATE INDEX IF NOT EXISTS payment_transactions_freelancer_idx ON payment_transactions(freelancer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS payment_transactions_status_idx ON payment_transactions(status, updated_at DESC);

CREATE TABLE IF NOT EXISTS wallet_ledger_entries (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  contract_id UUID REFERENCES contracts(id) ON DELETE RESTRICT,
  payment_id UUID REFERENCES payment_transactions(id) ON DELETE RESTRICT,
  direction TEXT NOT NULL CHECK (direction IN ('CREDIT','DEBIT')),
  entry_type TEXT NOT NULL CHECK (entry_type IN ('FUND','HOLD','RELEASE','REFUND','FEE','ADJUSTMENT')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  idempotency_key TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS wallet_ledger_user_idx ON wallet_ledger_entries(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS wallet_ledger_contract_idx ON wallet_ledger_entries(contract_id, created_at DESC);

CREATE OR REPLACE FUNCTION enforce_payment_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  c_client_id UUID;
  c_freelancer_id UUID;
  c_budget BIGINT;
  c_currency CHAR(3);
BEGIN
  SELECT client_id, freelancer_id, agreed_budget_minor, currency
    INTO c_client_id, c_freelancer_id, c_budget, c_currency
  FROM contracts WHERE id = NEW.contract_id;

  IF c_client_id IS NULL THEN RAISE EXCEPTION 'payment contract not found'; END IF;
  IF NEW.client_id <> c_client_id OR NEW.freelancer_id <> c_freelancer_id THEN
    RAISE EXCEPTION 'payment participant/contract mismatch';
  END IF;
  IF NEW.amount_minor <> c_budget OR NEW.currency <> c_currency THEN
    RAISE EXCEPTION 'payment amount/currency must match contract';
  END IF;

  IF TG_OP = 'UPDATE' AND (NEW.contract_id <> OLD.contract_id OR NEW.client_id <> OLD.client_id OR NEW.freelancer_id <> OLD.freelancer_id OR NEW.amount_minor <> OLD.amount_minor OR NEW.currency <> OLD.currency OR NEW.idempotency_key <> OLD.idempotency_key) THEN
    RAISE EXCEPTION 'immutable payment identity fields cannot change';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS payment_integrity_trigger ON payment_transactions;
CREATE TRIGGER payment_integrity_trigger
BEFORE INSERT OR UPDATE ON payment_transactions
FOR EACH ROW EXECUTE FUNCTION enforce_payment_integrity();

CREATE OR REPLACE FUNCTION enforce_payment_status_transition()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status <> 'PENDING' THEN RAISE EXCEPTION 'new payments must start PENDING'; END IF;
    RETURN NEW;
  END IF;
  IF NEW.status = OLD.status THEN RETURN NEW; END IF;
  IF OLD.status = 'PENDING' AND NEW.status NOT IN ('FUNDED','CANCELLED') THEN
    RAISE EXCEPTION 'invalid payment transition % -> %', OLD.status, NEW.status;
  ELSIF OLD.status = 'FUNDED' AND NEW.status NOT IN ('RELEASE_REQUESTED','REFUNDED','DISPUTED') THEN
    RAISE EXCEPTION 'invalid payment transition % -> %', OLD.status, NEW.status;
  ELSIF OLD.status = 'RELEASE_REQUESTED' AND NEW.status NOT IN ('RELEASED','DISPUTED') THEN
    RAISE EXCEPTION 'invalid payment transition % -> %', OLD.status, NEW.status;
  ELSIF OLD.status = 'DISPUTED' AND NEW.status NOT IN ('REFUNDED','RELEASED') THEN
    RAISE EXCEPTION 'invalid payment transition % -> %', OLD.status, NEW.status;
  ELSIF OLD.status IN ('RELEASED','REFUNDED','CANCELLED') THEN
    RAISE EXCEPTION 'terminal payment status cannot transition';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS payment_status_transition_trigger ON payment_transactions;
CREATE TRIGGER payment_status_transition_trigger
BEFORE INSERT OR UPDATE OF status ON payment_transactions
FOR EACH ROW EXECUTE FUNCTION enforce_payment_status_transition();

CREATE OR REPLACE FUNCTION enforce_ledger_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  p_contract UUID;
  p_client UUID;
  p_freelancer UUID;
BEGIN
  IF NEW.payment_id IS NULL THEN RETURN NEW; END IF;
  SELECT contract_id, client_id, freelancer_id INTO p_contract, p_client, p_freelancer
  FROM payment_transactions WHERE id = NEW.payment_id;
  IF p_contract IS NULL THEN RAISE EXCEPTION 'ledger payment not found'; END IF;
  IF NEW.contract_id IS DISTINCT FROM p_contract THEN RAISE EXCEPTION 'ledger contract/payment mismatch'; END IF;
  IF NEW.user_id NOT IN (p_client, p_freelancer) THEN RAISE EXCEPTION 'ledger user/payment participant mismatch'; END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS ledger_integrity_trigger ON wallet_ledger_entries;
CREATE TRIGGER ledger_integrity_trigger
BEFORE INSERT OR UPDATE ON wallet_ledger_entries
FOR EACH ROW EXECUTE FUNCTION enforce_ledger_integrity();


-- v29.200 production API safety primitives: replay-safe idempotency and verified payment webhook inbox.
CREATE TABLE IF NOT EXISTS api_idempotency_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  scope_key TEXT NOT NULL,
  actor_id UUID REFERENCES users(id) ON DELETE SET NULL,
  request_hash CHAR(64) NOT NULL CHECK (request_hash ~ '^[0-9a-f]{64}$'),
  response_code INT NOT NULL CHECK (response_code BETWEEN 100 AND 599),
  response_body JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMPTZ NOT NULL,
  UNIQUE(scope_key, actor_id)
);
CREATE INDEX IF NOT EXISTS api_idempotency_expiry_idx ON api_idempotency_records(expires_at);

CREATE TABLE IF NOT EXISTS payment_webhook_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider TEXT NOT NULL CHECK (length(btrim(provider)) BETWEEN 2 AND 80),
  provider_event_id TEXT NOT NULL CHECK (length(btrim(provider_event_id)) BETWEEN 1 AND 200),
  event_type TEXT NOT NULL CHECK (length(btrim(event_type)) BETWEEN 1 AND 120),
  payload_hash CHAR(64) NOT NULL CHECK (payload_hash ~ '^[0-9a-f]{64}$'),
  signature_verified BOOLEAN NOT NULL,
  processing_status TEXT NOT NULL DEFAULT 'RECEIVED'
    CHECK (processing_status IN ('RECEIVED','PROCESSING','PROCESSED','IGNORED','FAILED')),
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  processed_at TIMESTAMPTZ,
  failure_code TEXT,
  UNIQUE(provider, provider_event_id)
);
CREATE INDEX IF NOT EXISTS payment_webhook_status_idx ON payment_webhook_events(processing_status, received_at DESC);

CREATE TABLE IF NOT EXISTS api_audit_events (
  id BIGSERIAL PRIMARY KEY,
  request_id TEXT NOT NULL CHECK (length(btrim(request_id)) BETWEEN 8 AND 200),
  actor_id UUID REFERENCES users(id) ON DELETE SET NULL,
  route TEXT NOT NULL CHECK (length(btrim(route)) BETWEEN 1 AND 300),
  method TEXT NOT NULL CHECK (method IN ('GET','POST','PUT','PATCH','DELETE')),
  outcome TEXT NOT NULL CHECK (outcome IN ('SUCCESS','CLIENT_ERROR','AUTH_ERROR','RATE_LIMITED','SERVER_ERROR')),
  status_code INT NOT NULL CHECK (status_code BETWEEN 100 AND 599),
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS api_audit_actor_idx ON api_audit_events(actor_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS api_audit_request_idx ON api_audit_events(request_id);


-- v9.900 dispute/refund integrity hardening: auditable case and refund boundaries.
CREATE TABLE IF NOT EXISTS dispute_cases (
  id UUID PRIMARY KEY,
  contract_id UUID NOT NULL REFERENCES contracts(id) ON DELETE RESTRICT,
  payment_id UUID REFERENCES payment_transactions(id) ON DELETE RESTRICT,
  opened_by UUID NOT NULL REFERENCES users(id),
  respondent_id UUID NOT NULL REFERENCES users(id),
  reason TEXT NOT NULL CHECK (length(btrim(reason)) BETWEEN 10 AND 2000),
  evidence_ref TEXT,
  status TEXT NOT NULL DEFAULT 'OPEN'
    CHECK (status IN ('OPEN','UNDER_REVIEW','RESOLVED_REFUND','RESOLVED_RELEASE','DISMISSED','WITHDRAWN')),
  resolution_note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS dispute_cases_contract_idx ON dispute_cases(contract_id, created_at DESC);
CREATE INDEX IF NOT EXISTS dispute_cases_status_idx ON dispute_cases(status, updated_at DESC);

CREATE TABLE IF NOT EXISTS refund_requests (
  id UUID PRIMARY KEY,
  payment_id UUID NOT NULL REFERENCES payment_transactions(id) ON DELETE RESTRICT,
  contract_id UUID NOT NULL REFERENCES contracts(id) ON DELETE RESTRICT,
  requester_id UUID NOT NULL REFERENCES users(id),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  reason TEXT NOT NULL CHECK (length(btrim(reason)) BETWEEN 10 AND 2000),
  status TEXT NOT NULL DEFAULT 'REQUESTED'
    CHECK (status IN ('REQUESTED','APPROVED','REJECTED','PROCESSING','COMPLETED','FAILED')),
  idempotency_key TEXT NOT NULL UNIQUE,
  provider_reference TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS refund_requests_payment_idx ON refund_requests(payment_id, created_at DESC);
CREATE INDEX IF NOT EXISTS refund_requests_requester_idx ON refund_requests(requester_id, created_at DESC);

CREATE OR REPLACE FUNCTION enforce_dispute_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  p_client UUID;
  p_freelancer UUID;
  p_contract UUID;
BEGIN
  SELECT client_id, freelancer_id, contract_id INTO p_client, p_freelancer, p_contract
  FROM payment_transactions WHERE id = NEW.payment_id;

  IF NEW.payment_id IS NOT NULL AND p_contract IS NULL THEN
    RAISE EXCEPTION 'dispute payment not found';
  END IF;
  IF NEW.payment_id IS NOT NULL AND p_contract <> NEW.contract_id THEN
    RAISE EXCEPTION 'dispute payment/contract mismatch';
  END IF;
  SELECT client_id, freelancer_id INTO p_client, p_freelancer
  FROM contracts WHERE id = NEW.contract_id;
  IF p_client IS NULL THEN RAISE EXCEPTION 'dispute contract not found'; END IF;
  IF NEW.opened_by NOT IN (p_client, p_freelancer) OR NEW.respondent_id NOT IN (p_client, p_freelancer) OR NEW.opened_by = NEW.respondent_id THEN
    RAISE EXCEPTION 'dispute participants must be the contract participants';
  END IF;
  IF TG_OP = 'UPDATE' AND (NEW.contract_id <> OLD.contract_id OR NEW.payment_id IS DISTINCT FROM OLD.payment_id OR NEW.opened_by <> OLD.opened_by OR NEW.respondent_id <> OLD.respondent_id) THEN
    RAISE EXCEPTION 'dispute identity fields cannot change';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS dispute_integrity_trigger ON dispute_cases;
CREATE TRIGGER dispute_integrity_trigger
BEFORE INSERT OR UPDATE ON dispute_cases
FOR EACH ROW EXECUTE FUNCTION enforce_dispute_integrity();

CREATE OR REPLACE FUNCTION enforce_dispute_transition()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status <> 'OPEN' THEN RAISE EXCEPTION 'new disputes must start OPEN'; END IF;
    RETURN NEW;
  END IF;
  IF NEW.status = OLD.status THEN RETURN NEW; END IF;
  IF OLD.status = 'OPEN' AND NEW.status NOT IN ('UNDER_REVIEW','WITHDRAWN') THEN
    RAISE EXCEPTION 'invalid dispute transition';
  ELSIF OLD.status = 'UNDER_REVIEW' AND NEW.status NOT IN ('RESOLVED_REFUND','RESOLVED_RELEASE','DISMISSED') THEN
    RAISE EXCEPTION 'invalid dispute transition';
  ELSIF OLD.status IN ('RESOLVED_REFUND','RESOLVED_RELEASE','DISMISSED','WITHDRAWN') THEN
    RAISE EXCEPTION 'terminal dispute status cannot transition';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS dispute_status_transition_trigger ON dispute_cases;
CREATE TRIGGER dispute_status_transition_trigger
BEFORE INSERT OR UPDATE OF status ON dispute_cases
FOR EACH ROW EXECUTE FUNCTION enforce_dispute_transition();

CREATE OR REPLACE FUNCTION enforce_refund_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  p_contract UUID;
  p_client UUID;
  p_freelancer UUID;
  p_amount BIGINT;
  p_currency CHAR(3);
BEGIN
  SELECT contract_id, client_id, freelancer_id, amount_minor, currency
    INTO p_contract, p_client, p_freelancer, p_amount, p_currency
  FROM payment_transactions WHERE id = NEW.payment_id;

  IF p_contract IS NULL THEN RAISE EXCEPTION 'refund payment not found'; END IF;
  IF NEW.contract_id <> p_contract OR NEW.currency <> p_currency OR NEW.amount_minor > p_amount THEN
    RAISE EXCEPTION 'refund payment/contract/amount mismatch';
  END IF;
  IF NEW.requester_id NOT IN (p_client, p_freelancer) THEN
    RAISE EXCEPTION 'refund requester must be a payment participant';
  END IF;
  IF TG_OP = 'UPDATE' AND (NEW.payment_id <> OLD.payment_id OR NEW.contract_id <> OLD.contract_id OR NEW.requester_id <> OLD.requester_id OR NEW.amount_minor <> OLD.amount_minor OR NEW.currency <> OLD.currency OR NEW.idempotency_key <> OLD.idempotency_key) THEN
    RAISE EXCEPTION 'refund identity fields cannot change';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS refund_integrity_trigger ON refund_requests;
CREATE TRIGGER refund_integrity_trigger
BEFORE INSERT OR UPDATE ON refund_requests
FOR EACH ROW EXECUTE FUNCTION enforce_refund_integrity();

CREATE OR REPLACE FUNCTION enforce_refund_transition()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status <> 'REQUESTED' THEN RAISE EXCEPTION 'new refunds must start REQUESTED'; END IF;
    RETURN NEW;
  END IF;
  IF NEW.status = OLD.status THEN RETURN NEW; END IF;
  IF OLD.status = 'REQUESTED' AND NEW.status NOT IN ('APPROVED','REJECTED') THEN
    RAISE EXCEPTION 'invalid refund transition';
  ELSIF OLD.status = 'APPROVED' AND NEW.status <> 'PROCESSING' THEN
    RAISE EXCEPTION 'invalid refund transition';
  ELSIF OLD.status = 'PROCESSING' AND NEW.status NOT IN ('COMPLETED','FAILED') THEN
    RAISE EXCEPTION 'invalid refund transition';
  ELSIF OLD.status IN ('REJECTED','COMPLETED','FAILED') THEN
    RAISE EXCEPTION 'terminal refund status cannot transition';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS refund_status_transition_trigger ON refund_requests;
CREATE TRIGGER refund_status_transition_trigger
BEFORE INSERT OR UPDATE OF status ON refund_requests
FOR EACH ROW EXECUTE FUNCTION enforce_refund_transition();

-- v10.000: Trust & Safety enforcement integrity.
CREATE TABLE IF NOT EXISTS moderation_cases (
  id UUID PRIMARY KEY,
  report_id UUID REFERENCES trust_reports(id),
  subject_user_id UUID NOT NULL REFERENCES users(id),
  opened_by UUID NOT NULL REFERENCES users(id),
  reason_code TEXT NOT NULL,
  evidence_ref TEXT,
  status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','UNDER_REVIEW','RESOLVED','DISMISSED')),
  resolution_code TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS account_enforcements (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id),
  moderation_case_id UUID NOT NULL REFERENCES moderation_cases(id),
  action TEXT NOT NULL CHECK (action IN ('WARNING','LIMITED','SUSPENDED','CLOSED','REINSTATED')),
  reason_code TEXT NOT NULL,
  starts_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ends_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE OR REPLACE FUNCTION enforce_moderation_case_integrity()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.report_id IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM trust_reports r
      WHERE r.id = NEW.report_id
        AND (r.reported_user_id = NEW.subject_user_id OR r.reporter_id = NEW.opened_by)
    ) THEN
      RAISE EXCEPTION 'moderation case must bind to the reported subject or reporter';
    END IF;
  END IF;
  IF TG_OP = 'UPDATE' AND (
    NEW.report_id IS DISTINCT FROM OLD.report_id OR
    NEW.subject_user_id <> OLD.subject_user_id OR
    NEW.opened_by <> OLD.opened_by OR
    NEW.reason_code <> OLD.reason_code
  ) THEN
    RAISE EXCEPTION 'moderation case identity fields cannot change';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS moderation_case_integrity_trigger ON moderation_cases;
CREATE TRIGGER moderation_case_integrity_trigger
BEFORE INSERT OR UPDATE ON moderation_cases
FOR EACH ROW EXECUTE FUNCTION enforce_moderation_case_integrity();

CREATE OR REPLACE FUNCTION enforce_moderation_case_transition()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF NEW.status <> 'OPEN' THEN RAISE EXCEPTION 'new moderation cases must start OPEN'; END IF;
    RETURN NEW;
  END IF;
  IF NEW.status = OLD.status THEN RETURN NEW; END IF;
  IF OLD.status = 'OPEN' AND NEW.status <> 'UNDER_REVIEW' THEN
    RAISE EXCEPTION 'invalid moderation case transition';
  ELSIF OLD.status = 'UNDER_REVIEW' AND NEW.status NOT IN ('RESOLVED','DISMISSED') THEN
    RAISE EXCEPTION 'invalid moderation case transition';
  ELSIF OLD.status IN ('RESOLVED','DISMISSED') THEN
    RAISE EXCEPTION 'terminal moderation case status cannot transition';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS moderation_case_status_transition_trigger ON moderation_cases;
CREATE TRIGGER moderation_case_status_transition_trigger
BEFORE INSERT OR UPDATE OF status ON moderation_cases
FOR EACH ROW EXECUTE FUNCTION enforce_moderation_case_transition();

CREATE OR REPLACE FUNCTION enforce_account_enforcement_integrity()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM moderation_cases m
    WHERE m.id = NEW.moderation_case_id AND m.subject_user_id = NEW.user_id
  ) THEN
    RAISE EXCEPTION 'enforcement must bind to the moderation subject';
  END IF;
  IF NEW.ends_at IS NOT NULL AND NEW.ends_at <= NEW.starts_at THEN
    RAISE EXCEPTION 'enforcement end must be after start';
  END IF;
  IF TG_OP = 'UPDATE' THEN
    RAISE EXCEPTION 'account enforcement records are immutable';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS account_enforcement_integrity_trigger ON account_enforcements;
CREATE TRIGGER account_enforcement_integrity_trigger
BEFORE INSERT OR UPDATE ON account_enforcements
FOR EACH ROW EXECUTE FUNCTION enforce_account_enforcement_integrity();


-- v10.100 trust/safety evidence-chain hardening: append-only, ordered, server-derived integrity evidence.

CREATE TABLE IF NOT EXISTS trust_safety_evidence_events (
  id UUID PRIMARY KEY,
  case_id UUID NOT NULL REFERENCES moderation_cases(id) ON DELETE RESTRICT,
  sequence_no BIGINT NOT NULL CHECK (sequence_no > 0),
  event_type TEXT NOT NULL CHECK (event_type IN (
    'CASE_OPENED','CASE_REVIEW_STARTED','CASE_RESOLVED','CASE_DISMISSED',
    'ENFORCEMENT_APPLIED','ENFORCEMENT_REINSTATED'
  )),
  actor_id UUID NOT NULL REFERENCES users(id),
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  payload JSONB NOT NULL DEFAULT '{}',
  previous_hash CHAR(64),
  event_hash CHAR(64) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(case_id, sequence_no),
  UNIQUE(case_id, event_hash)
);

CREATE INDEX IF NOT EXISTS trust_safety_evidence_case_idx
  ON trust_safety_evidence_events(case_id, sequence_no);

CREATE OR REPLACE FUNCTION enforce_trust_safety_evidence_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  previous_event trust_safety_evidence_events%ROWTYPE;
  expected_hash TEXT;
BEGIN
  IF TG_OP <> 'INSERT' THEN
    RAISE EXCEPTION 'trust/safety evidence is append-only';
  END IF;

  SELECT * INTO previous_event
  FROM trust_safety_evidence_events
  WHERE case_id = NEW.case_id
  ORDER BY sequence_no DESC
  LIMIT 1
  FOR UPDATE;

  IF previous_event.id IS NULL THEN
    IF NEW.sequence_no <> 1 OR NEW.previous_hash IS NOT NULL THEN
      RAISE EXCEPTION 'first evidence event must start at sequence 1 without previous hash';
    END IF;
  ELSE
    IF NEW.sequence_no <> previous_event.sequence_no + 1 THEN
      RAISE EXCEPTION 'evidence sequence must be contiguous';
    END IF;
    IF NEW.previous_hash IS NULL OR NEW.previous_hash <> previous_event.event_hash THEN
      RAISE EXCEPTION 'evidence previous hash mismatch';
    END IF;
    IF NEW.occurred_at < previous_event.occurred_at THEN
      RAISE EXCEPTION 'evidence timestamp cannot move backwards';
    END IF;
  END IF;

  expected_hash := encode(digest(
    COALESCE(NEW.case_id::text,'') || '|' ||
    NEW.sequence_no::text || '|' ||
    NEW.event_type || '|' ||
    NEW.actor_id::text || '|' ||
    NEW.occurred_at::text || '|' ||
    NEW.payload::text || '|' ||
    COALESCE(NEW.previous_hash,''),
    'sha256'
  ), 'hex');

  IF NEW.event_hash <> expected_hash THEN
    RAISE EXCEPTION 'evidence event hash mismatch';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trust_safety_evidence_integrity_trigger ON trust_safety_evidence_events;
CREATE TRIGGER trust_safety_evidence_integrity_trigger
BEFORE INSERT OR UPDATE OR DELETE ON trust_safety_evidence_events
FOR EACH ROW EXECUTE FUNCTION enforce_trust_safety_evidence_integrity();

CREATE OR REPLACE FUNCTION block_trust_safety_evidence_delete()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE EXCEPTION 'trust/safety evidence cannot be deleted';
END;
$$;

DROP TRIGGER IF EXISTS trust_safety_evidence_delete_trigger ON trust_safety_evidence_events;
CREATE TRIGGER trust_safety_evidence_delete_trigger
BEFORE DELETE ON trust_safety_evidence_events
FOR EACH ROW EXECUTE FUNCTION block_trust_safety_evidence_delete();

-- v10.200 security-incident lifecycle: server-controlled, append-only incident audit trail.
CREATE TABLE IF NOT EXISTS security_incidents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  severity TEXT NOT NULL CHECK (severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
  state TEXT NOT NULL CHECK (state IN ('OPEN','TRIAGED','CONTAINED','RECOVERING','RESOLVED','CLOSED')),
  summary TEXT NOT NULL CHECK (length(summary) BETWEEN 1 AND 2000),
  created_by UUID NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS security_incident_events (
  id BIGSERIAL PRIMARY KEY,
  incident_id UUID NOT NULL REFERENCES security_incidents(id),
  sequence_no BIGINT NOT NULL CHECK (sequence_no > 0),
  from_state TEXT,
  to_state TEXT NOT NULL,
  action_type TEXT NOT NULL CHECK (action_type IN ('CONTAIN','INVESTIGATE','RECOVER','VERIFY','NOTIFY')),
  actor_id UUID NOT NULL REFERENCES users(id),
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  evidence_hash TEXT NOT NULL CHECK (evidence_hash ~ '^[0-9a-f]{64}$'),
  previous_hash TEXT,
  UNIQUE (incident_id, sequence_no),
  UNIQUE (incident_id, evidence_hash)
);

CREATE INDEX IF NOT EXISTS security_incident_events_incident_idx
  ON security_incident_events(incident_id, sequence_no);

-- v10.300: server-side lifecycle transition enforcement and immutable incident identity.
-- v10.700: server-derived incident evidence hashes prevent client-supplied hash forgery.
-- v10.800: evidence-chain anchor validation requires a strict previous-hash/state link.
CREATE OR REPLACE FUNCTION enforce_security_incident_transition()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP <> 'UPDATE' THEN RETURN NEW; END IF;
  IF NEW.id IS DISTINCT FROM OLD.id
     OR NEW.created_by IS DISTINCT FROM OLD.created_by
     OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
    RAISE EXCEPTION 'security incident identity fields are immutable';
  END IF;
  IF NEW.state IS DISTINCT FROM OLD.state THEN
    IF NOT (
      (OLD.state = 'OPEN' AND NEW.state IN ('TRIAGED','CONTAINED')) OR
      (OLD.state = 'TRIAGED' AND NEW.state IN ('CONTAINED','RESOLVED')) OR
      (OLD.state = 'CONTAINED' AND NEW.state IN ('RECOVERING','RESOLVED')) OR
      (OLD.state = 'RECOVERING' AND NEW.state = 'RESOLVED') OR
      (OLD.state = 'RESOLVED' AND NEW.state = 'CLOSED')
    ) THEN
      RAISE EXCEPTION 'invalid security incident state transition';
    END IF;
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS security_incident_transition_trigger ON security_incidents;
CREATE TRIGGER security_incident_transition_trigger
BEFORE UPDATE ON security_incidents
FOR EACH ROW EXECUTE FUNCTION enforce_security_incident_transition();

CREATE OR REPLACE FUNCTION enforce_security_incident_event_integrity()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE prev security_incident_events%ROWTYPE; incident security_incidents%ROWTYPE; expected_hash TEXT;
BEGIN
  IF TG_OP <> 'INSERT' THEN RAISE EXCEPTION 'security incident events are append-only'; END IF;
  SELECT * INTO incident FROM security_incidents WHERE id = NEW.incident_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'security incident not found'; END IF;
  IF NEW.sequence_no = 1 THEN
    IF NEW.previous_hash IS NOT NULL OR NEW.from_state IS NOT NULL THEN
      RAISE EXCEPTION 'first incident event cannot have previous state/hash';
    END IF;
    IF NEW.to_state <> 'OPEN' OR NEW.action_type <> 'NOTIFY' THEN
      RAISE EXCEPTION 'first incident event must open the incident with NOTIFY';
    END IF;
    IF incident.state <> NEW.to_state THEN
      RAISE EXCEPTION 'first incident event must match incident state';
    END IF;
  ELSE
    IF NEW.previous_hash IS NULL OR NEW.previous_hash !~ '^[0-9a-f]{64}$' THEN
      RAISE EXCEPTION 'non-first incident event requires a valid previous hash';
    END IF;
    IF NEW.from_state IS NULL THEN
      RAISE EXCEPTION 'non-first incident event requires a from_state';
    END IF;
    SELECT * INTO prev FROM security_incident_events
    WHERE incident_id = NEW.incident_id AND sequence_no = NEW.sequence_no - 1;
    IF NOT FOUND THEN RAISE EXCEPTION 'incident event sequence gap'; END IF;
    IF NEW.previous_hash IS DISTINCT FROM prev.evidence_hash THEN RAISE EXCEPTION 'incident event hash chain mismatch'; END IF;
    IF NEW.from_state IS DISTINCT FROM prev.to_state THEN RAISE EXCEPTION 'incident state chain mismatch'; END IF;
    IF incident.state IS DISTINCT FROM NEW.from_state THEN
      RAISE EXCEPTION 'incident current state does not match event from_state';
    END IF;
    IF NOT (
      (NEW.from_state = 'OPEN' AND NEW.to_state IN ('TRIAGED','CONTAINED')) OR
      (NEW.from_state = 'TRIAGED' AND NEW.to_state IN ('CONTAINED','RESOLVED')) OR
      (NEW.from_state = 'CONTAINED' AND NEW.to_state IN ('RECOVERING','RESOLVED')) OR
      (NEW.from_state = 'RECOVERING' AND NEW.to_state = 'RESOLVED') OR
      (NEW.from_state = 'RESOLVED' AND NEW.to_state = 'CLOSED')
    ) THEN
      RAISE EXCEPTION 'incident event state transition is invalid';
    END IF;
    IF NEW.occurred_at <= prev.occurred_at THEN
      RAISE EXCEPTION 'incident event timestamp must strictly increase';
    END IF;
  END IF;
  IF NEW.actor_id IS NULL THEN
    RAISE EXCEPTION 'security incident event actor is required';
  END IF;
  IF NEW.evidence_hash !~ '^[0-9a-f]{64}$' THEN
    RAISE EXCEPTION 'invalid security incident evidence hash';
  END IF;
  expected_hash := encode(digest(
    NEW.incident_id::text || '|' ||
    NEW.sequence_no::text || '|' ||
    COALESCE(NEW.from_state,'') || '|' ||
    NEW.to_state || '|' ||
    NEW.action_type || '|' ||
    NEW.actor_id::text || '|' ||
    NEW.occurred_at::text || '|' ||
    COALESCE(NEW.previous_hash,''),
    'sha256'
  ), 'hex');
  NEW.evidence_hash := expected_hash;
  IF NEW.to_state NOT IN ('OPEN','TRIAGED','CONTAINED','RECOVERING','RESOLVED','CLOSED') THEN
    RAISE EXCEPTION 'invalid security incident event state';
  END IF;
  IF NEW.action_type NOT IN ('CONTAIN','INVESTIGATE','RECOVER','VERIFY','NOTIFY') THEN
    RAISE EXCEPTION 'invalid security incident event action';
  END IF;
  IF (NEW.to_state = 'OPEN' AND NEW.action_type <> 'NOTIFY')
     OR (NEW.to_state = 'TRIAGED' AND NEW.action_type <> 'INVESTIGATE')
     OR (NEW.to_state = 'CONTAINED' AND NEW.action_type <> 'CONTAIN')
     OR (NEW.to_state = 'RECOVERING' AND NEW.action_type <> 'RECOVER')
     OR (NEW.to_state IN ('RESOLVED','CLOSED') AND NEW.action_type <> 'VERIFY') THEN
    RAISE EXCEPTION 'security incident action does not match target state';
  END IF;
  IF NEW.occurred_at > now() + interval '5 minutes' THEN
    RAISE EXCEPTION 'security incident event timestamp is too far in the future';
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION apply_security_incident_event_state()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  UPDATE security_incidents
     SET state = NEW.to_state, updated_at = now()
   WHERE id = NEW.incident_id;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS security_incident_event_integrity_trigger ON security_incident_events;
CREATE TRIGGER security_incident_event_integrity_trigger
BEFORE INSERT OR UPDATE OR DELETE ON security_incident_events
FOR EACH ROW EXECUTE FUNCTION enforce_security_incident_event_integrity();

DROP TRIGGER IF EXISTS security_incident_event_state_trigger ON security_incident_events;
CREATE TRIGGER security_incident_event_state_trigger
AFTER INSERT ON security_incident_events
FOR EACH ROW EXECUTE FUNCTION apply_security_incident_event_state();

-- v42.000 payment/financial integrity hardening: immutable ledger, provider identity,
-- refund ceiling, webhook verification boundary, and idempotency expiry safety.
ALTER TABLE payment_transactions
  ADD COLUMN IF NOT EXISTS provider TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS payment_provider_reference_uq
  ON payment_transactions(provider, provider_reference)
  WHERE provider IS NOT NULL AND provider_reference IS NOT NULL;

ALTER TABLE payment_transactions
  ADD CONSTRAINT payment_provider_name_chk
  CHECK (provider IS NULL OR length(btrim(provider)) BETWEEN 2 AND 80);

CREATE OR REPLACE FUNCTION enforce_payment_provider_reference()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.provider_reference IS NOT NULL AND NEW.provider IS NULL THEN
    RAISE EXCEPTION 'provider reference requires provider name';
  END IF;
  IF TG_OP = 'UPDATE'
     AND (NEW.provider IS DISTINCT FROM OLD.provider
          OR NEW.provider_reference IS DISTINCT FROM OLD.provider_reference)
     AND OLD.provider_reference IS NOT NULL THEN
    RAISE EXCEPTION 'provider identity is immutable once recorded';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS payment_provider_reference_trigger ON payment_transactions;
CREATE TRIGGER payment_provider_reference_trigger
BEFORE INSERT OR UPDATE ON payment_transactions
FOR EACH ROW EXECUTE FUNCTION enforce_payment_provider_reference();

CREATE OR REPLACE FUNCTION block_ledger_mutation()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE EXCEPTION 'wallet ledger entries are append-only';
END;
$$;

DROP TRIGGER IF EXISTS wallet_ledger_immutable_trigger ON wallet_ledger_entries;
CREATE TRIGGER wallet_ledger_immutable_trigger
BEFORE UPDATE OR DELETE ON wallet_ledger_entries
FOR EACH ROW EXECUTE FUNCTION block_ledger_mutation();

CREATE OR REPLACE FUNCTION enforce_ledger_financial_integrity()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  p_amount BIGINT;
  p_currency CHAR(3);
  p_status TEXT;
BEGIN
  IF NEW.payment_id IS NULL THEN RETURN NEW; END IF;
  SELECT amount_minor, currency, status
    INTO p_amount, p_currency, p_status
  FROM payment_transactions
  WHERE id = NEW.payment_id
  FOR UPDATE;

  IF p_amount IS NULL THEN
    RAISE EXCEPTION 'ledger payment not found';
  END IF;
  IF NEW.currency <> p_currency THEN
    RAISE EXCEPTION 'ledger currency/payment currency mismatch';
  END IF;
  IF NEW.amount_minor > p_amount THEN
    RAISE EXCEPTION 'ledger entry exceeds authoritative payment amount';
  END IF;
  IF NEW.entry_type IN ('FUND','HOLD','RELEASE','REFUND')
     AND p_status = 'CANCELLED' THEN
    RAISE EXCEPTION 'financial ledger mutation is not allowed for cancelled payment';
  END IF;
  IF NEW.entry_type = 'FUND' AND NEW.direction <> 'CREDIT' THEN
    RAISE EXCEPTION 'FUND ledger entry must be CREDIT';
  ELSIF NEW.entry_type = 'HOLD' AND NEW.direction <> 'DEBIT' THEN
    RAISE EXCEPTION 'HOLD ledger entry must be DEBIT';
  ELSIF NEW.entry_type = 'RELEASE' AND NEW.direction <> 'CREDIT' THEN
    RAISE EXCEPTION 'RELEASE ledger entry must be CREDIT';
  ELSIF NEW.entry_type = 'REFUND' AND NEW.direction <> 'CREDIT' THEN
    RAISE EXCEPTION 'REFUND ledger entry must be CREDIT';
  ELSIF NEW.entry_type = 'FEE' AND NEW.direction <> 'DEBIT' THEN
    RAISE EXCEPTION 'FEE ledger entry must be DEBIT';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS ledger_financial_integrity_trigger ON wallet_ledger_entries;
CREATE TRIGGER ledger_financial_integrity_trigger
BEFORE INSERT ON wallet_ledger_entries
FOR EACH ROW EXECUTE FUNCTION enforce_ledger_financial_integrity();

CREATE OR REPLACE FUNCTION enforce_refund_financial_ceiling()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
  p_amount BIGINT;
  p_currency CHAR(3);
  p_status TEXT;
  already_refunded BIGINT;
BEGIN
  SELECT amount_minor, currency, status
    INTO p_amount, p_currency, p_status
  FROM payment_transactions
  WHERE id = NEW.payment_id
  FOR UPDATE;

  IF p_amount IS NULL THEN
    RAISE EXCEPTION 'refund payment not found';
  END IF;
  IF NEW.currency <> p_currency THEN
    RAISE EXCEPTION 'refund currency mismatch';
  END IF;
  IF p_status NOT IN ('FUNDED','DISPUTED') THEN
    RAISE EXCEPTION 'refund requires a funded or disputed payment';
  END IF;

  SELECT COALESCE(SUM(amount_minor), 0)
    INTO already_refunded
  FROM refund_requests
  WHERE payment_id = NEW.payment_id
    AND status IN ('APPROVED','PROCESSING','COMPLETED')
    AND (TG_OP = 'INSERT' OR id <> NEW.id);

  IF already_refunded + NEW.amount_minor > p_amount THEN
    RAISE EXCEPTION 'cumulative refund amount exceeds payment amount';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS refund_financial_ceiling_trigger ON refund_requests;
CREATE TRIGGER refund_financial_ceiling_trigger
BEFORE INSERT OR UPDATE OF payment_id, amount_minor, currency, status ON refund_requests
FOR EACH ROW EXECUTE FUNCTION enforce_refund_financial_ceiling();

CREATE OR REPLACE FUNCTION enforce_webhook_processing_verification()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.processing_status IN ('PROCESSING','PROCESSED') AND NOT NEW.signature_verified THEN
    RAISE EXCEPTION 'unverified payment webhook cannot mutate financial state';
  END IF;
  IF NEW.processing_status = 'PROCESSED' AND NEW.processed_at IS NULL THEN
    NEW.processed_at := NOW();
  ELSIF NEW.processing_status <> 'PROCESSED' AND NEW.processed_at IS NOT NULL THEN
    RAISE EXCEPTION 'processed_at is only valid for PROCESSED webhooks';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS webhook_processing_verification_trigger ON payment_webhook_events;
CREATE TRIGGER webhook_processing_verification_trigger
BEFORE INSERT OR UPDATE ON payment_webhook_events
FOR EACH ROW EXECUTE FUNCTION enforce_webhook_processing_verification();

CREATE OR REPLACE FUNCTION enforce_idempotency_expiry()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.expires_at <= NEW.created_at THEN
    RAISE EXCEPTION 'idempotency record must expire after creation';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS api_idempotency_expiry_trigger ON api_idempotency_records;
CREATE TRIGGER api_idempotency_expiry_trigger
BEFORE INSERT OR UPDATE ON api_idempotency_records
FOR EACH ROW EXECUTE FUNCTION enforce_idempotency_expiry();
