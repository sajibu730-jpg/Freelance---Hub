# Freelance Hub v23.800 — Production Data / Network Boundary Hardening

This milestone adds a static CI gate for the production data and network boundary.

## Verified
- Android INTERNET permission is present.
- Manifest cleartext traffic is disabled.
- Network Security Config is attached and denies cleartext traffic.
- Secure session SharedPreferences are excluded from cloud backup and device transfer.
- Session tokens use Android Keystore-backed AES/GCM storage.
- Backend endpoint and project ID are injected through BuildConfig rather than hardcoded source values.
- API transport requires HTTPS and rejects URL user-info/fragments.
- Authorization header handling remains centralized in SecureApiClient.
- Obvious localhost/example endpoints are rejected in Android source.

## Scope boundary
This is a source/CI integrity gate. It does not prove that a live backend, database, RLS policy, payment provider, or deployed HTTPS certificate is operational. Those require the production environment and credentials.

Verification command:
`bash scripts/verify_v23800_production_data_boundary.sh`
