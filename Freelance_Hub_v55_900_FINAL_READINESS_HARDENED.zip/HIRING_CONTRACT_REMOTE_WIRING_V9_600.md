# Hiring + Contract Remote Wiring — v9.600

This increment makes hiring/assignment an explicit server-authoritative boundary between proposals and work delivery.

## Added
- Accept-proposal client contract call with idempotency key.
- Contract retrieval by job.
- Authenticated participant contract listing.
- Provider-neutral `contracts` schema with unique job/proposal ownership.
- Work submissions can reference the authoritative contract.
- OpenAPI contract definitions for contract reads.

## Authorization boundary
- Only the job client may accept a proposal.
- Contract reads are limited to the client/freelancer participants.
- Work submission endpoints must require the freelancer assigned by the contract.
- A job may have at most one active contract.
- Client/freelancer IDs must be derived server-side; never trusted from the Android payload.

## Production boundary
The Android contract is wired, but no live production backend is deployed in this environment. Actual authorization/RLS and transaction behavior must be verified against the deployed service before release.
