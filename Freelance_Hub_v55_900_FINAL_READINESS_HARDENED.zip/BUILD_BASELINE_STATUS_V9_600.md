# Freelance Hub v9.600 — Build Baseline Status

## Verified in source package
- Android Gradle Plugin: 8.6.1
- Kotlin: 2.0.21
- Gradle CI version: 8.10.2
- Java toolchain: 17
- Release minification/shrinking enabled
- Production workflow runs the source-reproducibility gate before Gradle
- Production workflow requires backend and release-signing secrets
- Production workflow verifies the resulting APK with `apksigner`

## Environment-dependent
- This package does not claim a successful local Gradle build. The current execution environment has no Gradle executable and no Android SDK installation.
- CI remains the authoritative build environment until a real GitHub Actions run produces the APK evidence artifacts.

## Authentication baseline
- A local `logged_in` preference is no longer an authentication authority.
- Access/refresh tokens are protected with Android Keystore-backed AES/GCM storage.
- Refresh-token rotation is represented by `/auth/refresh`.
- Backend authentication remains required; no local/demo password validation is present.
