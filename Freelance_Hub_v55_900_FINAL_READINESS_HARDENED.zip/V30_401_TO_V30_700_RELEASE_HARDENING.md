# Freelance Hub v30.401 → v30.700 Release Hardening

## v30.500 — Runtime configuration boundary
- Backend URL and project ID remain build-time injected through `BuildConfig`.
- Release gate rejects non-example hard-coded HTTP(S) endpoints in Kotlin source.
- Version is consolidated to `30.700.0` / `30700` for the completed range.

## v30.600 — Android security boundary
- Cleartext network traffic is disabled at manifest and network-security-config levels.
- Secure session preferences are excluded from legacy backup and modern cloud/device transfer.
- Session tokens are stored with Android Keystore AES/GCM.
- Insecure debug/cleartext resource flags are rejected by the gate.

## v30.700 — Release evidence consolidation
- Final workflow gate chains the runtime-config and Android-security gates.
- Workflow evidence is aligned to version `30.700.0` / code `30700`.
- Stale v30.000/v30.400 evidence metadata is rejected.

## Verification boundary
Static repository/CI gates were executed successfully. A real Android release build still requires the configured CI toolchain, and a production-signed build requires the user's GitHub secrets/keystore and production backend configuration.
