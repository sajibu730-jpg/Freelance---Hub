# v9.600 Marketplace Remote UI Wiring

- Active Jobs tab now loads jobs from `RemoteMarketplaceRepository` only.
- Active client Post Job flow publishes through `POST /jobs` with an idempotency key.
- Active freelancer proposal flow publishes through `POST /jobs/{jobId}/proposals` with an idempotency key.
- Active job detail is server-backed and does not use `DemoJobs` for the Jobs tab.
- Legacy local marketplace functions remain in `AppRepository` for non-active/legacy features and are not the source of truth for the active Jobs tab.
- Actual compile/device/backend integration remains pending because this environment does not contain the Android SDK/Gradle executable and the production backend is not deployed.
