# v51.400.0 Changelog

Marketplace Governance & Assurance hardening across server authorization, matching, accountability, appeals, payment idempotency, recovery evidence, AI advisory boundaries, privacy disclosure, and release provenance.
