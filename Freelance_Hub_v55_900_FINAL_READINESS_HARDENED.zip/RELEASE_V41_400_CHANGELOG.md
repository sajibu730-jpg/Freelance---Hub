# Freelance Hub v41.400.0

## Production provenance hardening
- Added GitHub Actions OIDC/build-provenance attestation for release artifacts.
- Production workflow now attests both the signed APK and AAB.
- Verification workflow attests the verification APK provenance.
- Added a release provenance integrity gate that checks version metadata, permissions, attestation wiring, and stale artifact labels.
- Updated release artifact labels and metadata to v41.400 / versionCode 41400.

## Validation boundary
This release adds source/workflow-side provenance controls. Actual production signing, backend secrets, GitHub-hosted build execution, and device/Play validation still require the corresponding external environment and credentials.
