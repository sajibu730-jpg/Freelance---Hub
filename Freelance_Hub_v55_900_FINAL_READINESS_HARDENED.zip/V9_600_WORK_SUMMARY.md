# Freelance Hub v9.600 — Work Summary

- Version: 9.600.0
- Version Code: 2840
- Advanced the active CI gate from v9.500 provenance verification to exact source-reproducibility verification.
- Added exact source-inventory coverage checks so every release-source file must appear once in the immutable SHA-256 manifest.
- Added manifest-only/source-only mismatch diagnostics with fail-closed behavior.
- Preserved deterministic APK checksum/build-metadata evidence requirements.
- Preserved release hardening, shell syntax, secret-hygiene, and production-boundary checks.
- Generated a new immutable source-release manifest for the v9.600 snapshot.

Validation is performed against the source package. A real Gradle APK build is not claimed unless a provisioned Android build environment executes the workflow.

## Communication UI wiring — current correction
- The Messages tab is now wired to `RemoteCommunicationRepository`.
- Legacy local message/conversation UI paths were removed from the active navigation flow.
- Network work is dispatched off the main thread.
- Remote failures do not fall back to local communication data.
- The active communication UI remains disabled until a valid production backend is configured.
- Live end-to-end verification still requires a deployed API and authenticated Android test run.


## Profile remote UI wiring
- Active Profile tab now reads and updates the authenticated profile through `RemoteAccountRepository` (`GET /me`, `PATCH /me`).
- `bio` is included in the remote account model and OpenAPI User contract.
- Local profile storage is no longer the active Profile-tab authority.
- Verification: source-reproducibility gate PASS after manifest regeneration.
- See `PROFILE_REMOTE_UI_WIRING_V9_600.md`.


## Work Delivery + Freelancer Analysis extension

Added server-backed work submission, structured freelancer analysis, client review/revision status, revision-history API contracts, and production database foundations. See `WORK_DELIVERY_ANALYSIS_V9_600.md`.
