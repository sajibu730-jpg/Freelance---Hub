# Freelance Hub v9.600 — Home Dashboard Remote UI Wiring

The active Home/Dashboard route now uses the server-backed marketplace and account repositories.

## Boundary
- Account identity/display data: `RemoteAccountRepository.currentUser()`
- Job counts/list: `RemoteMarketplaceRepository.listJobs(50)`
- No `DemoJobs` or local `AppRepository` data is used by the active Home route.
- Dashboard refreshes through the configured backend and reports request failures instead of silently substituting demo data.

## Verification boundary
This is source-level wiring verification. Android compilation and real backend end-to-end verification remain pending until a CI runner/device with the required SDK and deployed backend configuration is available.
