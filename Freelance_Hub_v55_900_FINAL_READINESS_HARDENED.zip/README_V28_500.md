# Freelance Hub v28.500

## v28.201 → v28.500 — Moderation Audit Export Purpose Binding

This milestone adds an explicit business-purpose contract to moderation-audit exports.

- Supported purposes: `COMPLIANCE_REVIEW`, `INCIDENT_REVIEW`, `LEGAL_HOLD`.
- `COMPLIANCE_REVIEWER` is restricted to `COMPLIANCE_REVIEW` exports.
- `ADMIN` may use any defined purpose.
- Ordinary moderators remain unable to export.
- The OpenAPI request contract now requires `purpose`.
- Export authorization failures include purpose/role mismatch in the `403` contract.

This is a contract/security hardening milestone; it does not claim production backend deployment, real-world authorization enforcement, or a signed release APK.
