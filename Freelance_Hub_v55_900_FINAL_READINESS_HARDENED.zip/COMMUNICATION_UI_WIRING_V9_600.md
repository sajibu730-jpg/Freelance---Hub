# Communication UI Wiring — v9.600

The Messages tab now uses the server-backed communication repository instead of the legacy local message/notification data path.

## Runtime boundary

- `RemoteCommunicationRepository` is the source for conversations, messages, and notifications in the Messages tab.
- Network work is dispatched off the main thread.
- The UI does not fall back to local `SharedPreferences` data when the remote API fails.
- An unconfigured production backend leaves remote communication disabled and shows an explicit state.
- Message and notification mutations use the authenticated access token and server-side authorization.

## Verification boundary

This wiring is source-level verified. A live end-to-end PASS still requires a deployed API and authenticated Android test run.
