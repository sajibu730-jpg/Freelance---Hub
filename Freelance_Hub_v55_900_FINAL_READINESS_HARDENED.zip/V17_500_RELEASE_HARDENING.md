# Freelance Hub v17.500 — Source/CI Release Hardening

This release boundary continues source and CI hardening from v17.300 through v17.500.

## Enforced boundary
1. Android versionCode is 8500.
2. Android versionName is 17.500.0.
3. Production workflow permissions remain least-privilege.
4. Mutable workflow branch references remain prohibited.
5. Java 17 and Gradle 8.10.2 remain pinned.
6. Secret material detection remains enabled.
7. Release evidence and manifest continuity are maintained.
8. Production gates remain explicit and are not falsely marked complete.

## Not claimed by this boundary
- Successful production APK/AAB compilation.
- Release signing or keystore validation.
- Live backend/database deployment.
- Live payment gateway/webhook activation.
- Real-device smoke testing.
- Google Play publication.
