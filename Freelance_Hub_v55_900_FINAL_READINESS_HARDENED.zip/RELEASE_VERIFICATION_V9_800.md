# Freelance Hub v9.800 — Payment & Escrow Integrity Verification

## Active controls
- Version 9.800.0 / Version Code 2860 must match VERSION.txt, Gradle configuration, CI evidence, and the active source gate.
- Payment transactions use unique idempotency keys and immutable identity fields.
- Server-side triggers enforce contract participants, amount/currency consistency, and valid payment status transitions.
- Wallet ledger entries are bound to the referenced payment and one of its participants.
- RLS permits participant reads while financial mutations remain server-controlled.
- CI must run the source gate before Gradle and fail closed on missing release evidence or credential material.

## Production boundary
A passing source gate does not establish a live payment provider, verified webhooks, deployed database/RLS, production signing, real-device testing, or Play Console publication.
