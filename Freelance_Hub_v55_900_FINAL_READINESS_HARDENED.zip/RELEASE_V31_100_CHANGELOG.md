# Freelance Hub v31.100.0 — Release Hardening Changelog

- Bumped Android versionCode to 31100 and versionName to 31.100.0.
- Replaced stale v30 production-boundary workflow dependencies with v31.100 gates.
- Added explicit v31.100 artifact-integrity and deployment/recovery gates.
- Kept production signing and backend credentials externalized to GitHub Actions secrets.
- Production APK/AAB generation remains gated on real signing credentials and backend configuration.
