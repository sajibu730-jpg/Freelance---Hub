# Freelance Hub v15.100 — Release Hardening Notes

This range advances the release-integrity baseline from v14.900 to v15.100 across the major-version boundary.

## Hardening changes

- Adds a dedicated v14.901 → v15.100 continuity ledger with 200 sequential version/code transitions.
- Adds explicit major-version boundary validation so the ledger cannot silently skip from v14.999 to v15.001.
- Adds source release manifest and manifest-root verification for the v15.100 source snapshot.
- Adds workflow-policy and production-provenance checks for the active v15.100 workflows.
- Keeps release signing material outside the source tree and requires production secrets through CI configuration.
- Updates the active Android release to v15.100.0 / versionCode 6290.

## Boundary

A source/CI gate PASS does not by itself prove that a real production backend is deployed, that a physical Android device has been tested, that Play Console testing has passed, or that the release has been published.
