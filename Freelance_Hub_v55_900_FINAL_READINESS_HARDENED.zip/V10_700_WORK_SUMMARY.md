# Freelance Hub v10.700 — Incident Evidence Hash Integrity

- Security incident evidence hashes are now server-derived from canonical incident event fields.
- Client-supplied evidence_hash values are validated for shape, then replaced by the server-derived SHA-256 value before insert.
- Canonical field ordering is mirrored in Android lifecycle rules for deterministic request construction.
- Added Android unit coverage for canonical evidence input ordering.
- Added dedicated v10.700 verification gate and wired it into Android build/production workflows.
- Version: 10.700.0; Version Code: 2970.
