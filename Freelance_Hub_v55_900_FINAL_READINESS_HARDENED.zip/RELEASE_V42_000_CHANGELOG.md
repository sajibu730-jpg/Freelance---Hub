# Release v42.000.0

- Hardened payment provider identity and reference uniqueness.
- Made wallet ledger entries append-only.
- Added payment-linked ledger amount/currency and direction invariants.
- Added cumulative refund ceiling and payment-state restrictions.
- Added webhook verification/processing boundary.
- Added idempotency expiry validation.
- Added v42.000 payment/financial integrity CI gate.
- Android versionCode: 42000; versionName: 42.000.0.
