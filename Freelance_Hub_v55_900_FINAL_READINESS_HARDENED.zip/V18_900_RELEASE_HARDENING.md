# Freelance Hub v18.900 — Source/CI Release Hardening

This release boundary continues source/CI hardening from v18.700 through v18.900.

## Enforced boundary
1. Android versionCode is 9900.
2. Android versionName is 18.900.0.
3. The v18.701 → v18.900 ledger contains exactly 200 checkpoints.
4. Active workflows use least-privilege read-only repository/action permissions.
5. Active workflows use immutable action major-version references and reject mutable branch refs.
6. Repository-local release gates run only after checkout.
7. Current v18.900 boundary verification is required by both Android workflows.
8. Historical release gates are retained as evidence, but are not treated as current production proof.
9. Private-key material is rejected by the source boundary check.
10. Current release evidence must identify v18.900 / code 9900.

## Not claimed by this boundary
- Successful production APK/AAB compilation in this environment.
- Release signing or keystore validation.
- Live backend/database deployment.
- Live payment gateway/webhook activation.
- Real-device smoke testing.
- Google Play publication.
