# Freelance Hub v11.500 — Release Evidence Index Hardening

## Scope
The release pipeline now binds generated APK artifacts to a machine-checkable evidence index.

## Changes
- Added `scripts/verify_v11500_release_evidence_gate.sh`.
- Added `scripts/verify_v11500_release_evidence_selfcheck.sh`.
- Both verification and production workflows generate `RELEASE_EVIDENCE_INDEX.txt` after build/evidence generation.
- The index records APK filename, byte size, and SHA-256 plus hashes of `BUILD_METADATA.txt` and `SHA256SUMS.txt`.
- Self-check recomputes all APK hashes/sizes and evidence-file hashes before artifact upload.
- Release version bumped to 11.500.0 / Version Code 3050.
- Source manifest and root regenerated after all changes.

## Boundary
This hardening validates source/workflow/evidence integrity. It does not claim a real APK build or device test until GitHub Actions and a real device execute those steps.
