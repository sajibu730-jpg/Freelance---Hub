# Authentication API implementation contract — v29.700

## Required server boundary

The Android client may call `/auth/signup`, `/auth/login`, `/auth/refresh`, and `/auth/logout`, but token issuance, password verification, account status, email verification, and refresh-token rotation are server/provider responsibilities.

### Access token
- Short-lived access token.
- Validate issuer, audience, expiry, signature, and account lifecycle state on every protected request.
- Never accept a client-supplied role as authorization.

### Refresh token
- Rotate on every successful refresh.
- Revoke the previous token family on replay/reuse detection.
- Store only a secure hash/reference server-side; never log raw refresh tokens.

### Account lifecycle
- Enforce unique verified email/identity according to the deployed identity provider.
- Closed/suspended accounts cannot authenticate or refresh.
- Reinstatement requires an explicit server-side state transition.

### Email verification
- Verification token is single-use, time-limited, and server-generated.
- Signup does not grant privileged access before required verification.

### Required audit events
`AUTH_SIGNUP`, `AUTH_LOGIN_SUCCESS`, `AUTH_LOGIN_FAILURE`, `AUTH_REFRESH`, `AUTH_REFRESH_REUSE_DETECTED`, `AUTH_LOGOUT`, `AUTH_EMAIL_VERIFIED`, `AUTH_ACCOUNT_BLOCKED`.

No passwords, JWT signing keys, database credentials, refresh tokens, payment secrets, or provider service keys may be stored in the Android project or repository.
