# Privacy and Data Lifecycle Contract — v46.000

## Required controls
- Collect only fields required for the stated product purpose.
- Classify identity, financial, communication, moderation and AI-analysis data before processing.
- Redact sensitive fields from operational logs, analytics and exported evidence unless strictly required.
- Data export must be scoped, authenticated, time-bounded and auditable.
- Deletion requests must produce verifiable evidence while preserving legally/operationally required immutable financial and safety records.
- Rectification must not rewrite append-only financial ledger history or moderation evidence; corrections are additive and auditable.
- Retention decisions must have an owner, purpose and review date.
- AI work-analysis inputs must not be repurposed into training/marketing data by default; provider use must follow explicit production configuration and contract.

## Fail-closed requirements
Missing purpose, scope, authorization, retention decision or redaction policy blocks export/release evidence generation.
