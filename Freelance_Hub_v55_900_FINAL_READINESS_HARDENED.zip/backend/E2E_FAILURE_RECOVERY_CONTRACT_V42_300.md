# Freelance Hub v42.300 — End-to-End Failure & Recovery Contract

This document defines the release-time E2E contract. It does **not** claim that a live staging or production backend has been deployed or tested.

## Core flow
1. Signup → verification → login.
2. Login → protected API access → token expiry/refresh rotation.
3. Create job → retrieve job → submit proposal → authorization check.
4. Contract creation → valid state transition → participant messaging.
5. Payment creation with idempotency key → provider confirmation → verified webhook → ledger entry.
6. Duplicate webhook → no second financial mutation.
7. Refund request → bounded cumulative refund → completion/reconciliation.
8. Contract completion → settlement → final audit evidence.

## Failure/recovery scenarios
| Scenario | Required behavior | Recovery evidence |
|---|---|---|
| Expired access token | Reject protected request; refresh only through valid rotation | Auth status + rotation event |
| Replayed refresh token | Reject and revoke affected session chain | Security/audit event |
| Duplicate payment request | Return original idempotent result; no duplicate charge | Idempotency record |
| Hash-mismatched idempotent replay | Reject; do not mutate financial state | Error + audit event |
| Invalid webhook signature | Reject before financial mutation | Webhook rejection event |
| Duplicate webhook event | Mark duplicate/no-op after first application | Event ID evidence |
| Provider timeout | Keep payment non-terminal until authoritative result; retry safely | Retry/idempotency evidence |
| Partial payment failure | No premature ledger settlement | Payment + ledger consistency evidence |
| Refund above remaining amount | Reject | Refund ceiling evidence |
| Concurrent refund requests | Serialize/check authoritative total; never exceed payment amount | DB transaction evidence |
| Unauthorized participant mutation | Reject with non-secret error | Authorization audit event |
| Rate-limit exhaustion | Reject safely; recover after window | Rate-limit evidence |
| Backend unavailable | Client surfaces retry-safe state; no fabricated success | Client/network evidence |
| Database migration failure | Release gate stops; no partial production release | CI failure evidence |

## Financial invariants
- Money is represented in integer minor units.
- Currency is an explicit ISO-4217-style three-letter code.
- Provider references are unique per provider.
- Wallet ledger entries are append-only.
- Verified provider events are the only webhook path permitted to mutate financial state.
- Cumulative completed/processing/approved refunds cannot exceed the authoritative payment amount.
- Idempotency records must have a future expiry.

## Evidence boundary
A real staging run must record only non-secret identifiers, status summaries, migration/RLS results, webhook verification results, audit-event presence, and recovery outcomes. Credentials, tokens, signatures, payment secrets, and personal data must never be included in release evidence.
