# Freelance Hub — v29.400 Production API Boundary

This document closes the software-side contract between the Android client and the future deployed backend. It does **not** deploy a backend or create provider credentials.

## Required server responsibilities

1. **Authentication**
   - Verify credentials only on the server/auth provider.
   - Issue short-lived access tokens and rotate refresh tokens.
   - Enforce account status, email verification policy, role authorization and session revocation.

2. **Request safety**
   - Require a correlation/request ID for every authenticated write.
   - Apply endpoint-specific rate limits.
   - Validate body size, pagination bounds, identifiers, currency and monetary integer units.
   - Reject unknown/unsafe state transitions instead of trusting Android input.

3. **Idempotency**
   - Payment, refund, contract-creation and other financial writes must accept a client-generated idempotency key.
   - Bind the key to an actor + operation scope + canonical request hash.
   - Return the original stored response for an exact replay; reject a reused key with a different request hash.
   - Expire old records according to server policy.

4. **Payment webhooks**
   - Verify provider signature/authentication before processing.
   - Persist provider + provider event ID in `payment_webhook_events` before side effects.
   - Treat duplicate provider events as replay/no-op.
   - Apply provider events through the payment state machine; never grant paid access from the Android client.
   - Record processing outcome and failure code for reconciliation.

5. **Audit logging**
   - Write server-side request outcomes to `api_audit_events`.
   - Do not store passwords, access tokens, refresh tokens, payment secrets or raw webhook signatures in audit records.

6. **Authorization / RLS**
   - Hosted auth-aware PostgreSQL must apply `BACKEND_RLS.sql`.
   - Client apps must never connect directly to PostgreSQL.
   - Service-role operations remain server-side only.

## Financial invariant

The backend is authoritative for checkout, escrow, release, refund, dispute and course/premium entitlement. Android may display server state but cannot create a successful payment, unlock paid content, or mark a financial transition as completed locally.

## Deployment gate

Before production release, the operator must provide the real auth provider, managed database, HTTPS API, payment provider, webhook endpoint, secret store, monitoring and backup/recovery configuration. No real secrets belong in this repository.
