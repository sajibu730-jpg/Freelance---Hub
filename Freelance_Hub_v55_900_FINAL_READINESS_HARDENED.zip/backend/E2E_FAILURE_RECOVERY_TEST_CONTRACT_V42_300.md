# Freelance Hub v42.300 — End-to-End and Failure/Recovery Test Contract

## Purpose
This release adds a deterministic pre-staging contract for the complete critical path and its failure/recovery cases. It is a **test contract and static readiness gate**, not evidence that a live staging or production environment has been executed.

## Critical path
1. Signup → email verification → login.
2. Login → token refresh → refresh-token rotation.
3. Create job → retrieve job → submit proposal.
4. Client accepts proposal → contract state transition.
5. Contract participants exchange messages; non-participant access is denied.
6. Create payment with idempotency key → provider funding webhook → FUNDED state.
7. Duplicate webhook is detected without duplicate ledger mutation.
8. Release request → RELEASE_REQUESTED → RELEASED with authorized server-side transition.
9. Refund request is bounded by the original payment amount and idempotent.
10. Completion/terminal state prevents later unauthorized mutation.

## Required failure/recovery scenarios
- expired access token → refresh or re-authentication; no privilege escalation.
- refresh-token replay → reuse detection/revocation.
- unauthorized proposal/contract/message mutation → rejected without state change.
- suspended/closed account → protected resource denied.
- rate limit exceeded → request rejected without partial mutation.
- duplicate idempotency key with changed request hash → conflict; original result remains authoritative.
- invalid webhook signature → rejected; no financial state mutation.
- duplicate webhook event → one state transition/ledger effect only.
- out-of-order webhook → ignored or quarantined unless state transition is valid.
- database/API timeout during financial mutation → retry is safe through idempotency; no duplicate ledger effect.
- release/refund beyond available amount → rejected.
- terminal payment/refund → later mutation rejected.
- migration failure → deployment stops before traffic switch; rollback/run-forward decision recorded.
- restore failure → incident escalated; production cutover remains blocked until recovery evidence exists.

## Evidence required from an actual staging run
- non-secret environment identifier and test-run ID
- request/response status summary
- database migration and RLS result
- authorization-denial checks
- idempotency/replay results
- webhook signature and duplicate-event results
- ledger invariant checks
- failure/recovery outcomes
- artifact SHA-256 and workflow run metadata

No passwords, access tokens, refresh tokens, payment secrets, private keys, card data, or private message bodies may appear in test evidence.

## Production boundary
A repository ZIP, static gate, or CI pass does not prove that a real staging server, database, payment provider, device, backup restore, or production deployment has been executed.
