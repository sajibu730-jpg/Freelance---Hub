# API contract matrix — v47.200

| Area | Example route family | Required authorization | Required controls | Financial effect |
|---|---|---|---|---|
| Auth/session | `/auth/*`, `/me` | verified identity / account state | issuer, audience, expiry, refresh replay protection | none |
| Profile | `/users/me`, `/users/{id}` | self or permitted public view | field allowlist, input validation | none |
| Jobs | `/jobs`, `/jobs/{jobId}` | authenticated; client mutation ownership | bounded pagination, visibility, audit | none |
| Proposals | `/jobs/{jobId}/proposals`, `/proposals/{id}` | permitted freelancer/client participant | duplicate/ownership checks, state validation | none |
| Contracts | `/contracts/{id}` | client/freelancer participant | server state machine, ownership | may authorize later payment, not itself a payment |
| Messages | `/conversations/*`, `/messages/*` | conversation participant | server sender identity, bounded body | none |
| Work submission | `/contracts/{id}/submissions` | assigned freelancer / authorized reviewer | requirement linkage, revision history, file/input limits | none |
| AI analysis | `/submissions/{id}/analysis` | assigned freelancer or authorized reviewer | requirement-scoped analysis, no payment authority | none |
| Reviews | `/contracts/{id}/reviews` | eligible participant | one-review-per-side policy, validation | none |
| Payment/escrow | `/payments/*`, `/escrow/*` | authorized contract participant + server decision | idempotency, amount/currency match, ledger invariants | yes |
| Webhooks | `/webhooks/{provider}` | provider signature verification | unique event ID, replay protection, processed state | yes |
| Refunds | `/refunds/*` | authorized requester/reviewer | ceiling, state machine, idempotency | yes |
| Disputes | `/disputes/*` | contract participant / moderator | participant checks, evidence, state machine | may authorize refund/release |
| Trust & safety | `/reports/*`, `/enforcement/*`, `/appeals/*` | reporter/moderator/account owner as applicable | evidence reference, audit, appeal separation | none |
| Notifications | `/notifications/*` | audience owner | audience binding, bounded page size | none |
| Admin | `/admin/*` | server-side admin role | explicit allowlist, audit, rate limits, no client role assertion | may authorize controlled financial action |

## Universal response rules
- Every response carrying a request ID uses the same request ID format and correlation value.
- Protected mutation failures use stable error codes.
- Pagination is bounded server-side.
- Authorization is derived from verified server identity, never a client-supplied role/user ID.
- Financial mutations require idempotency and transaction-safe invariant enforcement.
