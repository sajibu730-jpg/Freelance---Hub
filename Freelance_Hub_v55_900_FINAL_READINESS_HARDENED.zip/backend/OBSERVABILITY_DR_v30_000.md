# Observability and disaster-recovery boundary — v30.000

## Minimum production telemetry
- request ID and API latency/error counters
- authentication failures and token-reuse events
- authorization denials
- rate-limit events
- payment webhook verification/processing outcomes
- idempotency conflicts
- database migration status
- security incidents and state transitions

Do not log passwords, access/refresh tokens, payment secrets, full card data, or private message bodies.

## Recovery requirements
- automated managed-database backups
- documented restore procedure
- periodic restore verification
- migration version tracking
- rollback/run-forward decision recorded per release
- incident evidence retained according to the deployment's privacy/retention policy

A source ZIP containing these contracts is not evidence that backups or restore tests have actually been executed in production.
