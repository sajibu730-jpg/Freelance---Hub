# Migration & Restore Verification Contract — v45.200

## Migration requirements

1. Migrations are forward-only and versioned.
2. Destructive baseline operations are prohibited in release automation.
3. Schema changes affecting payments, ledger, refunds, disputes, RLS, or identity uniqueness require an explicit migration record.
4. A production migration must be backed by a current backup/restore point before execution.
5. Migration evidence must record Git SHA, migration identifier, UTC timestamp, operator/workflow run, result, and rollback/restore decision.

## Restore requirements

- A restore test must be performed against an isolated target.
- The restored database must pass schema integrity checks and the financial invariant checks before it is considered usable.
- Restore testing must verify that secrets are not stored inside the database dump.
- A failed restore or failed post-restore invariant check blocks production acceptance.

## Scope boundary

This repository provides the verification contract and static release gate. It does not perform a live production backup or restore without access to the user's managed database environment.
