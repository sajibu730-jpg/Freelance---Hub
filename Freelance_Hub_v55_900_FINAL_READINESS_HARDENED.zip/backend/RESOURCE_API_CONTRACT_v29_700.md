# Resource API contract — v29.700

This contract defines the server-side boundary for `/me`, jobs, proposals, contracts, and messages.

| Resource | Server requirement |
|---|---|
| `/me` | Derive identity from verified access token; never accept user id as authority |
| `GET /jobs` | Bounded cursor pagination; server-side filters; stable ordering |
| `POST /jobs` | Authenticated client role + validation + audit event |
| `GET /jobs/{jobId}` | Return only fields permitted by job visibility state |
| `POST /jobs/{jobId}/proposals` | One active proposal per permitted freelancer/job; ownership enforced server-side |
| `PATCH /proposals/{proposalId}` | Participant/owner authorization before mutation |
| `/messages` | Conversation participant authorization on read/write; no client-controlled sender id |
| Contract transitions | Explicit server state machine; invalid transitions rejected |

## Common rules
- HTTPS only in production.
- Request ID required for every API request.
- Rate limits are endpoint-specific and enforced server-side.
- Input validation happens before persistence.
- Errors use stable non-secret codes; no stack traces or SQL details.
- Pagination limits are server-enforced.
- Audit events contain actor/resource/request metadata but never credentials or tokens.
