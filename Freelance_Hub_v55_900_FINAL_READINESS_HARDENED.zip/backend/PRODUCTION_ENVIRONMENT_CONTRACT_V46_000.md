# Production Environment Contract — v46.000

This contract defines what must be validated before a live deployment is accepted. It does not claim that a live backend, database, payment provider, or secrets store has been provisioned.

## Required runtime boundaries

- `DATABASE_URL` must resolve to a managed PostgreSQL instance and must never be embedded in Android resources.
- `JWT_ISSUER` and `JWT_AUDIENCE` must be explicit and non-placeholder in the deployment secret store.
- Production API traffic must use HTTPS only.
- Payment provider secrets and webhook signing secrets belong only in the server-side secret manager.
- Android must communicate only with the API boundary; it must not connect directly to PostgreSQL.
- Environment values must be validated at startup and fail closed when mandatory values are missing or still contain documented placeholders.

## Configuration safety

- No populated `.env` file is committed.
- No private key, password, access token, payment secret, or webhook secret is stored in source control.
- Production and non-production credentials must be separate.
- Database migrations must be applied through a controlled deployment identity, not from the Android client.
- Health checks must report dependency state without returning secrets, tokens, connection strings, or raw provider errors.

## Acceptance boundary

A PASS from the v46.000 environment gate means the source package contains the required validation contract and placeholder/secret hygiene checks. It is not evidence that external infrastructure is live.
