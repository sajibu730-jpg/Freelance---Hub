-- v47.200 read-only invariant fixtures.
-- This file intentionally contains SELECT/CTE statements only; it must never mutate production data.

-- 1. Duplicate provider event IDs would violate the webhook uniqueness contract.
WITH fixture(provider, provider_event_id) AS (
  VALUES ('fixture_provider','evt_a'), ('fixture_provider','evt_b'), ('fixture_provider','evt_a')
)
SELECT provider, provider_event_id, COUNT(*) AS occurrences
FROM fixture
GROUP BY provider, provider_event_id
HAVING COUNT(*) > 1;

-- 2. A refund greater than the payment amount is invalid.
WITH fixture(payment_amount_minor, refund_amount_minor) AS (
  VALUES (10000::BIGINT, 10001::BIGINT), (10000::BIGINT, 5000::BIGINT)
)
SELECT payment_amount_minor, refund_amount_minor
FROM fixture
WHERE refund_amount_minor > payment_amount_minor;

-- 3. Currency mismatches are invalid.
WITH fixture(payment_currency, ledger_currency) AS (
  VALUES ('USD','USD'), ('USD','EUR')
)
SELECT payment_currency, ledger_currency
FROM fixture
WHERE payment_currency IS DISTINCT FROM ledger_currency;

-- 4. Reusing an idempotency key with a different request hash is a conflict.
WITH fixture(scope_key, request_hash) AS (
  VALUES ('payment:create:contract-1','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),
         ('payment:create:contract-1','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb')
)
SELECT scope_key, COUNT(DISTINCT request_hash) AS distinct_hashes
FROM fixture
GROUP BY scope_key
HAVING COUNT(DISTINCT request_hash) > 1;

-- 5. Production reconciliation query: duplicate webhook records, if any, are review items.
SELECT provider, provider_event_id, COUNT(*) AS occurrences
FROM payment_webhook_events
GROUP BY provider, provider_event_id
HAVING COUNT(*) > 1;
