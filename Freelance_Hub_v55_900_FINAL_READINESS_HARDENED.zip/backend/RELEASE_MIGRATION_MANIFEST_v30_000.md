# Release migration manifest — v30.000

The database migration source of truth remains `BACKEND_SCHEMA.sql` and `BACKEND_RLS.sql`.

Required release checks:
- schema and RLS files are present;
- RLS is applied only in an auth-aware hosted environment;
- all application tables remain protected by RLS/FORCE RLS;
- migration execution is recorded with an immutable release/build identifier;
- schema changes are backward-compatible with the deployed Android API contract before rollout;
- destructive changes require an explicit migration/recovery plan.

This manifest does not claim a hosted migration has been executed.
