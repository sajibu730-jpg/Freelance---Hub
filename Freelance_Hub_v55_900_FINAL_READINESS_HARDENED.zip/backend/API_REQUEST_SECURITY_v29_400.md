# API Request Security Contract — v29.400

| Area | Server requirement |
|---|---|
| Transport | HTTPS only; reject insecure production base URLs |
| Auth | Verify access token, issuer, audience, expiry and account state |
| Writes | Request ID + endpoint rate limit + input validation |
| Pagination | Server-enforced bounded page size/cursor; never accept unbounded limits |
| Money | Integer minor units + ISO-4217-like 3-letter currency validation |
| Idempotency | Required for financial/side-effecting operations; exact request-hash replay only |
| Authorization | Resource ownership/participant checks before mutation |
| Errors | Stable non-secret error codes; no stack traces or SQL details |
| Logging | Request outcome and actor metadata; never secrets/tokens/passwords |
| Admin | Separate server-side authorization; no client-controlled admin role |
| Database | API/service only; Android never connects directly |
