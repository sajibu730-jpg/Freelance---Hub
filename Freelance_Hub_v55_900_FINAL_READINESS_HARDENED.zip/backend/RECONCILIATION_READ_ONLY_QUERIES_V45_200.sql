-- Freelance Hub v45.200 read-only reconciliation queries.
-- Run against a controlled read-only connection. No INSERT/UPDATE/DELETE/DDL is used here.

-- 1) Payment rows whose provider reference is duplicated.
SELECT provider_reference, COUNT(*) AS payment_count
FROM payment_transactions
WHERE provider_reference IS NOT NULL
GROUP BY provider_reference
HAVING COUNT(*) > 1
ORDER BY payment_count DESC, provider_reference;

-- 2) Webhook events whose provider event ID is duplicated within provider scope.
SELECT provider, provider_event_id, COUNT(*) AS event_count
FROM payment_webhook_events
GROUP BY provider, provider_event_id
HAVING COUNT(*) > 1
ORDER BY event_count DESC, provider, provider_event_id;

-- 3) Refund totals that exceed the original payment amount.
SELECT p.id AS payment_id,
       p.amount_minor AS payment_amount_minor,
       p.currency,
       COALESCE(SUM(r.amount_minor) FILTER (WHERE r.status = 'COMPLETED'), 0) AS completed_refund_minor
FROM payment_transactions p
LEFT JOIN refund_requests r ON r.payment_id = p.id
GROUP BY p.id, p.amount_minor, p.currency
HAVING COALESCE(SUM(r.amount_minor) FILTER (WHERE r.status = 'COMPLETED'), 0) > p.amount_minor
ORDER BY p.id;

-- 4) Ledger entries with payment identity mismatches.
SELECT l.id AS ledger_id, l.payment_id, l.contract_id AS ledger_contract_id,
       p.contract_id AS payment_contract_id, l.currency AS ledger_currency,
       p.currency AS payment_currency, l.amount_minor, p.amount_minor
FROM wallet_ledger_entries l
JOIN payment_transactions p ON p.id = l.payment_id
WHERE l.contract_id IS DISTINCT FROM p.contract_id
   OR l.currency IS DISTINCT FROM p.currency
   OR l.amount_minor > p.amount_minor;

-- 5) Payments whose participant/contract identity no longer matches.
SELECT p.id AS payment_id, p.contract_id,
       p.client_id AS payment_client_id, c.client_id AS contract_client_id,
       p.freelancer_id AS payment_freelancer_id, c.freelancer_id AS contract_freelancer_id,
       p.amount_minor, c.agreed_budget_minor, p.currency, c.currency AS contract_currency
FROM payment_transactions p
JOIN contracts c ON c.id = p.contract_id
WHERE p.client_id IS DISTINCT FROM c.client_id
   OR p.freelancer_id IS DISTINCT FROM c.freelancer_id
   OR p.amount_minor IS DISTINCT FROM c.agreed_budget_minor
   OR p.currency IS DISTINCT FROM c.currency;

-- 6) Webhook events that claim successful verification but have no processed timestamp.
SELECT provider, provider_event_id, event_type, processing_status, received_at, processed_at
FROM payment_webhook_events
WHERE signature_verified = TRUE
  AND processing_status = 'PROCESSED'
  AND processed_at IS NULL
ORDER BY received_at DESC;
