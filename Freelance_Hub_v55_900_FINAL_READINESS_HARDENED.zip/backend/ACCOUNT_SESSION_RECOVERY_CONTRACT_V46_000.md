# Account and Session Recovery Contract — v46.000

- Recovery requires a verified recovery factor and a server-authoritative challenge.
- Recovery attempts are rate-limited and produce audit evidence without exposing secrets.
- Successful recovery revokes or rotates affected sessions/tokens as configured by policy.
- Recovery cannot elevate a user into admin/moderator/payment-provider authority.
- Closed/banned identity controls remain authoritative during re-registration and recovery.
- Logout/revocation is fail-closed for protected mutations; stale sessions cannot perform payment, moderation or account-security mutations.
- Recovery state transitions are idempotent and safe under duplicate requests.
