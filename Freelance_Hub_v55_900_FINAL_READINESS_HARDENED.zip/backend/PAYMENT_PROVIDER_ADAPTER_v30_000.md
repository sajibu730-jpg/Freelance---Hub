# Payment provider adapter boundary — v30.000

Provider integration is server-only. The Android application never receives provider secret keys and never authorizes paid access from a local callback alone.

## Adapter responsibilities
- Create checkout/payment intent from an authoritative server order.
- Attach a server-generated order/checkout identifier.
- Verify provider webhook signature using secret-manager material.
- Enforce timestamp/replay window where supported.
- Persist the webhook event before processing it.
- Process each provider event at most once by provider event ID.
- Apply financial state changes transactionally.
- Reconcile provider state with the internal ledger.
- Record refunds/disputes and provider references without storing secrets.

## Required invariants
- Provider amount/currency must match the authoritative order.
- A client-supplied success flag is never sufficient to grant access.
- Duplicate webhook delivery is idempotent.
- Invalid signature causes no financial state mutation.
- A webhook for an unknown order is quarantined for review.
- Refund and dispute transitions are monotonic and auditable.
