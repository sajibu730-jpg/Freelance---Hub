# Production readiness boundary — v29.700

## Software-side complete in this milestone
- Authentication API contract hardened for token rotation/reuse detection.
- `/me`, jobs, proposals, contracts, and messaging authorization boundaries documented.
- Staging end-to-end test plan defined.
- CI version/evidence metadata aligned to v29.700.
- Existing database idempotency, webhook inbox, audit, and RLS boundaries retained.

## External deployment gates still required
- Real identity provider configured.
- Hosted PostgreSQL/Supabase migrations and RLS applied.
- HTTPS API deployed and reachable.
- Real payment provider configured with server-side secrets.
- Staging integration tests executed against the deployed service.
- Real-device smoke test and release signing completed.

Until those external gates pass, this source package must not be described as a production-deployed service.
