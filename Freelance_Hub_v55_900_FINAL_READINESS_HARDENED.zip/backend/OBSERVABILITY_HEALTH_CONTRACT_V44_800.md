# Observability & Health Contract — v44.800

## Health endpoints

The production API should expose separate checks for:

- process/liveness;
- database connectivity/readiness;
- authentication dependency readiness;
- payment provider dependency readiness;
- migration/schema compatibility.

Health responses must not expose credentials, JWTs, connection strings, SQL statements, stack traces, or provider secrets.

## Required telemetry

- request ID propagation;
- latency and error-rate metrics;
- authentication failures and rate-limit events;
- payment webhook verification failures;
- idempotency conflicts/replays;
- reconciliation exceptions;
- migration/restore events;
- deployment and rollback events.

Logs must avoid passwords, access tokens, authorization headers, full payment secrets and raw sensitive payloads.

## Incident boundary

A health-check or observability contract PASS confirms source-level readiness only. External monitoring, alert routing and on-call ownership still require deployment configuration.
