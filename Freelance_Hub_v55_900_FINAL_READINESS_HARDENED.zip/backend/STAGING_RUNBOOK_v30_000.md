# Staging execution runbook — v30.000

This runbook becomes the handoff checklist for the first real deployed staging service.

1. Provision isolated staging identity provider and database.
2. Apply schema migrations and auth-aware RLS.
3. Configure HTTPS API and secret-manager references.
4. Configure payment provider test credentials only in staging secrets.
5. Run authentication, authorization, messaging, contract, payment, webhook and rate-limit tests.
6. Verify audit events and request-ID correlation.
7. Execute backup/restore verification in the staging environment.
8. Record build SHA, migration version, API version and test-run ID.
9. Confirm no production credentials or personal data entered evidence artifacts.
10. Only after all checks pass, promote the same immutable build artifact to the next environment according to the deployment policy.
