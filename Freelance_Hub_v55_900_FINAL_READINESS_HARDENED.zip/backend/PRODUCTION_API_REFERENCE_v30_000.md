# Production API reference boundary — v30.000

This milestone defines the implementation boundary for a deployed API without embedding a specific vendor SDK or production credentials.

## Request pipeline
1. HTTPS termination and trusted proxy validation.
2. Request ID generation/propagation.
3. Authentication token validation for protected routes.
4. Account lifecycle and role authorization.
5. Rate-limit and bounded-pagination checks.
6. Idempotency check for financial mutations.
7. Request schema validation and normalized error response.
8. Domain mutation inside a database transaction.
9. Audit event emission.
10. Response with stable API contract and request ID.

## Error contract
Protected API errors must use a stable machine-readable shape:
`{ code, message, request_id }`.
Sensitive stack traces, SQL text, tokens, secrets, and provider payloads must never be returned to clients.

## Financial mutation rule
Payment, refund, escrow, wallet, and dispute mutations require a server-generated authorization decision and an idempotency key. A repeated key with a different normalized request hash must be rejected as a conflict.

## Pagination
List endpoints must enforce server-side maximum page size and reject invalid cursor/page parameters. Clients cannot request unbounded result sets.

## Audit
Security-sensitive actions emit an immutable audit record with request ID, actor, action type, target type/id, outcome, and server timestamp. Raw credentials and payment secrets are excluded.
