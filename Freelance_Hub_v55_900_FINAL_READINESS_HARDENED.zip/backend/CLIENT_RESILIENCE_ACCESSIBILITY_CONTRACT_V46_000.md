# Client Resilience and Accessibility Contract — v46.000

## Resilience
- Read operations may degrade to an explicit unavailable state; mutation operations must never silently succeed offline.
- Retries are bounded, backoff-aware and safe only for idempotent requests or requests carrying an idempotency key.
- Stable error codes/messages must avoid leaking credentials, tokens, payment secrets or internal stack traces.
- Connectivity recovery must not duplicate jobs, proposals, messages, payments or refunds.

## Accessibility and safety
- Interactive controls require meaningful labels/content descriptions.
- Error states are programmatically distinguishable and not conveyed by color alone.
- Dynamic text must remain readable without truncating critical financial/security information.
- Sensitive values are masked by default where exposure is not required for the task.
