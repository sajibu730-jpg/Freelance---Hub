# Data and financial consistency contract — v47.200
Production release requirements: migration ordering/checksum evidence; backup/restore evidence; provider-reference uniqueness; immutable posted ledger entries; exact amount/currency matching; refund ceiling; duplicate webhook protection; idempotency request-hash consistency; discrepancy recording and manual-review escalation.
Repository reconciliation SQL is read-only. Live reconciliation uses least-privilege credentials and performs no financial mutation.
