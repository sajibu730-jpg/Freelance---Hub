# Staging integration test plan — v29.700

This is a test contract, not a claim that a staging server is currently deployed.

## Required end-to-end checks
1. Signup → email verification → login.
2. Access token expiry → refresh rotation.
3. Refresh-token replay → reuse detection/revocation.
4. Create job → retrieve job → submit proposal.
5. Unauthorized proposal mutation is rejected.
6. Two participants can message; a non-participant cannot read/send.
7. Contract transition accepts only valid state transitions.
8. Financial mutation requires idempotency key and exact request-hash replay.
9. Duplicate payment webhook is accepted once and marked duplicate thereafter.
10. Invalid webhook signature is rejected without state mutation.
11. Closed/suspended account cannot access protected resources.
12. Rate limits and bounded pagination are enforced.

## Evidence required from a real staging run
- API base URL (non-secret identifier only)
- test run identifier
- request/response status summary
- database migration/RLS result
- webhook verification result
- audit-event presence check
- failure/recovery results

No production credentials or personal secrets belong in test evidence.
