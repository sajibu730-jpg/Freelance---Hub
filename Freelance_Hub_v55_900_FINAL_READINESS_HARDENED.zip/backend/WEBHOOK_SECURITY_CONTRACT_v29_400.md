# Payment Webhook Security Contract — v29.400

Provider-neutral contract for the production API.

## Processing order

1. Read raw request bytes without normalization.
2. Verify the provider signature using a secret stored outside the repository.
3. Validate timestamp/replay window when the provider supports it.
4. Parse the event only after signature verification.
5. Require a stable provider event ID and provider name.
6. Insert into `payment_webhook_events` using `(provider, provider_event_id)` uniqueness.
7. If the event already exists, return a successful duplicate/no-op response without repeating financial side effects.
8. For a new event, execute the server-side payment transition inside a database transaction.
9. Mark the inbox record `PROCESSED`, `IGNORED`, or `FAILED` and retain a safe failure code.

## Never do

- Never trust a client-provided payment success flag.
- Never put webhook secrets in Android resources, BuildConfig, source control, or APK assets.
- Never use a provider reference alone as proof of payment without verified provider event/authentication.
- Never process the same provider event twice.
