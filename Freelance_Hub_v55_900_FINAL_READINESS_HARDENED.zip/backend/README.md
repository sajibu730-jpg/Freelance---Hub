# Freelance Hub backend — v29.700 production integration boundary

This directory contains the local PostgreSQL development foundation. It is intentionally separate from the Android client.

## Safety

- Never commit real passwords, JWT signing keys, payment secrets, webhook secrets, or provider service keys.
- Use a secrets manager for production.
- Apply `BACKEND_SCHEMA.sql` to the local PostgreSQL container. Apply `BACKEND_RLS.sql` only in an authentication-aware hosted PostgreSQL/Supabase environment that provides `auth.uid()`; the local plain-PostgreSQL compose intentionally does not mount the RLS file because it would fail without the auth schema.
- The Android app must never connect directly to PostgreSQL.

## Local development

1. Copy `.env.example` to `.env` and replace the placeholder password.
2. Run `docker compose up -d` from this directory.
3. Use the future/API service boundary for application traffic; the database port is for local development only.

## Current integration status

The PostgreSQL schema, RLS foundation, API idempotency records, payment webhook inbox, server-side audit boundary, authentication rotation/reuse contract, resource authorization contract, and staging integration test plan are present, and `openapi.yaml` defines the provider-neutral API contract. The local compose file provisions schema only; hosted deployment must apply the RLS policy set in an auth-aware environment. A deployed production API is not included in this package. Until deployment is completed, the Android application must not treat the placeholder API endpoint as a live service.

## Production requirements

Production requires:

- a deployed HTTPS API,
- managed PostgreSQL/database hosting,
- server-side authentication and authorization,
- secret management,
- rate limiting and abuse controls,
- webhook verification for payment providers,
- backups/recovery procedures,
- monitoring and audit logging.

No production credentials are included here.
