# AI and trust/safety contract — v46.000
AI work analysis may compare submitted work against stored requirements and return structured findings. It must not authorize payment/refund, mark a contract complete by itself, close/suspend an account by itself, or bypass server authorization/reviewer controls.
Missing requirements, unavailable AI, malformed output or uncertain analysis fail closed to a reviewable state. Anti-bypass warnings, reports, appeals and administrative decisions remain explicit server-side transitions with auditable evidence.
