# Payment Reconciliation & Ledger Invariant Contract — v44.800

## Required invariants

- Every payment has exactly one contract and its participant IDs, amount and currency match the contract.
- Provider references and provider webhook event IDs are unique within their provider scope.
- Idempotency keys are unique within their defined scope and are not silently reused for a different request payload.
- A refund cannot exceed the original payment amount; cumulative completed refunds must not exceed the payment amount.
- Ledger entries linked to a payment must use the payment contract, currency and participant boundary.
- Terminal payment/refund states cannot be mutated into another terminal or active state.
- Replayed webhook events must not create a second financial effect.
- Reconciliation must identify orphaned provider events, unmatched internal payments, duplicate effects, currency mismatches, amount mismatches and state mismatches.

## Reconciliation evidence

A production reconciliation report should include:

- provider and reconciliation window;
- number of provider events received/processed/failed;
- internal payments by state;
- unmatched and duplicate references;
- ledger totals by currency;
- refund totals and remaining refundable amount;
- exceptions requiring manual review;
- Git SHA / workflow run and UTC timestamp.

The source gate verifies the contract and schema primitives. It does not claim that a live provider reconciliation has been executed.
