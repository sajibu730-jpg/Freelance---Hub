# Freelance Hub v17.300 Release Hardening

This boundary advances the source/CI hardening baseline from v17.100 to v17.300.

## Changes
- Version `17.300.0`, version code `8300`.
- Added a workflow-security gate covering least-privilege permissions, mutable branch references, pinned Java/Gradle versions, and secret-output checks.
- Added a deterministic v17.300 release-boundary verifier.
- Preserved explicit production blockers; source checks do not convert external evidence into completion.
- Added a 200-checkpoint traceability ledger for v17.101 → v17.300.

## Release boundary
A PASS here means the checked source/CI invariants hold. It does not establish a deployed backend, real payment provider, production database execution, release signing, device testing, or Play Console publication.
