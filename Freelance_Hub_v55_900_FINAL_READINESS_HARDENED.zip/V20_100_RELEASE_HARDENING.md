# Freelance Hub v20.100 — Release Hardening

Scope: source/CI release provenance, workflow ordering and permissions, stale-evidence exclusion, private-key pattern scanning, version continuity, deterministic release-boundary checks, and provenance evidence.

This milestone does **not** claim that a production APK/AAB was compiled, signed, installed on a real device, deployed to a production backend, connected to a live payment provider, or released to Google Play. Those require execution in the appropriate Android/cloud/account environments and independently verifiable evidence.

The active release workflows are required to run checkout first, then the v20.100 release-boundary gate, then the v20.100 provenance gate. Mutable GitHub Action refs are rejected and read-only workflow permissions are enforced.
