#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
[[ "$(cat "$ROOT/VERSION.txt")" == "46.400.0" ]]
grep -q "v46.001–v46.100" "$ROOT/V46_001_TO_V46_400_PRODUCTION_TRUST_RESILIENCE_LEDGER.md"
grep -q "AI/work analysis remains advisory" "$ROOT/backend/PRODUCTION_TRUST_RESILIENCE_CONTRACT_V46_400.md"
grep -q "does not claim live deployment" "$ROOT/backend/PRODUCTION_TRUST_RESILIENCE_CONTRACT_V46_400.md"
grep -q "aiMayAuthorize" "$ROOT/app/src/main/java/com/freelancehub/app/data/ProductionTrustResilienceRules.kt"
! grep -RInE 'sk_(live|test)_[A-Za-z0-9]+|AKIA[0-9A-Z]{16}|-----BEGIN (RSA |EC )?PRIVATE KEY-----' "$ROOT/app" "$ROOT/backend" --exclude='*.sha256' >/dev/null
echo "v46.400 release gate: PASS (source/contract checks only)"
