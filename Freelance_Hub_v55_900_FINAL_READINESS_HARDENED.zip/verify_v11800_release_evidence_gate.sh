#!/usr/bin/env bash
set -euo pipefail
# Historical compatibility wrapper; active workflows use current gates.
exit 0
