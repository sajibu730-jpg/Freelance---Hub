# Freelance Hub v9.600 — Source Reproducibility Verification

This milestone strengthens release provenance by requiring exact source-inventory coverage in addition to duplicate-free paths, file existence, and SHA-256 verification.

## Required CI evidence
- release APK output
- `SHA256SUMS.txt`
- `BUILD_METADATA.txt` containing release identity, Git SHA, workflow run/attempt, UTC timestamp, toolchain identity, and APK filenames

## Reproducibility controls
- `SOURCE_RELEASE_MANIFEST_v9.600.sha256` is non-empty and hash-valid.
- Every manifest path is unique and exists.
- Every release-source file is represented exactly once in the manifest.
- No manifest-only or source-only paths are permitted.
- The current gate executes before Gradle test/build commands.

## External boundary
Passing this source/CI contract does not mean that an APK was actually compiled in this environment, signed with a production key, installed on a real device, connected to a live backend/payment provider, or published to Google Play. Those remain external release activities.
