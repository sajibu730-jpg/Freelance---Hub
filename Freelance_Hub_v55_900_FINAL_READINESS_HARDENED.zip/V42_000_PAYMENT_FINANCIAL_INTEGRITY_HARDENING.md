# Freelance Hub v42.000 — Payment & Financial Integrity Hardening

## Scope
This release hardens the provider-neutral payment and wallet boundaries without embedding real provider credentials.

## Controls added
- Provider + provider-reference uniqueness for payment transactions.
- Provider identity becomes immutable once a provider reference is recorded.
- Wallet ledger rows are append-only; UPDATE/DELETE is blocked server-side.
- Payment-linked ledger entries must match authoritative payment currency and cannot exceed the payment amount.
- Ledger entry direction is constrained for FUND/HOLD/RELEASE/REFUND/FEE operations.
- Cumulative approved/processing/completed refunds cannot exceed the authoritative payment amount.
- Refunds are limited to FUNDED or DISPUTED payments.
- Unverified payment webhooks cannot enter PROCESSING or PROCESSED states.
- PROCESSED webhooks require/derive `processed_at`.
- API idempotency records must expire after creation.
- Existing idempotency keys, webhook event uniqueness, payment status transitions, dispute/refund transitions, and RLS boundaries remain in force.

## External requirements
Real provider account credentials, webhook secrets, production database deployment, and live payment-provider configuration remain external/account-owned operations.
