# Freelance Hub v10.800 — Incident Evidence-Chain Anchor Integrity

- Non-first incident events must provide a valid 64-character lowercase previous evidence hash.
- Non-first incident events must provide a valid source (`from_state`) lifecycle state.
- First-event anchor remains strictly `sequence_no=1`, with no previous hash/source state.
- Android lifecycle rules mirror the continuation anchor contract.
- Dedicated v10.800 verification gate added to build and production workflows.
- Version: 10.800.0 / Version Code 2980.
