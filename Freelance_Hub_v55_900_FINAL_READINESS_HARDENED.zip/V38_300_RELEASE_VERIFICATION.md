# v38.300 Release Verification

- VERSION.txt: 38.300.0
- Android versionCode: 38300
- Android versionName: 38.300.0
- Hardening ledger: 300 checkpoints (v38.001→v38.300)
- Scope: source/release-boundary hardening and verification.
- Not covered by this artifact: real-device installation, live backend/payment deployment, Play Store publication.
